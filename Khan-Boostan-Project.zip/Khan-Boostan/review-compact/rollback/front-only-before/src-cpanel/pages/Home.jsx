import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict, publicItemName } from '../lib.jsx'
import { newsCat } from '../components/NewsCard.jsx'

/* ثابت‌های صفحهٔ خانه (عیناً از phase-14) */
const CAT_IMG = { food: '/images/product-rice.webp', agri: '/images/product-dried-fruit.webp', construction: '/images/product-cement.webp', machinery: '/images/product-generator.webp', household: '/images/product-kitchenware.webp', textile: '/images/product-fabric.webp', energy: '/images/product-solar.webp', spare: '/images/product-spareparts.webp' }
const STEPS = {
  fa: [['۰۱', 'درخواست و شناخت نیاز', 'گفتگو با مشتری یا شرکت، تعیین مشخصات و مقدار'], ['۰۲', 'بررسی و تأمین', 'انتخاب تأمین‌کننده بر اساس اصول مشخص، اعلام شفاف قیمت و شرایط'], ['۰۳', 'هماهنگی و آماده‌سازی', 'کنترل کیفیت و بسته‌بندی، تکمیل اسناد'], ['۰۴', 'انتقال و تحویل', 'پیگیری تا تحویل، اطلاع‌رسانی روشن']],
  en: [['01', 'Request & scoping', 'Talk with the client, agree specifications and quantity'], ['02', 'Review & sourcing', 'Choose suppliers on clear principles, transparent pricing'], ['03', 'Coordination & prep', 'Quality control, packing and documents'], ['04', 'Shipping & delivery', 'Follow-up until delivery, clear updates']],
}
const faN = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d])
const feat = (a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0)

function PartnerLogo({ p, L }) {
  const ch = (L(p.name) || '?').trim().charAt(0)
  return (
    <span className="grid shrink-0 place-items-center" aria-hidden="true" style={{ width: '34px', height: '34px' }}>
      <svg viewBox="0 0 40 40" width="34" height="34"><g fill="#D96F4E"><path d="M20 4 34 12v16L20 36 6 28V12Z" /></g><text x="20" y="25.5" textAnchor="middle" fontSize="15" fontWeight="800" fill="#fff">{ch}</text></svg>
    </span>
  )
}

export default function Home() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  const [motionAllowed, setMotionAllowed] = useState(() => typeof window === 'undefined' || !window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)')
    const update = () => setMotionAllowed(!media.matches)
    media.addEventListener('change', update)
    update()
    return () => media.removeEventListener('change', update)
  }, [])
  const [form, setForm] = useState({ name: '', phone: '', email: '', msg: '', website: '' })
  const [sent, setSent] = useState(false)
  if (!data) return <div className="min-h-[70vh]" />

  const hero = settings.hero ?? {}, act = settings.activities ?? {}, about = settings.about ?? {}
  const comp = settings.company ?? {}, contact = settings.contact ?? {}, sec = settings.sections ?? {}
  const products6 = [...(data.products ?? [])].sort((a, b) => feat(a, b) || bySort(a, b)).slice(0, 6)
  const news3 = [...(data.news ?? [])].sort((a, b) => feat(a, b) || (b.date ?? '').localeCompare(a.date ?? '')).slice(0, 3)
  const facts = data.facts ?? [], markets = act.markets ?? []
  const projects3 = [...(data.projects ?? [])].sort((a, b) => feat(a, b) || bySort(a, b)).slice(0, 3)
  const partners10 = [...(data.partners ?? [])].sort((a, b) => feat(a, b) || bySort(a, b)).slice(0, 10)
  const steps = STEPS[lang === 'en' ? 'en' : 'fa']
  const gallery = data.gallery ?? [], cats = data.categories ?? []
  const profileDoc = (data.documents ?? []).find((d) => d.kind === 'profile')
  const caps = cats.map((c) => ({ id: c.id, name: L(c.name), n: (data.products ?? []).filter((p) => p.category === c.id).length })).filter((x) => x.n > 0).sort((a, b) => b.n - a.n).slice(0, 5)
  const maxN = Math.max(1, ...caps.map((x) => x.n))
  const factCells = [...facts.map((f) => ({ value: L(f.value), label: L(f.label) })), ...(markets.length ? [{ value: lang === 'fa' ? faN(markets.length) : String(markets.length), label: lang === 'fa' ? 'بازار فعال' : 'Active markets' }] : [])].slice(0, 4)
  const principles = comp.principles ?? []
  const catName = (id) => L((cats.find((c) => c.id === id) ?? {}).name, '')
  const submit = (e) => {
    e.preventDefault()
    fetch('/api/request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: form.name, phone: form.phone, email: form.email, message: form.msg, website: form.website }) }).then((r) => { if (r.ok) setSent(true) }).catch(() => {})
  }
  const marqueePartners = (
    <div className="marquee-group">
      {partners10.map((p, i) => (
        <span key={p.id ?? i} className="me-3 flex shrink-0 items-center gap-3 whitespace-nowrap rounded-xl border border-mist-200 bg-white px-4 py-2.5">
          <PartnerLogo p={p} L={L} />
          <span className="flex flex-col gap-1">
            <b className="text-[13.5px] text-ink">{L(p.name)}</b>
            <span><span className="rounded-full border border-mist-300 bg-mist-50 px-2.5 py-0.5 text-[11px] font-bold text-[#565E66]">{t('rel_' + p.kind, L(p.kind))}</span></span>
          </span>
        </span>
      ))}
    </div>
  )

  return (
    <main id="main" className="site-home flex-1">
      <section className="home-hero band-dark relative overflow-hidden pt-10 md:pt-14">
        {motionAllowed ? (
          <video autoPlay muted loop playsInline poster="/images/hero-trade.webp" className="absolute inset-0 h-full w-full object-cover" aria-hidden="true" tabIndex="-1">
            <source src="/videos/hero-loop.mp4" type="video/mp4" />
          </video>
        ) : (
          <img src="/images/hero-trade.webp" alt="" aria-hidden="true" fetchPriority="high" className="home-hero-still absolute inset-0 h-full w-full object-cover" />
        )}
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink/78 via-ink/52 to-ink" aria-hidden="true"></span>
        <span className="hero-shade" aria-hidden="true"></span>
        <span className="pointer-events-none absolute inset-0" aria-hidden="true" style={{ background: 'radial-gradient(120% 95% at 50% 8%, transparent 42%, rgba(30, 33, 37, 0.72) 100%)' }}></span>
        <span aria-hidden="true" className="mouse-glow " style={{ '--glow': 'rgba(238, 139, 108, .13)', '--gs': '680px' }}></span>
        <div className="home-hero-labels pointer-events-none absolute inset-0 hidden lg:block" aria-hidden="true">
          <span className="floaty glass absolute left-[4%] top-[13%] flex items-center gap-2 px-4 py-2.5 text-[12.5px] font-bold text-mist-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brass"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" /><path d="m3.3 7 8.7 5 8.7-5" /><path d="M12 22V12" /></svg>{lang === 'fa' ? 'واردات' : 'Import'}</span>
          <span className="floaty floaty-d1 glass absolute left-[10%] top-[66%] flex items-center gap-2 px-4 py-2.5 text-[12.5px] font-bold text-mist-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brass"><path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1" /><path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76" /><path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6" /><path d="M12 10v4" /><path d="M12 2v3" /></svg>{lang === 'fa' ? 'صادرات' : 'Export'}</span>
          <span className="floaty floaty-d2 glass absolute left-[30%] top-[9%] flex items-center gap-2 px-4 py-2.5 text-[12.5px] font-bold text-mist-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brass"><circle cx="12" cy="12" r="10" /><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" /><path d="M2 12h20" /></svg>{lang === 'fa' ? 'تجارت بین‌المللی' : 'Global trade'}</span>
        </div>
        <div className="home-hero-shell wrap relative z-[2] pb-24 md:pb-28">
          <div className="home-hero-copy max-w-[820px]">
            <span className="rv mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[.07] px-4 py-1.5 text-[13px] font-bold text-mist-100 backdrop-blur"><span className="pulse-dot h-2 w-2 rounded-full bg-brass"></span>{L(comp.legal)}</span>
            <h1 className="rv text-white" style={{ fontSize: 'clamp(30px, 3.7vw, 50px)', lineHeight: '1.3' }}>{L(hero.title)}</h1>
            <p className="rv mt-5 max-w-[54ch] text-[clamp(15.5px,1.3vw,18.5px)] leading-relaxed text-mist-300">{L(hero.text)}</p>
            <div className="rv mt-8 flex flex-wrap gap-3">
              <Link className="btn-coral" to="/activities">{t('nav_activities')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
              <Link className="btn-ghost-light" to="/contact">{t('nav_contact')}</Link>
            </div>
            {sec.showTeam !== false && (data.team ?? []).length > 0 && (
              <div className="rv mt-8 flex items-center gap-4">
                <div className="flex" dir="ltr">
                  {(data.team ?? []).slice(0, 4).map((m, i) => (
                    <img key={m.id ?? i} src={m.photo} alt="" loading="lazy" className={'h-11 w-11 rounded-full object-cover ring-2 ring-ink ' + (i ? '-ms-3' : '')} />
                  ))}
                </div>
                <span className="text-[13px] leading-tight text-mist-200">
                  <b className="block text-[14px] text-white">{lang === 'fa' ? 'تیم تجارت خارجی خان بوستان' : 'Khan Boostan trade desk'}</b>
                  {lang === 'fa' ? 'پاسخ‌گوی درخواست‌های شما' : 'Ready to answer your requests'}
                </span>
              </div>
            )}
            {markets.length > 0 && (
              <div className="rv mt-8 flex flex-wrap items-center gap-2 border-t border-white/10 pt-6">
                <span className="me-1 text-[12.5px] font-bold uppercase tracking-wide text-mist-300">{lang === 'fa' ? 'بازارها' : 'Markets'}</span>
                {markets.map((m, i) => (
                  <span key={i} className="rounded-full border border-white/12 bg-white/[.05] px-3 py-1 text-[12.5px] text-mist-200">{L(m)}</span>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
      {sec.showFacts !== false && factCells.length > 0 && (
        <div className="-mt-16 md:-mt-20">
          <div className="wrap relative">
            <div className="home-facts grid divide-y divide-mist-200 rounded-card border border-mist-200 bg-white shadow-card md:grid-cols-4 md:divide-y-0 md:divide-x md:rtl:divide-x-reverse">
              {factCells.map((f, i) => (
                <div key={i} className={`rv rv-d${i + 1} flex items-baseline gap-3 px-7 py-6`}>
                  <span className="font-head text-[30px] font-bold leading-none text-ink">{f.value}</span>
                  <span className="text-[13.5px] text-[#8A9199]">{f.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      <section className="home-intro bg-white py-16 md:py-24">
        <div className="wrap grid items-center gap-12 md:grid-cols-2 md:gap-16">
          <div className="rv">
            <div className="eyebrow mb-3 text-brass-dark">{t('about_t')}</div>
            <h2 className="mb-4" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>
              {lang === 'fa' ? (<>تجارتی که از <span className="text-brass-deep">نیاز بازار</span> آغاز می‌شود</>) : (<>Trade that starts from <span className="text-brass-deep">market need</span></>)}
            </h2>
            <p className="mb-4 text-[15px] leading-relaxed text-[#565E66]">{String(L(comp.about) || '').split('\n')[0]}</p>
            <p className="mb-6 text-[15px] leading-relaxed text-[#565E66]">{L(comp.approach)}</p>
            <Link className="link-more" to="/about">{t('read_more')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
          </div>
          <div className="rv relative pb-10">
            <span className="home-stamp pointer-events-none absolute grid h-[104px] w-[104px] place-items-center rounded-full bg-white shadow-card -top-7 -start-7 z-[2]" aria-hidden="true">
              <svg viewBox="0 0 100 100" className="spin-slow absolute inset-0 h-full w-full text-brass-deep" style={{ direction: 'ltr' }}>
                <defs><path id="sb-circle" d="M50,50 m-36,0 a36,36 0 1,1 72,0 a36,36 0 1,1 -72,0" /></defs>
                <text fontSize="10.2" fontWeight="700" letterSpacing="2.2" fill="currentColor"><textPath href="#sb-circle">KHAN BOOSTAN • IMPORT • EXPORT • </textPath></text>
              </svg>
              <span className="grid h-11 w-11 place-items-center rounded-full bg-brass text-white"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1" /><path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76" /><path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6" /><path d="M12 10v4" /><path d="M12 2v3" /></svg></span>
            </span>
            <div className="relative ">
              <div className="overflow-hidden rounded-2xl shadow-card"><img src="/images/trade-warehouse.webp" alt="" loading="lazy" className="aspect-[4/3] w-full object-cover" /></div>
              <div className="home-overlap absolute -bottom-9 -start-6 w-[46%] overflow-hidden rounded-2xl border-4 border-white shadow-card" style={{ transform: 'rotate(-3deg)' }}><img src="/images/trade-cargo.webp" alt="" loading="lazy" className="aspect-[4/3] w-full object-cover" /></div>
              <div className="absolute -bottom-6 end-4 rounded-xl bg-white px-5 py-3 text-center shadow-card">
                <div className="font-head text-[24px] font-bold leading-none text-brass-deep">{lang === 'fa' ? faN(markets.length) : markets.length}</div>
                <div className="mt-1 text-[11.5px] font-bold text-[#565E66]">{lang === 'fa' ? 'بازار فعال' : 'Active markets'}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="home-capabilities bg-white py-16 md:py-20">
        <div className="wrap grid gap-12 md:grid-cols-2 md:gap-16">
          <div className="rv">
            <div className="eyebrow mb-3 text-brass-dark">{t('capabilities_t')}</div>
            <h2 className="mb-6" style={{ fontSize: 'clamp(22px, 2.4vw, 30px)' }}>{lang === 'fa' ? (<>حوزه‌هایی که <span className="text-brass-deep">هر روز</span> در آن‌ها کالا جابه‌جا می‌کنیم</>) : (<>Sectors where goods move <span className="text-brass-deep">every day</span></>)}</h2>
            <div className="grid gap-4">
              {caps.map((c) => (
                <div key={c.id}>
                  <div className="mb-1.5 flex items-baseline justify-between gap-3 text-[13.5px]">
                    <span className="font-semibold text-ink">{c.name}</span>
                    <span className="text-[#8A9199]">{lang === 'fa' ? faN(c.n) + ' قلم' : c.n + ' items'}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-mist-200">
                    <div className="h-full rounded-full bg-gradient-to-r from-brass to-brass-deep transition-[width] duration-700" style={{ width: Math.round((c.n / maxN) * 100) + '%' }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="rv rv-r pb-9"><div className="relative "><div className="overflow-hidden rounded-2xl shadow-card"><img src="/images/trade-highway.webp" alt="" loading="lazy" className="aspect-[4/3] w-full object-cover"/></div><div className="home-overlap absolute -bottom-9 -start-6 w-[46%] overflow-hidden rounded-2xl border-4 border-white shadow-card" style={{transform:'rotate(-3deg)'}}><img src="/images/gallery-loading.webp" alt="" loading="lazy" className="aspect-[4/3] w-full object-cover"/></div></div></div>
        </div>
      </section>
      <section className="home-trades py-16 md:py-20">
        <div className="wrap">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
            <div className="max-w-[62ch]">
              <div className="eyebrow mb-2 text-brass-dark">{t('nav_activities')}</div>
              <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('trade_intro_t')}</h2>
              <p className="mt-2 text-[#565E66]">{t('trade_intro_d')}</p>
            </div>
            <Link className="btn-line btn-sm" to="/activities">{t('view_all')}</Link>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            <Link className="card group rv rv-d1 relative flex h-full flex-col overflow-hidden no-underline" to="/import">
              <div className="aspect-[16/9] overflow-hidden"><img src="/images/trade-warehouse.webp" alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
              <div className="flex flex-1 flex-col gap-2 p-6 pt-0">
                <span className="relative z-[2] -mt-5 grid h-11 w-11 place-items-center rounded-xl bg-white text-brass-dark shadow-card ring-1 ring-mist-200"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1" /><path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76" /><path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6" /><path d="M12 10v4" /><path d="M12 2v3" /></svg></span>
                <h3 className="mt-2 text-[18px]">{L(settings.pages?.import?.title, lang === 'fa' ? 'واردات کالا' : 'Import of goods')}</h3>
                <p className="line-clamp-3 text-[14px] leading-relaxed text-[#565E66]">{L(settings.pages?.import?.intro)}</p>
              </div>
            </Link>
            <Link className="card group rv rv-d2 relative flex h-full flex-col overflow-hidden no-underline" to="/export">
              <div className="aspect-[16/9] overflow-hidden"><img src="/images/trade-cargo.webp" alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
              <div className="flex flex-1 flex-col gap-2 p-6 pt-0">
                <span className="relative z-[2] -mt-5 grid h-11 w-11 place-items-center rounded-xl bg-white text-brass-dark shadow-card ring-1 ring-mist-200"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" /><path d="m3.3 7 8.7 5 8.7-5" /><path d="M12 22V12" /></svg></span>
                <h3 className="mt-2 text-[18px]">{L(settings.pages?.export?.title, lang === 'fa' ? 'صادرات محصولات' : 'Export of products')}</h3>
                <p className="line-clamp-3 text-[14px] leading-relaxed text-[#565E66]">{L(settings.pages?.export?.intro)}</p>
              </div>
            </Link>
            <Link className="card group rv rv-d3 relative flex h-full flex-col overflow-hidden no-underline" to="/activities">
              <div className="aspect-[16/9] overflow-hidden"><img src="/images/trade-port.webp" alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
              <div className="flex flex-1 flex-col gap-2 p-6 pt-0">
                <span className="relative z-[2] -mt-5 grid h-11 w-11 place-items-center rounded-xl bg-white text-brass-dark shadow-card ring-1 ring-mist-200"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" /><path d="M2 12h20" /></svg></span>
                <h3 className="mt-2 text-[18px]">{lang === 'fa' ? 'تأمین و تجارت بین‌المللی' : 'Sourcing & international trade'}</h3>
                <p className="line-clamp-3 text-[14px] leading-relaxed text-[#565E66]">{L(act.sourcing)}</p>
              </div>
            </Link>
          </div>
        </div>
      </section>
      {sec.showProducts !== false && cats.length > 0 && (
        <section className="bg-white py-14 md:py-16">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('nav_products')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('categories_t')}</h2>
                <p className="mt-2 text-[#565E66]">{t('categories_d')}</p>
              </div>
              <Link className="btn-line btn-sm" to="/products">{t('view_all')}</Link>
            </div>
            <div className="home-category-grid grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {cats.map((c, i) => {
                const n = (data.products ?? []).filter((p) => p.category === c.id).length
                return (
                  <Link key={c.id} className={`rv rv-d${(i % 4) + 1} group relative block overflow-hidden rounded-xl2 no-underline`} to={`/products/?c=${c.id}`}>
                    <img src={CAT_IMG[c.id] ?? '/images/product-rice.webp'} alt={L(c.name)} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                    <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/25 to-transparent" aria-hidden="true"></span>
                    <span className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-4">
                      <b className="text-[14.5px] text-white">{L(c.name)}</b>
                      <span className="rounded-full bg-white/90 px-2 py-0.5 text-[11px] font-bold text-ink">{lang === 'fa' ? faN(n) : n}</span>
                    </span>
                  </Link>
                )
              })}
            </div>
          </div>
        </section>
      )}
      {sec.showProducts !== false && products6.length > 0 && (
        <section className="home-process py-16 md:py-24">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('nav_products')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'محصولات منتخب' : 'Selected products'}</h2>
                <p className="mt-2 text-[#565E66]">{lang === 'fa' ? 'نمونه‌ای از کالاهایی که در واردات یا صادرات آن‌ها فعالیت داریم.' : 'A sample of the goods we trade in import or export.'}</p>
              </div>
              <Link className="btn-line btn-sm" to="/products">{t('view_all')}</Link>
            </div>
            <div className="home-product-list grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {products6.map((p, i) => (
                <div key={p.id} className={`rv rv-d${(i % 3) + 1}`}>
                  <Link className="kb-product-card card group flex h-full flex-col overflow-hidden no-underline" to={`/products/${p.id}/`}>
                    <div className="kb-card-media relative aspect-[4/3] overflow-hidden bg-mist-100">
                      <img src={p.image} alt={publicItemName(L(p.name))} loading="lazy" decoding="async" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                      <span className="absolute start-3 top-3 flex gap-1.5">
                        {p.featured && <span className="rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured_badge', lang === 'fa' ? 'ویژه' : 'Featured')}</span>}
                      </span>
                    </div>
                    <div className="kb-card-content flex flex-1 flex-col gap-2 p-5">
                      <span className="kb-card-meta flex items-center justify-between gap-2 text-[12px] font-bold text-brass-dark">
                        {catName(p.category)}
                        <span className="rounded-full border px-2 py-0.5 text-[10.5px] font-bold bg-brass-pale text-brass-dark border-[#F1C9B8]">{t('status_' + p.status, p.status)}</span>
                      </span>
                      <h3 className="text-[17px] leading-relaxed">{publicItemName(L(p.name))}</h3>
                      <p className="line-clamp-2 text-[13.5px] text-[#565E66]">{L(p.short)}</p>
                      <span className="kb-card-action mt-auto inline-flex items-center gap-2 pt-2 text-[13.5px] font-bold text-ink transition-colors group-hover:text-brass-dark">{t('view_details')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:-translate-x-1 rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></span>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
      <section className="bg-white py-16 md:py-20">
        <div className="wrap">
          <div className="mb-8 md:mb-10">
            <div className="eyebrow mb-2 text-brass-dark">{t('why_t')}</div>
            <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('reasons_t')}</h2>
            <p className="mt-2 text-[#565E66]">{t('reasons_d')}</p>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {principles.map((v, i) => (
              <div key={i} className={`rv rv-d${(i % 3) + 1} card flex h-full items-start gap-4 p-6`}>
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-brass-pale font-head text-[15px] font-bold text-brass-dark">{String(i + 1).padStart(2, '0')}</span>
                <span>
                  <b className="mb-1 block text-[16px] text-ink">{L(v.title)}</b>
                  <span className="block text-[13.5px] leading-relaxed text-[#565E66]">{L(v.text)}</span>
                </span>
              </div>
            ))}
          </div>
          <div className="rv mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {(about.values ?? []).map((v, i) => (
              <div key={i} className="flex items-start gap-2.5 rounded-card border border-mist-200 bg-mist-50 p-3.5">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brass"></span>
                <span className="text-[13.5px] leading-snug"><b className="block text-ink">{L(v.title)}</b><span className="text-[#6B7278]">{L(v.text)}</span></span>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="py-16 md:py-24">
        <div className="wrap">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4 md:mb-14">
            <div>
              <div className="eyebrow mb-2 text-brass-dark">{t('nav_process')}</div>
              <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? (<>از درخواست تا تحویل، در <span className="text-brass-deep">چهار گام</span></>) : (<>From request to delivery, in <span className="text-brass-deep">four steps</span></>)}</h2>
            </div>
            <Link className="btn-line btn-sm" to="/process">{lang === 'fa' ? 'جزئیات روند' : t('nav_process')}</Link>
          </div>
          <div className="relative grid gap-8 md:grid-cols-4 md:gap-6">
            <span className="step-line inset-x-[12%] hidden md:block" aria-hidden="true"></span>
            {steps.map((s, i) => (
              <div key={i} className={`rv rv-d${i + 1} relative flex gap-4 md:flex-col md:items-center md:text-center`}>
                <span className="step-dot">{s[0]}</span>
                <div>
                  <h3 className="mb-1.5 text-[17px]">{s[1]}</h3>
                  <p className="text-[14px] leading-relaxed text-[#565E66]">{s[2]}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      {sec.showProjects !== false && projects3.length > 0 && (
        <section className="bg-white py-16 md:py-20">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div>
                <div className="eyebrow mb-2 text-brass-dark">{lang === 'fa' ? 'سوابق و نمونه‌های همکاری' : 'Track record & cases'}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'سوابق و نمونه‌های همکاری' : 'Track record & selected cases'}</h2>
              </div>
              <Link className="btn-line btn-sm" to="/projects">{t('view_all')}</Link>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              {projects3.map((pr, i) => (
                <article key={pr.id} className={`card rv rv-d${i + 1} flex h-full flex-col gap-2 overflow-hidden p-0`}>
                  <img src={pr.image} alt="" loading="lazy" className="aspect-[16/9] w-full object-cover" />
                  <div className="flex flex-1 flex-col gap-2 p-6">
                    <span className="flex items-center gap-2">
                      <span className="tag">{L(pr.sector)}</span>
                      <span className="text-[12px] text-[#8A9199]">{pr.year}</span>
                    </span>
                    <h3 className="mt-1 text-[16.5px] leading-relaxed">{L(pr.title)}</h3>
                    <p className="line-clamp-3 text-[13.5px] text-[#565E66]">{L(pr.result)}</p>
                    <span className="mt-auto pt-3 text-[12.5px] text-[#8A9199]">{lang === 'fa' ? 'از: ' : 'by: '}{L(pr.client)}</span>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}
      {sec.showPartners !== false && partners10.length > 0 && (
        <section className="py-14 md:py-16">
          <div className="wrap">
            <div className="rv rounded-card border border-mist-200 bg-white p-6 shadow-card">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-[13px] font-bold uppercase tracking-wide text-[#8A9199]">{t('partners_t')}</h3>
                <Link className="link-more !text-[13px]" to="/partners">{t('view_all')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
              </div>
              <div className="marquee marquee-hover " style={{ '--speed': '42s' }}>
                <div className="marquee-track">
                  {marqueePartners}
                  {marqueePartners}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}
      {sec.showNews !== false && news3.length > 0 && (
        <section className="bg-white py-16 md:py-24">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('nav_news')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('nav_news')}</h2>
                <p className="mt-2 text-[#565E66]">{t('news_d')}</p>
              </div>
              <Link className="btn-line btn-sm" to="/news">{t('view_all')}</Link>
            </div>
            <div className="home-news-list grid gap-6 md:grid-cols-3">
              {news3.map((n, i) => (
                <div key={n.id} className={`rv rv-d${i + 1}`}>
                  <Link className="kb-news-card card group flex h-full flex-col overflow-hidden no-underline" to={`/news/${n.id}/`}>
                    <div className="kb-card-media relative aspect-[16/9] overflow-hidden bg-mist-100">
                      <img src={n.image} alt={L(n.title)} loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                      {n.featured && <span className="absolute start-3 top-3 rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured', lang === 'fa' ? 'ویژه' : 'Featured')}</span>}
                    </div>
                    <div className="kb-card-content flex flex-1 flex-col gap-2 p-5">
                      <div className="kb-card-meta flex items-center gap-3 text-[12px] text-[#8A9199]">
                        <time dateTime={n.date}>{n.date}</time>
                        <span className="rounded-full bg-mist-100 px-2 py-0.5 text-[10.5px] font-bold text-[#565E66]">{newsCat(n.category, lang)}</span>
                      </div>
                      <h3 className="text-[16px] leading-relaxed">{L(n.title)}</h3>
                      <p className="line-clamp-2 text-[13.5px] text-[#565E66]">{L(n.excerpt)}</p>
                      <span className="mt-auto flex items-center justify-between gap-3 pt-3">
                        <span className="text-[13px] font-bold text-ink transition-colors group-hover:text-brass-dark">{t('read_more', lang === 'fa' ? 'ادامه مطلب' : 'Read more')}</span>
                        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-brass-pale text-brass-dark transition-colors group-hover:bg-brass group-hover:text-white"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></span>
                      </span>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
      {sec.showGallery !== false && gallery.length > 0 && (
        <section className="band-dark relative overflow-hidden py-14 md:py-16">
          <span aria-hidden="true" className="mouse-glow " style={{ '--glow': 'rgba(238, 139, 108, .10)', '--gs': '700px' }}></span>
          <div className="wrap relative z-[2] mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="eyebrow mb-2 !text-brass">{lang === 'fa' ? 'تصاویر' : 'Pictures'}</div>
              <h2 className="text-white" style={{ fontSize: 'clamp(22px, 2.4vw, 30px)' }}>{t('gallery_t')}</h2>
              <p className="mt-2 text-mist-300">{lang === 'fa' ? 'لحظه‌هایی از فعالیت‌ها، محموله‌ها و دفتر ما.' : 'Moments from our operations, shipments and office.'}</p>
            </div>
            <Link className="btn-ghost-light btn-sm" to="/gallery">{t('view_all')}</Link>
          </div>
          <div className="marquee marquee-hover relative z-[2]" style={{ '--speed': '52s' }}>
            <div className="marquee-track">
              <div className="marquee-group">
                {gallery.map((g, i) => (
                  <figure key={i} className="zoom-hover group relative w-[260px] shrink-0 overflow-hidden rounded-card border border-white/10 md:w-[330px]">
                    <img src={g.image} alt={L(g.caption)} loading="lazy" className="aspect-[4/3] w-full object-cover" />
                    <figcaption className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/92 to-transparent px-4 pb-3 pt-10 text-[12.5px] font-bold text-white opacity-0 transition-opacity duration-300 group-hover:opacity-100">{L(g.caption)}</figcaption>
                  </figure>
                ))}
              </div>
              <div className="marquee-group">
                {gallery.map((g, i) => (
                  <figure key={'b' + i} className="zoom-hover group relative w-[260px] shrink-0 overflow-hidden rounded-card border border-white/10 md:w-[330px]">
                    <img src={g.image} alt={L(g.caption)} loading="lazy" className="aspect-[4/3] w-full object-cover" />
                    <figcaption className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/92 to-transparent px-4 pb-3 pt-10 text-[12.5px] font-bold text-white opacity-0 transition-opacity duration-300 group-hover:opacity-100">{L(g.caption)}</figcaption>
                  </figure>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}
      {sec.showDownloads !== false && profileDoc && (
        <section className="py-12 md:py-14">
          <div className="wrap">
            <div className="card flex flex-wrap items-center justify-between gap-6 p-6 md:p-8">
              <div className="flex items-center gap-4">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brass-pale text-brass-dark"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg></span>
                <div>
                  <h2 className="text-[18px]">{L(profileDoc.title)}</h2>
                  <p className="text-[13.5px] text-[#565E66]">{t('profile_d')}</p>
                </div>
              </div>
              <Link to={profileDoc.file} target="_blank" rel="noopener noreferrer" className="btn-ink">{t('download_l')} <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg></Link>
            </div>
          </div>
        </section>
      )}
      <section className="band-dark relative py-16 md:py-20">
        <span aria-hidden="true" className="mouse-glow " style={{ '--glow': 'rgba(238, 139, 108, .10)', '--gs': '560px' }}></span>
        <div className="wrap relative z-[2] grid items-center gap-10 md:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
          <div className="rv">
            <div className="eyebrow mb-3 !text-brass">{t('contact_t')}</div>
            <h2 className="mb-4 text-white" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'برای شروع گفتگوی تجارتی آماده‌ایم' : 'Ready to start a trade conversation'}</h2>
            <p className="mb-6 max-w-[46ch] text-[15px] leading-relaxed text-mist-300">{t('quote_d')}</p>
            <div className="relative aspect-[16/9] overflow-hidden rounded-xl2 border border-white/12">
              <img src="/images/trade-cargo.webp" alt="" loading="lazy" className="kenburns h-full w-full object-cover" />
              <span className="v-text absolute inset-y-0 start-0 grid w-10 place-items-center bg-ink/72 text-[11px] font-bold uppercase tracking-[.22em] text-mist-100 backdrop-blur-sm">{lang === 'fa' ? 'درخواست همکاری' : 'Request a quote'}</span>
            </div>
            <ul className="mt-6 grid gap-2.5 text-[14px] text-mist-200">
              {contact.email && <li className="flex items-center gap-2.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brass"><rect width="20" height="16" x="2" y="4" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></svg>{contact.email}</li>}
              {L(contact.hours) && <li className="flex items-center gap-2.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brass"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>{L(contact.hours)}</li>}
              {contact.phone && <li className="flex items-center gap-2.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brass"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" /></svg>{contact.phone}</li>}
            </ul>
          </div>
          <form className="rv glass p-6 md:p-8" noValidate="" onSubmit={submit}>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label !text-mist-200" htmlFor="q-name">{lang === 'fa' ? 'نام و تخلص *' : 'Full name *'}</label>
                <input id="q-name" className="field !bg-white/10 !border-white/20 !text-white placeholder:!text-mist-300" placeholder={lang === 'fa' ? 'نام کامل شما' : 'Your full name'} autoComplete="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <label className="label !text-mist-200" htmlFor="q-phone">{lang === 'fa' ? 'شمارهٔ تماس *' : 'Phone number *'}</label>
                <input id="q-phone" className="field !bg-white/10 !border-white/20 !text-white placeholder:!text-mist-300" placeholder={lang === 'fa' ? 'مثال: ۰۷۹۱۲۳۴۵۶' : 'e.g. +93 799 123 456'} autoComplete="tel" dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div className="sm:col-span-2">
                <label className="label !text-mist-200" htmlFor="q-email">{lang === 'fa' ? 'ایمیل (اختیاری)' : 'Email (optional)'}</label>
                <input id="q-email" type="email" className="field !bg-white/10 !border-white/20 !text-white placeholder:!text-mist-300" placeholder="name@example.com" autoComplete="email" dir="ltr" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="sm:col-span-2">
                <label className="label !text-mist-200" htmlFor="q-msg">{lang === 'fa' ? 'متن پیام' : 'Message'}</label>
                <textarea id="q-msg" rows="4" className="field resize-y !bg-white/10 !border-white/20 !text-white placeholder:!text-mist-300" placeholder={lang === 'fa' ? 'پیام خود را بنویسید…' : 'Write your message…'} value={form.msg} onChange={(e) => setForm({ ...form, msg: e.target.value })}></textarea>
              </div>
            </div>
            <input type="text" name="website" tabIndex="-1" autoComplete="off" aria-hidden="true" className="absolute h-0 w-0 overflow-hidden opacity-0" value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} />
            <div className="mt-5 flex flex-wrap items-center gap-4">
              <button type="submit" className="btn-coral">{lang === 'fa' ? 'ارسال پیام' : 'Send message'} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></button>
              {sent && <span className="text-[13px] font-bold text-mist-100">{lang === 'fa' ? 'پیام شما ثبت شد؛ سپاس.' : 'Message recorded; thank you.'}</span>}
              <span className="text-[12.5px] text-mist-300">{t('privacy_note')}</span>
            </div>

          </form>
        </div>
      </section>
    </main>
  )
}

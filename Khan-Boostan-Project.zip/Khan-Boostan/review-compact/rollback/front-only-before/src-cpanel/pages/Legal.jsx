import { useReveal } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero } from '../parts.jsx'

// Legal text is transcribed from the local cPanel phase-14 bundle, unchanged.
const COPY = {
  privacy: {
    fa: [
      ['چه معلوماتی جمع می‌شود', 'وقتی از فرم تماس استفاده می‌کنید، نام، نام شرکت (اختیاری)، شماره تماس، ایمیل (اختیاری)، موضوع و متن پیام شما ثبت می‌شود تا بتوانیم پاسخ بدهیم. هیچ کوکی ردیابی تبلیغاتی استفاده نمی‌شود.'],
      ['کاربرد معلومات', 'معلومات ارسال‌شده فقط برای پاسخ به درخواست شما، پیگیری همکاری و اطلاع‌رسانی مرتبط استفاده می‌شود و در اختیار اشخاص ثالث قرار نمی‌گیرد.'],
      ['نگهداری و دسترسی', 'پیام‌ها در دیتابیس داخلی شرکت نگهداری می‌شود و تنها کارمندان مجاز به آن دسترسی دارند.'],
      ['حذف معلومات', 'برای درخواست حذف پیام‌های خود، از صفحهٔ تماس با ما در ارتباط شوید.'],
    ],
    en: [
      ['What we collect', 'When you use the contact form we store your name, optional company name, phone, optional email, subject and message so we can respond. No advertising or tracking cookies are used.'],
      ['How it is used', 'Submitted details are used only to respond to your request, follow up on cooperation and send related updates. They are not shared with third parties.'],
      ['Storage & access', 'Messages are stored in the company internal database and accessible only to authorised staff.'],
      ['Deletion', 'To request deletion of your messages, contact us via the contact page.'],
    ],
  },
  terms: {
    fa: [
      ['محتوای سایت', 'محتوای این سایت برای معرفی فعالیت‌های شرکت است و پیشنهاد قیمت یا قرارداد محسوب نمی‌شود.'],
      ['درخواست‌ها', 'ثبت درخواست به معنای پذیرش تعهد از سوی شرکت نیست؛ شرایط هر معامله جداگانه توافق می‌شود.'],
      ['کوکی‌ها', 'این سایت تنها از کوکی ضروری برای عملکرد خود (مانند ورود مدیران) استفاده می‌کند؛ کوکی ردیابی یا تبلیغاتی به کار نمی‌رود.'],
      ['مالکیت', 'نام و نشان خان بوستان متعلق به شرکت است؛ استفاده بدون اجازه مجاز نیست.'],
    ],
    en: [
      ['Site content', 'Content on this site introduces company activities and is not a price offer or a contract.'],
      ['Requests', 'Submitting a request creates no obligation; terms of each deal are agreed separately.'],
      ['Cookies', 'This site uses only essential cookies for its own operation (such as admin sign-in); no tracking or advertising cookies are used.'],
      ['Ownership', 'The Khan Boostan name and mark belong to the company; unauthorised use is not permitted.'],
    ],
  },
}

export default function Legal({ kind }) {
  const { t, lang } = useDict()
  useReveal()
  const key = kind === 'terms' ? 'nav_terms' : 'nav_privacy'
  const blocks = COPY[kind === 'terms' ? 'terms' : 'privacy'][lang === 'en' ? 'en' : 'fa']
  return <main id="main" className="site-legal flex-1">
    <Hero image="/images/trade-detail.webp" crumbs={[[null, t(key)]]} title={t(key)} />
    <section className="py-12 md:py-16"><div className="wrap-narrow grid gap-6">
      {blocks.map(([heading, paragraph]) => <div className="rv card p-6 md:p-7" key={heading}>
        <h2 className="mb-2 text-[18px]">{heading}</h2>
        <p className="whitespace-pre-line text-[15px] text-slate-600">{paragraph}</p>
      </div>)}
    </div></section>
  </main>
}

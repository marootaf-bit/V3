import { useEffect } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import { useContent } from '../src/lib/store.jsx'
import { ScrollProgress } from '../src/lib/motion.jsx'
import AdminRoot from '../src/admin/Admin.jsx'
import { useDict } from './lib.jsx'
import PageMeta from './PageMeta.jsx'
import Header from './shell/Header.jsx'
import Footer from './shell/Footer.jsx'
import Home from './pages/Home.jsx'
import About, { TeamRedirect } from './pages/About.jsx'
import Activities from './pages/Activities.jsx'
import TradePage from './pages/TradePage.jsx'
import Process from './pages/Process.jsx'
import Products from './pages/Products.jsx'
import ProductDetail from './pages/ProductDetail.jsx'
import News from './pages/News.jsx'
import NewsDetail from './pages/NewsDetail.jsx'
import Gallery from './pages/Gallery.jsx'
import Partners from './pages/Partners.jsx'
import Projects from './pages/Projects.jsx'
import Contact from './pages/Contact.jsx'
import Downloads from './pages/Downloads.jsx'
import Careers from './pages/Careers.jsx'
import Legal from './pages/Legal.jsx'
import NotFound from './pages/NotFound.jsx'
import './site-polish.css'
import './premium-site.css'
import './compact-site.css'

function ScrollToTop() {
  const { pathname, hash } = useLocation()
  useEffect(() => {
    if (hash) {
      const id = hash.slice(1)
      requestAnimationFrame(() => {
        const el = document.getElementById(id)
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
        else window.scrollTo({ top: 0, behavior: 'instant' })
      })
      return
    }
    window.scrollTo({ top: 0, behavior: 'instant' })
  }, [pathname, hash])
  return null
}

function ErrorState() {
  const { t } = useDict()
  const { reload } = useContent()
  return (
    <main id="main" className="grid min-h-[60vh] place-items-center px-6 text-center">
      <div>
        <span className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-full bg-brass-pale text-brass-dark"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M2 12h20" /><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg></span>
        <h1 className="mb-2 text-[24px]">{t('error_t')}</h1>
        <p className="mb-6 text-slate-500">{t('error_d')}</p>
        <button className="btn-ink" onClick={reload}>{t('retry')}</button>
      </div>
    </main>
  )
}

function PremiumReveals({ data }) {
  const { pathname } = useLocation()
  useEffect(() => {
    if (!data || !['/about', '/partners'].includes(pathname) ||
        !('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const selector = '.kb-pages .kb-section .wrap > :is(.kb-section-head,.kb-intro-grid,.kb-scope-grid,.kb-purpose-grid,.kb-values-grid,.kb-message-grid,.kb-team-grid,.kb-teaser-grid,.kb-relations-intro-grid,.kb-filters,.kb-entity-grid,.kb-brand-grid)'
    const targets = [...document.querySelectorAll(selector)]
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) if (entry.isIntersecting) {
        entry.target.classList.add('premium-visible')
        observer.unobserve(entry.target)
      }
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.08 })
    for (const target of targets) { target.classList.add('premium-reveal'); observer.observe(target) }
    return () => { observer.disconnect(); targets.forEach((target) => target.classList.remove('premium-reveal')) }
  }, [data, pathname])
  return null
}

function SiteShell() {
  const { error, data } = useContent()
  return (
    <div className="public-site flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-[60] focus:bg-ink focus:px-4 focus:py-2 focus:text-white">skip</a>
      <ScrollProgress />
      <PremiumReveals data={data} />
      <PageMeta />
      <Header />
      {error ? <ErrorState /> : <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/team" element={<TeamRedirect />} />
        <Route path="/activities" element={<Activities />} />
        <Route path="/import" element={<TradePage kind="import" />} />
        <Route path="/export" element={<TradePage kind="export" />} />
        <Route path="/process" element={<Process />} />
        <Route path="/products" element={<Products />} />
        <Route path="/products/:slug" element={<ProductDetail />} />
        <Route path="/news" element={<News />} />
        <Route path="/news/:slug" element={<NewsDetail />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/partners" element={<Partners />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/downloads" element={<Downloads />} />
        <Route path="/careers" element={<Careers />} />
        <Route path="/privacy" element={<Legal kind="privacy" />} />
        <Route path="/terms" element={<Legal kind="terms" />} />
        <Route path="*" element={<NotFound />} />
      </Routes>}
      <Footer />
    </div>
  )
}

export default function App() {
  return <>
    <ScrollToTop />
    <Routes>
      <Route path="/admin/*" element={<AdminRoot />} />
      <Route path="/*" element={<SiteShell />} />
    </Routes>
  </>
}

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  root: 'src-cpanel',
  plugins: [react()],
  build: { outDir: '../build-cpanel', emptyOutDir: true },
})

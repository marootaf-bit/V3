<?php
/**
 * Khan Boostan — content API (v1)
 * Plain PHP 8 + SQLite. No framework, no composer.
 *
 *   Public : GET  /api/content            all published content (one payload)
 *            POST /api/requests           quote / contact / part / service requests
 *   Admin  : POST /api/admin/login|logout  GET /api/admin/me   POST /api/admin/password
 *            GET|POST /api/admin/collections/{c}   PUT|DELETE /api/admin/collections/{c}/{id}
 *            POST /api/admin/collections/{c}/reorder
 *            GET /api/admin/requests  PATCH|DELETE /api/admin/requests/{id}
 *            GET|PUT /api/admin/settings   POST /api/admin/upload   GET /api/admin/stats
 *            POST /api/admin/seed
 *
 * Data lives OUTSIDE the web root: /home/grandtir/shantui-data/
 */
declare(strict_types=1);

define('DATA_DIR', getenv('KB_DATA') ?: '/home/grandtir/khanboostan-data');
const DB_FILE     = DATA_DIR . '/khanboostan.sqlite';
const UPLOAD_DIR  = __DIR__ . '/../uploads';          // web-reachable: /uploads/...
const UPLOAD_URL  = '/uploads';
const ADMIN_EMAIL = 'alisinarajabi08@gmail.com';
const SITE_NAME   = 'Khan Boostan';
const COLLECTIONS = ['categories','products','news','facts','partners','team','documents','projects','testimonials','jobs','gallery','faq','brands'];
const DEMO_FILTERED = ['products','partners','projects','testimonials','documents','team','brands','gallery'];
const SETTING_KEYS = ['company','contact','hero','pages','sections','seo','about','activities'];
const MAX_UPLOAD  = 8 * 1024 * 1024;

// ------------------------------------------------------------------ bootstrap
@mkdir(DATA_DIR, 0700, true); @mkdir(DATA_DIR . '/sessions', 0700, true); @mkdir(UPLOAD_DIR, 0755, true);
ini_set('session.save_path', DATA_DIR . '/sessions');
ini_set('session.use_strict_mode', '1');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'), 'httponly' => true, 'samesite' => 'Lax']);
session_name('kb_admin');

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

function json(mixed $data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function fail(string $msg, int $code = 400, array $extra = []): never { json(['error' => $msg] + $extra, $code); }
function body(): array { $raw = file_get_contents('php://input'); $d = $raw ? json_decode($raw, true) : []; return is_array($d) ? $d : []; }
function now(): string { return gmdate('c'); }
function slugify(string $s): string { $s = strtolower(trim($s)); $s = preg_replace('/[^a-z0-9\x{0600}-\x{06FF}]+/u', '-', $s); return trim((string)$s, '-') ?: bin2hex(random_bytes(4)); }

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $fresh = !is_file(DB_FILE);
    $pdo = new PDO('sqlite:' . DB_FILE, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $pdo->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=4000;');
    $pdo->exec('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pass TEXT NOT NULL, name TEXT, created_at TEXT, last_login TEXT);
        CREATE TABLE IF NOT EXISTS items (id TEXT NOT NULL, collection TEXT NOT NULL, sort INTEGER DEFAULT 0, status TEXT DEFAULT "published", data TEXT NOT NULL, created_at TEXT, updated_at TEXT, PRIMARY KEY (collection, id));
        CREATE INDEX IF NOT EXISTS idx_items_col ON items(collection, status, sort);
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, name TEXT, phone TEXT, email TEXT, subject TEXT, machine TEXT, message TEXT, lang TEXT, meta TEXT, status TEXT DEFAULT "new", ip TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS logins (ip TEXT PRIMARY KEY, fails INTEGER DEFAULT 0, last TEXT);');
    if ($fresh || !$pdo->query('SELECT COUNT(*) c FROM users')->fetch()['c']) {
        $pw = 'KhanBoostan@' . date('Y') . '!';
        $pdo->prepare('INSERT OR IGNORE INTO users(email, pass, name, created_at) VALUES(?,?,?,?)')->execute([ADMIN_EMAIL, password_hash($pw, PASSWORD_DEFAULT), 'Administrator', now()]);
        @file_put_contents(DATA_DIR . '/INITIAL-PASSWORD.txt', "email: " . ADMIN_EMAIL . "\npassword: {$pw}\nChange it from Dashboard → Account.\n");
    }
    return $pdo;
}
function setting(string $k, mixed $default = null): mixed {
    $r = db()->prepare('SELECT value FROM settings WHERE key=?'); $r->execute([$k]); $v = $r->fetchColumn();
    return $v === false ? $default : json_decode((string)$v, true);
}
function setSetting(string $k, mixed $v): void {
    db()->prepare('INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at')->execute([$k, json_encode($v, JSON_UNESCAPED_UNICODE), now()]);
}
function rows(string $col, bool $publishedOnly): array {
    $sql = 'SELECT id, sort, status, data, updated_at FROM items WHERE collection=?' . ($publishedOnly ? " AND status='published'" : '') . ' ORDER BY sort ASC, created_at ASC';
    $st = db()->prepare($sql); $st->execute([$col]);
    $out = [];
    foreach ($st as $r) { $d = json_decode($r['data'], true) ?: []; $d['id'] = $r['id']; if (!$publishedOnly) { $d['_status'] = $r['status']; $d['_sort'] = (int)$r['sort']; $d['_updated'] = $r['updated_at']; } $out[] = $d; }
    return $out;
}
function requireAuth(): array {
    session_start();
    if (empty($_SESSION['uid'])) fail('Unauthorized', 401);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET' && ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'fetch') fail('Bad request origin', 403);
    return ['uid' => (int)$_SESSION['uid'], 'email' => $_SESSION['email'] ?? ''];
}
function clientIp(): string { return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'); }
function throttle(int $max = 8, int $window = 900): void {
    $ip = clientIp(); $r = db()->prepare('SELECT fails, last FROM logins WHERE ip=?'); $r->execute([$ip]); $row = $r->fetch();
    if ($row && (int)$row['fails'] >= $max && time() - strtotime($row['last']) < $window) fail('Too many attempts. Try again in 15 minutes.', 429);
}
function loginFail(): void { db()->prepare('INSERT INTO logins(ip,fails,last) VALUES(?,1,?) ON CONFLICT(ip) DO UPDATE SET fails=fails+1, last=excluded.last')->execute([clientIp(), now()]); }
function loginOk(): void { db()->prepare('DELETE FROM logins WHERE ip=?')->execute([clientIp()]); }
function str(mixed $v, int $max = 2000): string { return mb_substr(trim(is_scalar($v) ? (string)$v : ''), 0, $max); }

// ------------------------------------------------------------------ routing
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = preg_replace('#^/api/?#', '', $path);
$seg = array_values(array_filter(explode('/', trim($path, '/')), 'strlen'));
$r0 = $seg[0] ?? '';

try {
// ===================================================================== PUBLIC
if ($r0 === 'content' && $method === 'GET') {
    $out = ['generatedAt' => now(), 'settings' => []];
    foreach (SETTING_KEYS as $k) $out['settings'][$k] = (object)setting($k, []);
    foreach (COLLECTIONS as $c) $out[$c] = rows($c, true);
    $showDemo = (bool)(setting('sections', [])['showDemo'] ?? true);
    if (!$showDemo) foreach (DEMO_FILTERED as $c) $out[$c] = array_values(array_filter($out[$c], fn($p) => empty($p['demo'])));
    $etag = '"' . md5(json_encode($out)) . '"';
    header('ETag: ' . $etag); header('Cache-Control: no-cache');
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }
    json($out);
}
if (($r0 === 'requests' || $r0 === 'contact') && $method === 'POST') {
    $b = body();
    if (str($b['website'] ?? '') !== '') json(['ok' => true]); // honeypot
    $name = str($b['name'] ?? '', 120); $phone = str($b['phone'] ?? '', 40); $message = str($b['message'] ?? '', 4000);
    if ($name === '' || $phone === '') fail('name and phone are required', 422);
    $kind = in_array($b['kind'] ?? '', ['contact','product','cooperation'], true) ? $b['kind'] : 'contact';
    // rate: max 10 per IP per hour
    $c = db()->prepare("SELECT COUNT(*) FROM requests WHERE ip=? AND created_at > ?"); $c->execute([clientIp(), gmdate('c', time() - 3600)]);
    if ((int)$c->fetchColumn() >= 10) fail('Too many requests', 429);
    $meta = is_array($b['meta'] ?? null) ? array_slice($b['meta'], 0, 20) : [];
    db()->prepare('INSERT INTO requests(kind,name,phone,email,subject,machine,message,lang,meta,status,ip,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$kind, $name, $phone, str($b['email'] ?? '', 160), str($b['subject'] ?? '', 160), str($b['machine'] ?? '', 200), $message, str($b['lang'] ?? 'fa', 5), json_encode($meta, JSON_UNESCAPED_UNICODE), 'new', clientIp(), now()]);
    $id = (int)db()->lastInsertId();
    // e-mail notification (best effort)
    $to = setting('contact')['notifyEmail'] ?? ADMIN_EMAIL;
    if (filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $subj = '=?UTF-8?B?' . base64_encode("[" . SITE_NAME . "] New {$kind} request #{$id} — {$name}") . '?=';
        $lines = ["New {$kind} request #{$id}", '', "Name: {$name}", "Phone: {$phone}", "Email: " . str($b['email'] ?? ''), "Subject: " . str($b['subject'] ?? ''), "Machine / part: " . str($b['machine'] ?? ''), '', $message, '', 'Open the panel: https://' . ($_SERVER['HTTP_HOST'] ?? 'khanboostan.grandtire.af') . '/admin/'];
        $host = $_SERVER['HTTP_HOST'] ?? 'grandtire.af';
        @mail($to, $subj, implode("\r\n", $lines), "From: " . SITE_NAME . " <no-reply@" . preg_replace('/^www\./', '', (string)$host) . ">\r\nContent-Type: text/plain; charset=UTF-8\r\nX-Mailer: khanboostan-api");
    }
    json(['ok' => true, 'id' => $id], 201);
}

// ===================================================================== ADMIN
if ($r0 !== 'admin') fail('Not found', 404);
$r1 = $seg[1] ?? ''; $r2 = $seg[2] ?? null; $r3 = $seg[3] ?? null;

if ($r1 === 'login' && $method === 'POST') {
    throttle();
    $b = body(); $email = strtolower(str($b['email'] ?? '', 160)); $pw = (string)($b['password'] ?? '');
    $st = db()->prepare('SELECT * FROM users WHERE email=?'); $st->execute([$email]); $u = $st->fetch();
    if (!$u || !password_verify($pw, $u['pass'])) { loginFail(); usleep(400000); fail('Invalid email or password', 401); }
    loginOk(); session_start(); session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id']; $_SESSION['email'] = $u['email'];
    db()->prepare('UPDATE users SET last_login=? WHERE id=?')->execute([now(), $u['id']]);
    json(['ok' => true, 'user' => ['email' => $u['email'], 'name' => $u['name']]]);
}
if ($r1 === 'logout') { session_start(); $_SESSION = []; session_destroy(); json(['ok' => true]); }
if ($r1 === 'me' && $method === 'GET') { session_start(); if (empty($_SESSION['uid'])) json(['user' => null]); json(['user' => ['email' => $_SESSION['email'] ?? '']]); }

$auth = requireAuth();

if ($r1 === 'password' && $method === 'POST') {
    $b = body(); $st = db()->prepare('SELECT * FROM users WHERE id=?'); $st->execute([$auth['uid']]); $u = $st->fetch();
    if (!$u || !password_verify((string)($b['current'] ?? ''), $u['pass'])) fail('Current password is wrong', 422);
    $new = (string)($b['new'] ?? ''); if (strlen($new) < 10) fail('New password must be at least 10 characters', 422);
    db()->prepare('UPDATE users SET pass=? WHERE id=?')->execute([password_hash($new, PASSWORD_DEFAULT), $u['id']]);
    if (!empty($b['email']) && filter_var($b['email'], FILTER_VALIDATE_EMAIL)) db()->prepare('UPDATE users SET email=? WHERE id=?')->execute([strtolower($b['email']), $u['id']]);
    @unlink(DATA_DIR . '/INITIAL-PASSWORD.txt');
    json(['ok' => true]);
}
if ($r1 === 'stats' && $method === 'GET') {
    $out = ['collections' => [], 'requests' => []];
    foreach (COLLECTIONS as $c) { $s = db()->prepare("SELECT COUNT(*) t, SUM(status='published') p FROM items WHERE collection=?"); $s->execute([$c]); $out['collections'][$c] = $s->fetch(); }
    foreach (db()->query("SELECT status, COUNT(*) n FROM requests GROUP BY status") as $r) $out['requests'][$r['status']] = (int)$r['n'];
    $out['recent'] = db()->query('SELECT id, kind, name, phone, machine, subject, status, created_at FROM requests ORDER BY id DESC LIMIT 8')->fetchAll();
    $since = gmdate('Y-m-d', time() - 13 * 86400);
    $daily = []; for ($i = 13; $i >= 0; $i--) $daily[gmdate('Y-m-d', time() - $i * 86400)] = 0;
    foreach (db()->query("SELECT substr(created_at,1,10) d, COUNT(*) n FROM requests WHERE created_at >= '{$since}' GROUP BY d") as $r) if (isset($daily[$r['d']])) $daily[$r['d']] = (int)$r['n'];
    $out['daily'] = $daily;
    $out['byKind'] = []; foreach (db()->query('SELECT kind, COUNT(*) n FROM requests GROUP BY kind') as $r) $out['byKind'][$r['kind']] = (int)$r['n'];
    $out['total'] = (int)db()->query('SELECT COUNT(*) FROM requests')->fetchColumn();
    $out['uploads'] = count(glob(UPLOAD_DIR . '/*/*/*.*') ?: []);
    $out['initialPasswordFile'] = is_file(DATA_DIR . '/INITIAL-PASSWORD.txt');
    json($out);
}
if ($r1 === 'settings') {
    if ($method === 'GET') { $o = []; foreach (SETTING_KEYS as $k) $o[$k] = (object)setting($k, []); json($o); }
    if ($method === 'PUT') { $b = body(); foreach (SETTING_KEYS as $k) if (isset($b[$k]) && is_array($b[$k])) setSetting($k, $b[$k]); json(['ok' => true]); }
}
if ($r1 === 'collections' && $r2 && in_array($r2, COLLECTIONS, true)) {
    $col = $r2;
    if ($method === 'GET' && !$r3) json(rows($col, false));
    if ($method === 'POST' && $r3 === 'reorder') {
        $ids = body()['ids'] ?? []; if (!is_array($ids)) fail('ids[] required');
        $st = db()->prepare('UPDATE items SET sort=? WHERE collection=? AND id=?'); $i = 0; foreach ($ids as $id) $st->execute([$i++, $col, (string)$id]);
        json(['ok' => true]);
    }
    if ($method === 'POST' && !$r3) {
        $b = body(); $data = is_array($b['data'] ?? null) ? $b['data'] : [];
        $id = slugify(mb_substr(str($b['id'] ?? ($data['slug'] ?? (($data['name']['en'] ?? $data['title']['en'] ?? $data['name']['fa'] ?? $data['title']['fa'] ?? '') ?: bin2hex(random_bytes(4))))), 0, 80));
        $chk = db()->prepare('SELECT 1 FROM items WHERE collection=? AND id=?'); $chk->execute([$col, $id]); if ($chk->fetch()) $id .= '-' . substr(bin2hex(random_bytes(2)), 0, 3);
        unset($data['id'], $data['_status'], $data['_sort'], $data['_updated']);
        $max = (int)db()->query("SELECT COALESCE(MAX(sort),-1) FROM items WHERE collection='" . $col . "'")->fetchColumn();
        db()->prepare('INSERT INTO items(id,collection,sort,status,data,created_at,updated_at) VALUES(?,?,?,?,?,?,?)')->execute([$id, $col, $max + 1, in_array($b['status'] ?? '', ['draft','published'], true) ? $b['status'] : 'published', json_encode($data, JSON_UNESCAPED_UNICODE), now(), now()]);
        json(['ok' => true, 'id' => $id], 201);
    }
    if ($r3 && $method === 'PUT') {
        $b = body(); $data = is_array($b['data'] ?? null) ? $b['data'] : null; $sets = []; $vals = [];
        if ($data !== null) { unset($data['id'], $data['_status'], $data['_sort'], $data['_updated']); $sets[] = 'data=?'; $vals[] = json_encode($data, JSON_UNESCAPED_UNICODE); }
        if (isset($b['status']) && in_array($b['status'], ['draft','published'], true)) { $sets[] = 'status=?'; $vals[] = $b['status']; }
        if (!$sets) fail('nothing to update');
        $sets[] = 'updated_at=?'; $vals[] = now(); $vals[] = $col; $vals[] = $r3;
        $st = db()->prepare('UPDATE items SET ' . implode(',', $sets) . ' WHERE collection=? AND id=?'); $st->execute($vals);
        if (!$st->rowCount()) fail('Not found', 404);
        json(['ok' => true]);
    }
    if ($r3 && $method === 'DELETE') { $st = db()->prepare('DELETE FROM items WHERE collection=? AND id=?'); $st->execute([$col, $r3]); json(['ok' => true, 'deleted' => $st->rowCount()]); }
}
if ($r1 === 'requests') {
    if ($method === 'GET' && !$r2) {
        $status = $_GET['status'] ?? ''; $w = in_array($status, ['new','read','done'], true) ? "WHERE status='{$status}'" : '';
        $list = db()->query("SELECT * FROM requests {$w} ORDER BY id DESC LIMIT 500")->fetchAll();
        foreach ($list as &$r) $r['meta'] = json_decode((string)$r['meta'], true) ?: [];
        json($list);
    }
    if ($r2 && $method === 'PATCH') { $s = body()['status'] ?? ''; if (!in_array($s, ['new','read','done'], true)) fail('bad status'); db()->prepare('UPDATE requests SET status=? WHERE id=?')->execute([$s, (int)$r2]); json(['ok' => true]); }
    if ($r2 && $method === 'DELETE') { db()->prepare('DELETE FROM requests WHERE id=?')->execute([(int)$r2]); json(['ok' => true]); }
}
if ($r1 === 'upload' && $method === 'POST') {
    if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) fail('file missing');
    $f = $_FILES['file']; if ($f['size'] > MAX_UPLOAD) fail('File too large (max 8 MB)', 413);
    $info = @getimagesize($f['tmp_name']);
    if (($_GET['kind'] ?? '') === 'file') {
        // documents: PDF only (checked by magic bytes, not by client-supplied name)
        $head = file_get_contents($f['tmp_name'], false, null, 0, 5);
        if ($head !== '%PDF-') fail('Only PDF documents are accepted', 415);
        $ext = 'pdf'; $info = [0, 0];
    } else {
        if (!$info) fail('Not an image', 415);
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif', 'image/svg+xml' => 'svg'][$info['mime']] ?? null; if (!$ext) fail('Unsupported image type', 415);
    }
    $dir = UPLOAD_DIR . '/' . date('Y/m'); @mkdir($dir, 0755, true);
    $name = date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], "$dir/$name")) fail('Could not store file', 500);
    @chmod("$dir/$name", 0644);
    json(['ok' => true, 'url' => UPLOAD_URL . '/' . date('Y/m') . '/' . $name, 'width' => $info[0], 'height' => $info[1]], 201);
}
if ($r1 === 'seed' && $method === 'POST') {
    $b = body(); $replace = !empty($_GET['replace']);
    $pdo = db(); $pdo->beginTransaction();
    $n = 0;
    foreach (COLLECTIONS as $c) {
        if (!isset($b[$c]) || !is_array($b[$c])) continue;
        if ($replace) $pdo->prepare('DELETE FROM items WHERE collection=?')->execute([$c]);
        $st = $pdo->prepare('INSERT OR REPLACE INTO items(id,collection,sort,status,data,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
        foreach (array_values($b[$c]) as $i => $item) { $id = (string)($item['id'] ?? ($item['img'] ?? ($item['photo'] ?? "item-$i"))); $id = slugify(basename($id)); unset($item['id']); $status = in_array($item['_status'] ?? '', ['draft','published'], true) ? $item['_status'] : 'published'; unset($item['_status']); $st->execute([$id, $c, $i, $status, json_encode($item, JSON_UNESCAPED_UNICODE), now(), now()]); $n++; }
    }
    if (isset($b['settings']) && is_array($b['settings'])) foreach ($b['settings'] as $k => $v) if (in_array($k, SETTING_KEYS, true)) setSetting($k, $v);
    $pdo->commit();
    json(['ok' => true, 'items' => $n]);
}
fail('Not found', 404);
} catch (Throwable $e) {
    error_log('[kb-api] ' . $e->getMessage());
    fail('Server error', 500, ['detail' => (ini_get('display_errors') ? $e->getMessage() : null)]);
}

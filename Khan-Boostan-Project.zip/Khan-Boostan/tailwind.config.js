/** @type {import('tailwindcss').Config}
 *  Design system v2 — derived from the approved references:
 *  "Colo pointer.jpg"  → graphite + coral/peach + light mist palette
 *  "Design implemention*.jpg" → dark hero panels, stat strips, process line,
 *                               dark testimonial/CTA bands, dark footer
 *  Token NAMES are kept from v1 (ink/brass/…) so page code stays stable;
 *  their VALUES now carry the new brand.
 */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // deep brand-blue family (from logo ring / #0168b4 darkened for text & dark bands)
        ink:   { DEFAULT: '#0C2E4E', 2: '#143A5C', 3: '#1D466B', 4: '#40648A' },
        // official brand gold #c4873b — accents, eyebrows, tags, marks
        brass: { DEFAULT: '#C4873B', deep: '#A97230', pale: '#F6ECDE', dark: '#8F5F26' },
        // official brand blue #0168b4 — primary actions, links, focus, active states
        brand: { DEFAULT: '#0168B4', deep: '#015A9C', dark: '#014C84', pale: '#E4F0FA' },
        // neutrals — off-white from brand board #f7f9fa
        paper:  '#FFFFFF',
        stone2: '#F5F8FA',
        mist:   { 50: '#F7F9FA', 100: '#EFF3F5', 200: '#E1E7EB', 300: '#C9D4DA' },
        rule:   { DEFAULT: '#E1E7EB', strong: '#B9C6CE' },
        // semantic
        ok:  '#2E9E6B',
        err: '#D64545'
      },
      fontFamily: {
        sans: ['"Noto Sans Arabic"', 'Tahoma', 'Arial', 'sans-serif'],
        head: ['"Noto Naskh Arabic"', '"Noto Sans Arabic"', 'Tahoma', 'serif']
      },
      boxShadow: {
        card: '0 1px 2px rgba(42,47,53,.04), 0 10px 30px -18px rgba(42,47,53,.18)',
        lift: '0 4px 10px rgba(42,47,53,.06), 0 30px 60px -28px rgba(42,47,53,.30)',
        panel: '0 24px 60px -30px rgba(20,23,26,.55)'
      },
      borderRadius: { card: '14px', xl2: '20px' }
    }
  },
  plugins: []
}

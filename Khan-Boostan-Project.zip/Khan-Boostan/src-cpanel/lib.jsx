import { createContext, useContext } from 'react'
import dict from './dict.json'
import { useLang } from '../src/lib/store.jsx'

const C = createContext(null)
// Only removes a parenthetical UI marker from a displayed product name.
// The original CMS field, demo flag and every other piece of content remain intact.
export const publicItemName = (value) => String(value ?? '').replace(/\s*\((?:نمونهٔ نمایشی|نمونه نمایشی|sample|demo)\)\s*$/iu, '').trim()

export function DictProvider({ children }) {
  const { lang } = useLang()
  const L = (v, d) => {
    if (v == null) return d ?? ''
    if (typeof v === 'string') return v
    return v[lang === 'en' ? 'en' : 'fa'] ?? v.fa ?? d ?? ''
  }
  const t = (k, d) => dict[lang === 'en' ? 'en' : 'fa'][k] ?? d ?? k
  return <C.Provider value={{ t, L, lang }}>{children}</C.Provider>
}
export const useDict = () => useContext(C)

import { Link } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero, Cta, FaqList, BoxIcon, ArrowIcon } from '../parts.jsx'

const ACT_STEPS = {
  fa: [['۰۱', 'درخواست و شناخت نیاز', 'گفتگو و تعیین مشخصات'], ['۰۲', 'بررسی و تأمین', 'انتخاب تأمین‌کننده و اعلام شفاف شرایط'], ['۰۳', 'هماهنگی و آماده‌سازی', 'کنترل کیفیت، بسته‌بندی و اسناد'], ['۰۴', 'انتقال و تحویل', 'پیگیری تا تحویل و اطلاع‌رسانی']],
  en: [['01', 'Request & scoping', 'Talk and agree specifications'], ['02', 'Review & sourcing', 'Supplier selection, transparent terms'], ['03', 'Coordination & prep', 'QC, packing and documents'], ['04', 'Delivery', 'Follow-up until delivery']],
}

export default function Activities() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  if (!data) return <div className="min-h-[70vh]" />
  const act = settings.activities ?? {}, pages = settings.pages ?? {}
  const cats = data.categories ?? []
  const industries = act.industries ?? [], markets = act.markets ?? [], principles = act.supplierPrinciples ?? []
  const projects = [...(data.projects ?? [])].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || bySort(a, b)).slice(0, 3)
  const faqs = (data.faq ?? []).slice(0, 8)
  const steps = ACT_STEPS[lang === 'en' ? 'en' : 'fa']
  const lanes = [
    { to: '/import', title: L(pages.import?.title), intro: L(pages.import?.intro), img: '/images/trade-warehouse.webp', icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1" /><path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76" /><path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6" /><path d="M12 10v4" /><path d="M12 2v3" /></svg> },
    { to: '/export', title: L(pages.export?.title), intro: L(pages.export?.intro), img: '/images/trade-cargo.webp', icon: <BoxIcon /> },
  ]
  return (
    <>
      <main id="main" className="site-activities flex-1">
        <Hero image="/images/trade-port.webp" crumbs={[[null, t('nav_activities')]]} title={t('nav_activities')} sub={L(act.sourcing)} />
        <section className="py-14 md:py-20">
          <div className="wrap grid gap-5 md:grid-cols-2">
            {lanes.map((ln, i) => (
              <Link className={`card group rv rv-d${i + 1} flex h-full flex-col overflow-hidden no-underline`} to={ln.to} key={ln.to}>
                <div className="aspect-[21/9] overflow-hidden"><img src={ln.img} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
                <div className="flex flex-1 flex-col gap-2 p-6">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-brass-pale text-brass-dark">{ln.icon}</span>
                  <h2 className="mt-1 text-[20px]">{ln.title}</h2>
                  <p className="text-[14px] leading-relaxed text-[#565E66]">{ln.intro}</p>
                  <span className="mt-auto inline-flex items-center gap-2 pt-3 text-[13.5px] font-bold text-ink group-hover:text-brass-dark">{t('view_details')} <ArrowIcon className="rtl:rotate-180" /></span>
                </div>
              </Link>
            ))}
          </div>
        </section>
        <section className="bg-white py-14 md:py-20">
          <div className="wrap">
            <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('nav_activities')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'حوزه‌ها و صنایع مورد فعالیت' : 'Fields & industries'}</h2>
              </div>
            </div>
            <div className="site-industry-grid grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {cats.map((c, i) => (
                <Link className={`rv rv-d${(i % 4) + 1} card p-6 no-underline`} to={`/products/?c=${c.id}`} key={c.id}>
                  <span className="mb-3 grid h-11 w-11 place-items-center rounded-xl bg-brass-pale text-brass-deep"><BoxIcon /></span>
                  <h3 className="mb-1.5 text-[16.5px]">{L(c.name)}</h3>
                  <p className="text-[13.5px] text-slate-500">{L(c.description)}</p>
                </Link>
              ))}
            </div>
            <div className="mt-8 grid gap-5 md:grid-cols-4">
              {industries.map((ind, i) => (
                <div className={`rv rv-d${i + 1} rounded-card border border-mist-200 bg-mist-50 p-5`} key={i}>
                  <h3 className="mb-1.5 text-[15.5px]">{L(ind.title)}</h3>
                  <p className="text-[13px] text-slate-600">{L(ind.text)}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        <section className="py-14 md:py-20">
          <div className="wrap">
            <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('method_t')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'روش همکاری: از دریافت نیاز تا انجام تعهد' : 'How we work: from need to commitment'}</h2>
              </div>
              <Link className="btn-line btn-sm" to="/process">{t('view_details')}</Link>
            </div>
            <div className="relative grid gap-8 md:grid-cols-4 md:gap-6">
              <span className="step-line inset-x-[12%] hidden md:block" aria-hidden="true"></span>
              {steps.map((s, i) => (
                <div className={`rv rv-d${i + 1} relative flex gap-4 md:flex-col md:items-center md:text-center`} key={i}>
                  <span className="step-dot">{s[0]}</span>
                  <div>
                    <h3 className="mb-1.5 text-[17px]">{s[1]}</h3>
                    <p className="text-[14px] leading-relaxed text-[#565E66]">{s[2]}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-14 grid gap-10 lg:grid-cols-2">
              <div className="rv">
                <h2 className="mb-3 text-[clamp(22px,2.4vw,30px)]">{lang === 'fa' ? 'بازارهای هدف' : 'Target markets'}</h2>
                <div className="flex flex-wrap gap-2.5">
                  {markets.map((m, i) => (
                    <span className="chip !min-h-[40px]" key={i}>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="me-1.5 h-4 w-4 text-brass-deep"><circle cx="12" cy="12" r="10" /><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" /><path d="M2 12h20" /></svg>
                      {L(m)}
                    </span>
                  ))}
                </div>
                <h2 className="mb-3 mt-9 text-[clamp(22px,2.4vw,30px)]">{lang === 'fa' ? 'همکاری با تولیدکنندگان و تأمین‌کنندگان' : 'Working with manufacturers & suppliers'}</h2>
                <ul className="grid gap-2.5">
                  {principles.map((p, i) => (
                    <li className="flex items-start gap-2.5 text-[15px] text-slate-600" key={i}>
                      <span className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brass"></span>
                      {L(p)}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rv card p-7 self-start">
                <h2 className="mb-3 text-[clamp(20px,2.2vw,26px)]">{lang === 'fa' ? 'کنترل کیفیت' : 'Quality control'}</h2>
                <p className="text-slate-600">{L(act.quality)}</p>
                <div className="mt-6 rounded-xl border border-rule bg-paper p-4 text-[13.5px] text-[#565E66]">{lang === 'fa' ? 'خدماتی مانند ترانسپورت، گمرک یا انبارداری تنها در صورت ارائهٔ واقعی توسط شرکت، به‌عنوان خدمت مستقل معرفی می‌شوند.' : 'Services such as transport, customs or warehousing are presented separately only when the company actually provides them.'}</div>
              </div>
            </div>
          </div>
        </section>
        <section className="bg-white py-14 md:py-20">
          <div className="wrap">
            <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{lang === 'fa' ? 'سوابق و نمونه‌های همکاری' : 'Track record & cases'}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'نمونه‌های مرتبط از همکاری‌ها' : 'Related engagements'}</h2>
              </div>
              <Link className="btn-line btn-sm" to="/projects">{t('view_all')}</Link>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              {projects.map((pr, i) => (
                <article className={`card rv rv-d${i + 1} flex h-full flex-col gap-2 p-6`} key={pr.id}>
                  <span className="flex items-center gap-2">
                    <span className="tag">{L(pr.sector)}</span>
                    <span className="text-[12px] text-[#8A9199]">{pr.year}</span>
                  </span>
                  <h3 className="mt-1 text-[16.5px] leading-relaxed">{L(pr.title)}</h3>
                  <p className="line-clamp-3 text-[13.5px] text-[#565E66]">{L(pr.result)}</p>
                </article>
              ))}
            </div>
          </div>
        </section>
        <section id="faq" className="scroll-mt-28 py-14 md:py-20">
          <div className="wrap">
            <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{lang === 'fa' ? 'پرسش‌های پرتکرار' : 'FAQ'}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('faq_coop')}</h2>
              </div>
              <Link className="btn-line btn-sm" to="/contact">{t('nav_contact')}</Link>
            </div>
            <div className="grid items-start gap-8 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)] lg:gap-12">
              <div className="grid gap-3">
                <FaqList items={faqs} plus />
              </div>
              <div className="rv rv-r relative hidden overflow-hidden rounded-xl2 border border-mist-200 shadow-card lg:block">
                <img src="/images/trade-highway.webp" alt="" loading="lazy" className="kenburns aspect-[4/5] w-full object-cover" />
                <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/55 to-transparent" aria-hidden="true"></span>
              </div>
            </div>
          </div>
        </section>
        <Cta />
      </main>
    </>
  )
}

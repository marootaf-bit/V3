import { Link } from 'react-router-dom'
import { useDict } from '../lib.jsx'

export function NotFoundCompact() {
  const { t } = useDict()
  return <main id="main" className="flex-1"><div className="grid min-h-[50vh] place-items-center px-6 text-center"><div>
    <h1 className="mb-3 text-[28px]">{t('notfound_t')}</h1>
    <p className="mb-6 text-slate-500">{t('notfound_d')}</p>
    <Link to="/" className="btn-ink">{t('back_home')}</Link>
  </div></div></main>
}

const LINKS = [['/', 'home'], ['/about', 'nav_about'], ['/activities', 'nav_activities'], ['/products', 'nav_products'], ['/news', 'nav_news'], ['/contact', 'nav_contact']]
export default function NotFound() {
  const { t } = useDict()
  return <main id="main" className="flex-1"><div className="grid min-h-[60vh] place-items-center px-6 text-center"><div>
    <div className="mb-3 font-head text-[64px] font-bold text-brass">404</div>
    <h1 className="mb-3 text-[28px]">{t('notfound_t')}</h1>
    <p className="mb-7 text-slate-500">{t('notfound_d')}</p>
    <div className="mb-8 flex flex-wrap justify-center gap-2">{LINKS.map(([url, label]) => <Link to={url} className="chip no-underline" key={url}>{t(label)}</Link>)}</div>
    <Link to="/" className="btn-ink">{t('back_home')}</Link>
  </div></div></main>
}

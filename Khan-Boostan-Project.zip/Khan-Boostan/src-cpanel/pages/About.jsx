import { useEffect, useState } from 'react'
import { Link, Navigate, useLocation } from 'react-router-dom'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import CompanyHero from '../components/CompanyHero.jsx'
import CompanyLoading from '../components/CompanyLoading.jsx'
import { usableLogo } from './company-assets.js'
import './company-relations.css'

const COPY = {
  fa: {
    pageTitle: 'درباره خان بوستان', intro: 'معرفی و ماهیت فعالیت', official: 'نام رسمی شرکت',
    history: 'روایت مسیر فعالیت', structure: 'ساختار و شیوهٔ کار',
    approach: 'رویکرد همکاری', audiences: 'مخاطبان فعالیت', imports: 'واردات', exports: 'صادرات',
    companyMore: 'متن کامل معرفی شرکت', messageMore: 'خواندن پیام کامل', messageTitle: 'پیام ثبت‌شده', managementMessage: 'پیام مدیریت',
    leadership: 'رهبری', management: 'مدیریت', colleagues: 'اعضای تیم', ungrouped: 'دیگر اعضای ثبت‌شده',
    photo: 'گفت‌وگوی تجارتی در کنار نمونه‌های کالا', scopeNote: 'نوع کالا و شرایط همکاری بر اساس درخواست مشتری و نیاز بازار تعیین می‌شود.',
    activityMore: 'مشاهدهٔ همهٔ حوزه‌های فعالیت',
    purpose: 'مأموریت و چشم‌انداز', values: 'ارزش‌های کاری', relations: 'همکاران و روابط تجارتی',
    relationsDemo: 'نوع هر رابطه در صفحهٔ همکاران بر اساس اطلاعات ثبت‌شده نمایش داده می‌شود؛ پیش از اتکا به آن، تأیید مستقیم بگیرید.',
    partnerMore: 'مشاهدهٔ روابط تجارتی', contactTitle: 'برای گفت‌وگوی تجارتی در تماس باشید',
    contactText: 'برای پرسش دربارهٔ فعالیت‌ها یا پیشنهاد همکاری، با ما تماس بگیرید.',
    profileDownload: 'دانلود پروفایل PDF',
  },
  en: {
    pageTitle: 'About Khan Boostan', intro: 'Company and scope of work', official: 'Registered company name',
    history: 'Our path so far', structure: 'How the company works',
    approach: 'Our approach', audiences: 'Who we work with', imports: 'Imports', exports: 'Exports',
    companyMore: 'Read the complete company introduction', messageMore: 'Read the full message', messageTitle: 'A message from the team', managementMessage: 'A message from management',
    leadership: 'Leadership', management: 'Management', colleagues: 'Team', ungrouped: 'Other registered members',
    photo: 'A trade conversation alongside examples of goods', scopeNote: 'Goods and terms are set by customer demand and market need.',
    activityMore: 'Explore all trade activities',
    purpose: 'Mission and vision', values: 'How we work', relations: 'Partners and trade relations',
    relationsDemo: 'The partners page shows relationship types as recorded; please confirm an arrangement directly before relying on it.',
    partnerMore: 'See trade relations', contactTitle: 'Start a trade conversation',
    contactText: 'Get in touch with a question about our activities or a cooperation proposal.',
    profileDownload: 'Download company profile (PDF)',
  },
}

// The preview server sends HTML for missing paths (and even for valid PDFs on HEAD).
// Read only the PDF signature so an absent/invalid file never becomes a download link.
function useAvailableProfile(file) {
  const [ready, setReady] = useState(false)
  useEffect(() => {
    setReady(false)
    if (!file) return
    const controller = new AbortController()
    try {
      const url = new URL(file, window.location.href)
      if (url.origin !== window.location.origin || !url.pathname.toLowerCase().endsWith('.pdf')) return
      fetch(url.href, { headers: { Range: 'bytes=0-4' }, signal: controller.signal })
        .then(async (response) => {
          if (!response.ok || !response.body) return
          const reader = response.body.getReader()
          const { value } = await reader.read()
          await reader.cancel().catch(() => {})
          if (!controller.signal.aborted && value && new TextDecoder().decode(value.slice(0, 5)) === '%PDF-') setReady(true)
        })
        .catch(() => {})
    } catch { /* An invalid path must not turn into a link. */ }
    return () => controller.abort()
  }, [file])
  return ready
}

function TeaserLogo({ entry }) {
  const [failed, setFailed] = useState(false)
  const logo = usableLogo(entry.logo)
  return logo && !failed ? (
    <img className="kb-teaser-logo" src={logo} alt="" width="48" height="48" loading="lazy" decoding="async" onError={() => setFailed(true)} />
  ) : null
}

// A previously shared /team URL should keep working without creating a second team source.
export function TeamRedirect() {
  const { data, settings } = useContent()
  const { lang } = useDict()
  if (!data) return <CompanyLoading lang={lang} />
  const hasTeam = settings.sections?.showTeam !== false && (data.team ?? []).length > 0
  return <Navigate replace to={hasTeam ? '/about#team' : '/about'} />
}

export default function About() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  const { hash } = useLocation()
  const c = COPY[lang]
  const comp = settings.company ?? {}, about = settings.about ?? {}, sec = settings.sections ?? {}
  const pages = settings.pages ?? {}
  const team = [...(data?.team ?? [])].sort(bySort)
  const teamVisible = Boolean(data && sec.showTeam !== false && team.length)
  const speaker = team.find((m) => m.group === 'leadership' && L(m.message)) ?? team.find((m) => L(m.message))
  const message = speaker ? L(speaker.message) : ''
  const groupNames = { leadership: c.leadership, management: c.management, team: c.colleagues }
  const teamGroups = Object.entries(groupNames)
    .map(([group, label]) => ({ group, label, members: team.filter((m) => m.group === group) }))
    .filter(({ members }) => members.length)
  const ungrouped = team.filter((m) => !Object.hasOwn(groupNames, m.group))
  if (ungrouped.length) teamGroups.push({ group: 'other', label: c.ungrouped, members: ungrouped })
  const facts = (data?.facts ?? []).filter((item) => L(item.label) || L(item.value))
  const values = (about.values ?? []).filter((item) => L(item.title) || L(item.text))
  const partners = [...(data?.partners ?? [])].filter((p) => p.kind !== 'brand').sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || bySort(a, b))
  const withLogo = partners.find((entry) => usableLogo(entry.logo))
  const teaserPartners = (withLogo ? [withLogo, ...partners.filter((entry) => entry !== withLogo)] : partners).slice(0, 3)
  const audience = [
    { label: c.imports, text: L(pages.import?.audience) },
    { label: c.exports, text: L(pages.export?.audience) },
  ].filter((item) => item.text)
  const fullIntroduction = L(comp.about)
  const overview = L(comp.summary) || fullIntroduction.split(/\n\s*\n/)[0]
  const introVisible = Boolean(L(comp.legal) || overview || fullIntroduction || L(comp.approach) || audience.length ||
    L(about.history) || L(about.structure) || (sec.showFacts !== false && facts.length))
  const profile = (data?.documents ?? []).find((doc) => doc.kind === 'profile' && doc.file)
  const profileReady = useAvailableProfile(sec.showDownloads !== false ? profile?.file : '')

  // The global hash handler may run before /api/content has mounted the team section.
  useEffect(() => {
    if (hash !== '#team' || !teamVisible) return
    const frame = requestAnimationFrame(() => {
      const section = document.getElementById('team')
      if (section) section.scrollIntoView({ behavior: 'instant', block: 'start' })
    })
    return () => cancelAnimationFrame(frame)
  }, [hash, teamVisible])

  if (!data) return <CompanyLoading lang={lang} />

  const scope = [
    { id: 'import', title: L(pages.import?.title, t('nav_import')), text: L(pages.import?.intro) },
    { id: 'export', title: L(pages.export?.title, t('nav_export')), text: L(pages.export?.intro) },
  ].filter((item) => item.text)

  return (
    <main id="main" className="kb-pages kb-about flex-1">
      <CompanyHero image="/images/about-office.webp" imageSet="/images/about-office-sm.webp 640w, /images/about-office-md.webp 1000w, /images/about-office.webp 1536w"
        title={c.pageTitle} summary={L(comp.tagline) || overview} crumbs={[{ label: t('nav_intro') }]} />

      {introVisible && <section className="kb-section kb-intro" aria-labelledby="kb-intro-title">
        <div className="wrap">
          <div className="kb-intro-grid">
            <div className="kb-intro-body">
              <h2 id="kb-intro-title">{c.intro}</h2>
              {L(comp.legal) && (
                <div className="kb-official">
                  <span className="kb-small-label">{c.official}</span>
                  <strong>{L(comp.legal)}</strong>
                  {lang === 'fa' && comp.legal?.en && <span lang="en" dir="ltr">{comp.legal.en}</span>}
                </div>
              )}
              {overview && <p className="kb-paragraph kb-lead">{overview}</p>}
              {L(comp.approach) && (
                <div className="kb-intro-point">
                  <h3>{c.approach}</h3><p>{L(comp.approach)}</p>
                </div>
              )}
              {audience.length > 0 && (
                <div className="kb-intro-point">
                  <h3>{c.audiences}</h3>
                  <dl>{audience.map(({ label, text }) => <div key={label}><dt>{label}</dt><dd>{text}</dd></div>)}</dl>
                </div>
              )}
              {fullIntroduction && fullIntroduction !== overview && (
                <details className="kb-full-introduction">
                  <summary>{c.companyMore}</summary>
                  <p className="kb-paragraph">{fullIntroduction}</p>
                </details>
              )}
              {L(about.history) && (
                <div className="kb-story">
                  <h3>{c.history}</h3>
                  <p className="kb-paragraph">{L(about.history)}</p>
                </div>
              )}
              {L(about.structure) && (
                <div className="kb-story">
                  <h3>{c.structure}</h3>
                  <p className="kb-paragraph">{L(about.structure)}</p>
                </div>
              )}
            </div>
            <div className="kb-intro-aside">
              <figure className="kb-intro-photo">
                <img src="/images/news-meeting.webp" srcSet="/images/news-meeting-sm.webp 640w, /images/news-meeting-md.webp 1000w, /images/news-meeting.webp 1536w" sizes="(max-width: 900px) 100vw, 40vw" alt={c.photo} width="1536" height="1024" loading="lazy" decoding="async" />
              </figure>
              {sec.showFacts !== false && facts.length > 0 && (
                <aside className="kb-facts" aria-labelledby="kb-facts-title">
                  <h3 id="kb-facts-title">{t('facts_t')}</h3>
                  <dl>
                    {facts.map((fact) => (
                      <div key={fact.id ?? `${L(fact.label)}-${L(fact.value)}`}>
                        <dt>{L(fact.label)}</dt><dd>{L(fact.value)}</dd>
                      </div>
                    ))}
                  </dl>
                </aside>
              )}
            </div>
          </div>
        </div>
      </section>}

      {scope.length > 0 && (
        <section className="kb-section kb-scope" aria-labelledby="kb-scope-title">
          <div className="wrap">
            <div className="kb-section-head">
              <h2 id="kb-scope-title">{t('trade_intro_t')}</h2>
              <p>{c.scopeNote}</p>
            </div>
            <div className="kb-scope-grid">
              {scope.map((item) => (
                <article className="kb-scope-item" key={item.id}>
                  <h3>{item.title}</h3><p>{item.text}</p>
                </article>
              ))}
            </div>
            <Link className="kb-text-link kb-scope-more" to="/activities">{c.activityMore}<span aria-hidden="true"> ↗</span></Link>
          </div>
        </section>
      )}

      {(L(about.mission) || L(about.vision)) && (
        <section className="kb-section kb-purpose" aria-labelledby="kb-purpose-title">
          <div className="wrap">
            <h2 id="kb-purpose-title">{c.purpose}</h2>
            <div className="kb-purpose-grid">
              {L(about.mission) && <div><h3>{t('mission_t', lang === 'fa' ? 'مأموریت' : 'Mission')}</h3><p>{L(about.mission)}</p></div>}
              {L(about.vision) && <div><h3>{t('vision_t', lang === 'fa' ? 'چشم‌انداز' : 'Vision')}</h3><p>{L(about.vision)}</p></div>}
            </div>
          </div>
        </section>
      )}

      {values.length > 0 && (
        <section className="kb-section kb-values" aria-labelledby="kb-values-title">
          <div className="wrap">
            <h2 id="kb-values-title">{c.values}</h2>
            <div className="kb-values-grid">
              {values.map((value, i) => (
                <article key={i}>
                  {L(value.title) && <h3>{L(value.title)}</h3>}
                  {L(value.text) && <p>{L(value.text)}</p>}
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      {teamVisible && message && (
        <section className="kb-section kb-message" aria-labelledby="kb-message-title">
          <div className="wrap kb-message-grid">
            <h2 id="kb-message-title">{speaker.group === 'leadership' ? t('chairman_msg') : speaker.group === 'management' ? c.managementMessage : c.messageTitle}</h2>
            <figure>
              {speaker.demo && <p className="kb-demo mb-3">{lang === 'fa' ? 'پیام و هویت نمونه؛ تأیید نشده' : 'Sample message and identity; unverified'}</p>}
              <blockquote>{message.length > 680 ? `${message.slice(0, 420).trimEnd()}…` : message}</blockquote>
              {message.length > 680 && (
                <details className="kb-message-more"><summary>{c.messageMore}</summary><blockquote>{message}</blockquote></details>
              )}
              <figcaption>
                {speaker.demo ? <span className="kb-team-avatar" aria-hidden="true"><svg viewBox="0 0 24 24" width="25" height="25" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="8" r="3.25" /><path d="M4.5 20c.2-3.7 3-6 7.5-6s7.3 2.3 7.5 6" /></svg></span> : speaker.photo && <img src={speaker.photo} alt="" width="55" height="55" loading="lazy" decoding="async" />}
                <span><strong>{L(speaker.name)}</strong><span>{L(speaker.role)}</span></span>
              </figcaption>
            </figure>
          </div>
        </section>
      )}

      {teamVisible && (
        <section id="team" className="kb-section kb-team" aria-labelledby="kb-team-title">
          <div className="wrap">
            <h2 id="kb-team-title">{t('nav_team')}</h2>
            {team.some((member) => member.demo) && <p className="mb-5 text-[13px] text-slate-600" role="note">{lang === 'fa' ? 'نام‌ها و شرح‌های این بخش نمونه‌اند؛ تا تأیید هویت و اجازهٔ نشر، تصویر اشخاص نمایش داده نمی‌شود.' : 'Names and biographies here are samples; portraits are withheld until identity and publication rights are verified.'}</p>}
            {teamGroups.map(({ group, label, members }) => (
              <div className="kb-team-group" key={group} data-team-group={group}>
                <h3>{label}</h3>
                <div className="kb-team-grid">
                  {members.map((member, index) => (
                    <article className="kb-person" key={member.id ?? index} data-member-id={member.id}>
                      {member.demo ? <span className="kb-person-placeholder" aria-hidden="true"><svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" strokeWidth="1.4"><circle cx="12" cy="8" r="3.25" /><path d="M4.5 20c.2-3.7 3-6 7.5-6s7.3 2.3 7.5 6" /></svg></span> : member.photo && <img src={member.photo} alt="" width="96" height="118" loading="lazy" decoding="async" />}
                      <div className="kb-person-copy">
                        <h4>{L(member.name)}</h4>
                        {L(member.role) && <p className="kb-person-role">{L(member.role)}</p>}
                        {L(member.bio) && <p>{L(member.bio)}</p>}
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {sec.showPartners !== false && partners.length > 0 && (
        <section className="kb-section kb-partner-teaser" aria-labelledby="kb-partner-teaser-title">
          <div className="wrap kb-teaser-grid">
            <div>
              <h2 id="kb-partner-teaser-title">{c.relations}</h2>
              <p>{partners.every((p) => p.demo) ? c.relationsDemo : t('partners_d')}</p>
              <Link className="kb-text-link" to="/partners">{c.partnerMore}<span aria-hidden="true"> ↗</span></Link>
            </div>
            <ul>
              {teaserPartners.map((p, index) => (
                <li key={p.id ?? index}>
                  <TeaserLogo entry={p} />
                  <strong>{L(p.name)}</strong>
                  <span>{t(`rel_${p.kind}`, lang === 'fa' ? 'رابطهٔ ثبت‌شده' : 'Registered relation')}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {sec.showDownloads !== false && profile && profileReady && (
        <div className="kb-profile wrap">
          <div><strong>{L(profile.title) || t('profile_t')}</strong><span>{t('profile_d')}</span></div>
          <a href={profile.file} download className="kb-text-link">{c.profileDownload}<span aria-hidden="true"> ↓</span></a>
        </div>
      )}
      <section className="kb-contact" aria-labelledby="kb-about-contact-title">
        <div className="wrap kb-contact-inner">
          <div><h2 id="kb-about-contact-title">{c.contactTitle}</h2><p>{c.contactText}</p></div>
          <Link to="/contact" className="btn-coral">{t('nav_contact')}</Link>
        </div>
      </section>
    </main>
  )
}

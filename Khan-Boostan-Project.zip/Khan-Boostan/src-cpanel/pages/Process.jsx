import { Link } from 'react-router-dom'
import { useContent, useReveal } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero, Cta } from '../parts.jsx'

const STEPS = {
  fa: [['01', 'درخواست و شناخت نیاز', 'گفتگو با مشتری یا شرکت، تعیین مشخصات و مقدار'], ['02', 'بررسی و تأمین', 'انتخاب تأمین‌کننده بر اساس اصول مشخص، اعلام شفاف قیمت و شرایط'], ['03', 'هماهنگی و آماده‌سازی', 'کنترل کیفیت و بسته‌بندی، تکمیل اسناد'], ['04', 'انتقال و تحویل', 'پیگیری تا تحویل، اطلاع‌رسانی روشن']],
  en: [['01', 'Request & scoping', 'Talk with the client, agree specifications and quantity'], ['02', 'Review & sourcing', 'Choose suppliers on clear principles, transparent pricing'], ['03', 'Coordination & prep', 'Quality control, packing and documents'], ['04', 'Shipping & delivery', 'Follow-up until delivery, clear updates']],
}

export default function Process() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  if (!data) return <div className="min-h-[70vh]" />
  const steps = STEPS[lang === 'en' ? 'en' : 'fa']
  const intro = L((settings.pages ?? {}).process?.intro)
  return (
    <>
      <main id="main" className="flex-1">
        <Hero image="/images/trade-highway.webp" crumbs={[['/activities', t('nav_activities')], [null, t('nav_process')]]} title={t('nav_process')} sub={intro || (lang === 'fa' ? 'روند کاری خان بوستان از درخواست مشتری آغاز می‌شود و تا تحویل ادامه می‌یابد.' : 'Our process starts with the client request and continues until delivery.')} />
        <section className="py-14 md:py-20">
          <div className="wrap">
            <div className="relative grid gap-8 md:grid-cols-4 md:gap-6">
              <span className="step-line inset-x-[12%] hidden md:block" aria-hidden="true"></span>
              {steps.map((s, i) => (
                <div className={`rv rv-d${i + 1} relative flex gap-4 md:flex-col md:items-center md:text-center`} key={i}>
                  <span className="step-dot">{s[0]}</span>
                  <div>
                    <h3 className="mb-1.5 text-[17px]">{s[1]}</h3>
                    <p className="text-[14px] leading-relaxed text-[#565E66]">{s[2]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        <Cta />
      </main>
    </>
  )
}

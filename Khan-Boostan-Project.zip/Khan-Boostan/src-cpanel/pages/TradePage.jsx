import { Link } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero, Cta, FaqList, BoxIcon, ArrowIcon } from '../parts.jsx'

export default function TradePage({ kind }) {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  if (!data) return <div className="min-h-[70vh]" />
  const pg = (settings.pages ?? {})[kind] ?? {}
  const cats = data.categories ?? []
  const projects = [...(data.projects ?? [])].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || bySort(a, b))
  const faqs = (data.faq ?? []).filter((f) => f.topic === kind)
  const cnt = (id) => (data.products ?? []).filter((p) => p.category === id).length
  return (
    <>
      <main id="main" className="flex-1">
        <Hero image={pg.image} crumbs={[['/activities', t('nav_activities')], [null, L(pg.title)]]} title={L(pg.title)} sub={L(pg.intro)} />
        <section className="py-14 md:py-20">
          <div className="wrap grid items-start gap-12 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
            <div className="rv">
              <h2 className="mb-3 text-[20px]">{lang === 'fa' ? 'دامنهٔ فعالیت' : 'Scope of work'}</h2>
              <p className="mb-6 whitespace-pre-line text-slate-600">{L(pg.body)}</p>
              <ul className="grid gap-3">
                {(pg.points ?? []).map((p, i) => (
                  <li className="card flex items-start gap-3 p-4 text-[15px] text-slate-600" key={i}>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className="mt-1 shrink-0 text-ok"><path d="M20 6 9 17l-5-5" /></svg>
                    {L(p)}
                  </li>
                ))}
              </ul>
              <h2 className="mb-3 mt-10 text-[20px]">{t('audience_t')}</h2>
              <p className="whitespace-pre-line text-slate-600">{L(pg.audience)}</p>
              <h2 className="mb-3 mt-10 text-[20px]">{t('required_t')}</h2>
              <p className="whitespace-pre-line text-slate-600">{L(pg.required)}</p>
            </div>
            <div className="grid gap-5 self-start">
              <div className="rv overflow-hidden rounded-card shadow-card"><img src={kind === 'import' ? '/images/trade-port.webp' : '/images/trade-detail.webp'} alt="" loading="lazy" className="w-full object-cover" /></div>
              <div className="rv card p-6">
                <h3 className="mb-3 text-[16px]">{t('groups_t')}</h3>
                <div className="flex flex-wrap gap-2">
                  {cats.map((c) => (
                    <Link className="chip no-underline" to={`/products/?c=${c.id}`} key={c.id}>{L(c.name)} <span className="text-[12px] text-slate-600">({cnt(c.id)})</span></Link>
                  ))}
                </div>
              </div>
              <div className="rv card p-6">
                <h3 className="mb-3 text-[16px]">{t('related_projects')}</h3>
                <ul className="grid gap-2.5">
                  {projects.slice(0, 2).map((pr) => (
                    <li className="rounded-xl border border-rule bg-paper p-3.5" key={pr.id}>
                      <b className="block text-[14px] text-ink">{L(pr.title)}</b>
                      <span className="text-[12.5px] text-[#8A9199]">{L(pr.sector)} · {pr.year}</span>
                    </li>
                  ))}
                </ul>
                <Link className="link-more mt-3 inline-flex !text-[13px]" to="/projects">{t('view_all')} <ArrowIcon className="rtl:rotate-180" /></Link>
              </div>
            </div>
          </div>
          {faqs.length > 0 && (
            <div className="wrap mt-14">
              <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
                <div className="max-w-[62ch]">
                  <div className="eyebrow mb-2 text-brass-dark">{lang === 'fa' ? 'پرسش‌های پرتکرار' : 'FAQ'}</div>
                  <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('faq_coop')}</h2>
                </div>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <FaqList items={faqs} />
              </div>
            </div>
          )}
        </section>
        <Cta />
      </main>
    </>
  )
}

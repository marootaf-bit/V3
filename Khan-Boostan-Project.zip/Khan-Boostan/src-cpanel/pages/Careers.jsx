import { Link } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero } from '../parts.jsx'

const Pin = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0" /><circle cx="12" cy="10" r="3" /></svg>
const Clock = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
const Users = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>

export default function Careers() {
  const { data } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  if (!data) return <div className="min-h-[70vh]" />
  const jobs = [...(data.jobs ?? [])].sort(bySort)
  return (
    <>
      <main id="main" className="flex-1">
        <Hero image="/images/gallery-office.webp" crumbs={[[null, t('nav_about')], [null, t('careers_t')]]} title={t('careers_t')} sub={t('careers_d')} />
        <section className="py-12 md:py-16">
          <div className="wrap-narrow grid gap-5">
            {jobs.length === 0 && <div className="grid place-items-center gap-4 py-14 text-center"><span className="grid h-14 w-14 place-items-center rounded-full bg-mist-100 text-[#A7AEB5]"><Users /></span><p className="text-slate-500">{t('jobs_empty')}</p><p className="max-w-[46ch] text-[13.5px] text-[#8A9199]">{lang === 'fa' ? 'در این پیش‌نمایش درخواست آنلاین فعال نیست؛ برای مشاهدهٔ راه‌های تماس به صفحهٔ تماس بروید.' : 'Online applications are disabled in this preview. The contact page lists the available contact details.'}</p><Link to="/contact" className="btn-line btn-sm">{t('nav_contact')}</Link></div>}
            {jobs.map((job, i) => (
              <div className={`rv rv-d${(i % 2) + 1} card p-6 md:p-7`} key={job.id}>
                <div className="mb-3 flex flex-wrap items-center gap-3">
                  <h3 className="text-[18px]">{L(job.title)}</h3>
                  <span className="rounded-full bg-blue-50 px-3 py-1 text-[12.5px] font-bold text-ink">{L(job.type)}</span>
                  <span className="inline-flex items-center gap-1.5 text-[13px] text-slate-500"><Pin />{L(job.location)}</span>
                  {job.deadline && <span className="inline-flex items-center gap-1.5 text-[13px] font-bold text-brass-dark"><Clock />{t('deadline_l')}: {job.deadline}</span>}
                </div>
                <p className="mb-4 text-[14.5px] text-slate-600">{L(job.summary)}</p>
                <div className="whitespace-pre-line text-[14.5px] text-slate-600">{L(job.body)}</div>
                <div className="mt-5 flex flex-wrap items-center gap-3">
                  <span className="inline-flex min-h-[42px] items-center rounded-lg border border-mist-300 bg-mist-50 px-4 text-[13px] font-bold text-ink">{lang === 'fa' ? 'درخواست بست غیرفعال' : 'Applications unavailable'}</span>
                  <span className="text-[12.5px] text-[#8A9199]">{lang === 'fa' ? 'این آگهی نمونه است؛ تا تأیید بست و راه دریافت درخواست، رزومه نفرستید.' : 'This is a sample vacancy. Please do not send a résumé before the role and application channel are verified.'}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  )
}

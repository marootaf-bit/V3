import { useReveal } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero } from '../parts.jsx'

// Design-preview wording: forms and sign-in are inactive; no backend receives data.
const COPY = {
  privacy: {
    fa: [
      ['فرم‌ها در این پیش‌نمایش', 'فرم تماس و درخواست تا تکمیل طراحی فقط برای نمایش‌اند. دکمهٔ ارسال غیرفعال است؛ چیزی که در فرم می‌نویسید به سرور فرستاده یا در دیتابیس ذخیره نمی‌شود.'],
      ['راه‌های تماس دیگر', 'اگر از شمارهٔ تلفن، ایمیل، واتساپ یا پیوندهای بیرونی استفاده کنید، ارتباط از طریق همان سرویس بیرونی انجام می‌شود، نه از طریق فرم این پیش‌نمایش.'],
      ['داده‌های مرورگر', 'برای یادآوری زبان انتخابی ممکن است تنظیمی در حافظهٔ محلی همین مرورگر (localStorage) ذخیره شود. در این پیش‌نمایش کوکی نشست مدیریت، کوکی ردیابی یا ثبت پیام وجود ندارد.'],
      ['پاک‌کردن اطلاعات محلی', 'برای حذف زبان ذخیره‌شده می‌توانید داده‌های این سایت را از مرورگر پاک کنید. این پیش‌نمایش هیچ درخواستی را روی سرور نگهداری نمی‌کند.'],
    ],
    en: [
      ['Forms in this preview', 'The contact and request forms are for layout review until the design is finished. Sending is disabled; nothing typed into them is sent to a server or stored in a database.'],
      ['Other contact channels', 'If you use the listed phone number, email, WhatsApp or external links, that contact takes place through the relevant outside service, not through this preview’s forms.'],
      ['Browser data', 'Your language preference may be saved in this browser’s local storage. This preview has no admin session cookies, tracking cookies or message storage.'],
      ['Removing local data', 'You can clear this site’s browser data to remove the saved language preference. This preview does not retain requests on a server.'],
    ],
  },
  terms: {
    fa: [
      ['محتوای سایت', 'محتوای این سایت برای معرفی فعالیت‌های شرکت است و پیشنهاد قیمت یا قرارداد محسوب نمی‌شود.'],
      ['درخواست‌ها', 'فرم‌های تماس و درخواست در این پیش‌نمایش صرفاً نمایشی‌اند و ارسال نمی‌شوند. برای ارتباط از راه‌های تماس درج‌شده در سایت استفاده کنید.'],
      ['تنظیمات مرورگر', 'در این پیش‌نمایش ورود مدیر، API یا کوکی نشست وجود ندارد. فقط انتخاب زبان ممکن است در حافظهٔ محلی مرورگر نگهداری شود؛ کوکی ردیابی یا تبلیغاتی به کار نمی‌رود.'],
      ['مالکیت', 'نام و نشان خان بوستان متعلق به شرکت است؛ استفاده بدون اجازه مجاز نیست.'],
    ],
    en: [
      ['Site content', 'Content on this site introduces company activities and is not a price offer or a contract.'],
      ['Requests', 'Contact and request forms are visual only in this preview and do not submit. Use the contact details listed on the site to get in touch.'],
      ['Browser preferences', 'This preview has no admin sign-in, API or session cookies. Only the language preference may be kept in browser local storage; no tracking or advertising cookies are used.'],
      ['Ownership', 'The Khan Boostan name and mark belong to the company; unauthorised use is not permitted.'],
    ],
  },
}

export default function Legal({ kind }) {
  const { t, lang } = useDict()
  useReveal()
  const key = kind === 'terms' ? 'nav_terms' : 'nav_privacy'
  const blocks = COPY[kind === 'terms' ? 'terms' : 'privacy'][lang === 'en' ? 'en' : 'fa']
  return <main id="main" className="site-legal flex-1">
    <Hero image="/images/trade-detail.webp" crumbs={[[null, t(key)]]} title={t(key)} />
    <section className="py-12 md:py-16"><div className="wrap-narrow grid gap-6">
      {blocks.map(([heading, paragraph]) => <div className="rv card p-6 md:p-7" key={heading}>
        <h2 className="mb-2 text-[18px]">{heading}</h2>
        <p className="whitespace-pre-line text-[15px] text-slate-600">{paragraph}</p>
      </div>)}
    </div></section>
  </main>
}

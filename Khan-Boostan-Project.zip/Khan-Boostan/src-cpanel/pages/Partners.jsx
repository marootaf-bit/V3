import { useEffect, useState } from 'react'
import { Link, useLocation, useSearchParams } from 'react-router-dom'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import CompanyHero from '../components/CompanyHero.jsx'
import CompanyLoading from '../components/CompanyLoading.jsx'
import { usableLogo } from './company-assets.js'
import './company-relations.css'

const COPY = {
  fa: {
    approach: 'شیوهٔ همکاری', source: 'نوع رابطه مطابق دستهٔ ثبت‌شده در پنل نمایش داده می‌شود؛ این فهرست به‌تنهایی تأییدِ حقوقیِ همکاری نیست.', demoNote: 'این نام‌ها و رابطه‌ها نمونه‌اند؛ نمایندگی، همکاری و اجازهٔ استفاده از نشان‌ها هنوز تأیید نشده است.',
    agencies: 'نمایندگی رسمی', agencyNote: 'در این بخش فقط مواردی نمایش داده می‌شود که نوع رابطهٔ آن‌ها در پنل «نمایندگی رسمی» ثبت شده است.',
    agencyDemo: 'برای تأیید نمایندگی رسمی، اسناد و وضعیت فعلی را مستقیماً با شرکت بررسی کنید.',
    relations: 'روابط تجارتی', relationsNote: 'شرکا، تأمین‌کنندگان، مشتریان و شرکت‌های وابسته بر اساس نوع ثبت‌شده، در یک فهرست قابل‌فیلتر نمایش داده می‌شوند.',
    filter: 'فیلتر بر اساس نوع رابطه', all: 'همه', partner: 'شرکای تجارتی', supplier: 'تأمین‌کنندگان', client: 'مشتریان', affiliate: 'وابسته',
    results: (count) => `${count} مورد در این فهرست`, unknown: 'نوع رابطه ثبت نشده', since: 'از سال',
    website: 'وب‌سایت', brands: 'برندهای عرضه‌شده', brandsNote: 'عرضهٔ محصولات یک برند به‌معنای نمایندگی رسمی آن نیست. رابطهٔ هر مورد همان است که در پنل درج شده است.',
    grouped: (count) => `${count} رکورد مرتبط؛ جزئیات هر مورد حفظ شده است`, disabled: 'فهرست روابط فعلاً منتشر نشده است',
    disabledNote: 'این بخش در تنظیمات غیرفعال است؛ برای معلومات دربارهٔ همکاری از صفحهٔ تماس استفاده کنید.',
    empty: 'هنوز رابطه‌ای برای این بخش ثبت نشده است.', contact: 'پیشنهاد همکاری دارید؟',
    contactNote: 'راه‌های تماس در صفحهٔ تماس درج شده‌اند؛ فرم آنلاین در این پیش‌نمایش غیرفعال است.',
  },
  en: {
    approach: 'How we work together', source: 'Relationship types follow the category recorded in the admin panel; this list alone does not verify a legal arrangement.', demoNote: 'These names and relations are samples; agency status, collaboration and logo permissions remain unverified.',
    agencies: 'Official agencies', agencyNote: 'Only records with the “official agency” type in the admin panel appear here.',
    agencyDemo: 'Please confirm any official agency arrangement and its current documentation directly with the company.',
    relations: 'Trade relationships', relationsNote: 'Partners, suppliers, clients and affiliates appear together, with filters based on the recorded relationship type.',
    filter: 'Filter by relationship type', all: 'All', partner: 'Trade partners', supplier: 'Suppliers', client: 'Clients', affiliate: 'Affiliates',
    results: (count) => `${count} entries in this list`, unknown: 'Relationship type not recorded', since: 'Since',
    website: 'Website', brands: 'Brands whose products are offered', brandsNote: 'Offering a brand’s products does not mean official representation. Each relation is shown as recorded in the admin panel.',
    grouped: (count) => `${count} linked records; each entry is preserved`, disabled: 'Relations are not currently published',
    disabledNote: 'This section is disabled in settings. Please use the contact page for cooperation enquiries.',
    empty: 'No relationships have been added to this section yet.', contact: 'Have a cooperation proposal?',
    contactNote: 'The contact page lists available details; its online form is disabled in this preview.',
  },
}
const FILTER_KINDS = ['partner', 'supplier', 'client', 'affiliate']
const showNumber = (value, lang) => Number.isFinite(Number(value))
  ? new Intl.NumberFormat(lang === 'fa' ? 'fa-AF' : 'en', { useGrouping: false }).format(Number(value))
  : String(value)
const sortFeatured = (a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || bySort(a, b)

function safeWebsite(value) {
  if (!value) return ''
  try { const u = new URL(value); return ['https:', 'http:'].includes(u.protocol) ? u.href : '' } catch { return '' }
}

// A shared display name is not proof of a shared brand. Prefer an explicit
// brand ID; an identical website AND name is the fallback when no IDs conflict.
const normalized = (value) => String(value || '').normalize('NFKC').toLocaleLowerCase()
  .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/[\u064b-\u065f\u200c\s\p{P}\p{S}]/gu, '')
const nameKeys = (name) => (typeof name === 'string' ? [normalized(name)] : [normalized(name?.fa), normalized(name?.en)]).filter(Boolean)
const brandKey = (record) => {
  const values = [record.brandId, record.brand_id, record.brand?.id, record._source === 'brand' ? record.id : null]
  return String(values.find((value) => value != null && String(value).trim()) ?? '').trim()
}
const websiteKey = (record) => {
  const href = safeWebsite(record.website)
  if (!href) return ''
  const url = new URL(href)
  return `${url.hostname.replace(/^www\./i, '').toLowerCase()}${url.pathname.replace(/\/+$/, '').toLowerCase()}`
}
const sameWebsiteAndName = (a, b) => {
  const site = websiteKey(a)
  const names = nameKeys(b.name)
  return Boolean(site && site === websiteKey(b) && nameKeys(a.name).some((key) => names.includes(key)))
}

export function groupBrandRecords(records) {
  const groups = []
  for (const record of records) {
    const id = brandKey(record)
    const exact = id && groups.find((group) => group.records.some((item) => brandKey(item) === id))
    const evidence = groups.find((group) => {
      const ids = group.records.map(brandKey).filter(Boolean)
      return (!id || !ids.length || ids.includes(id))
        && group.records.some((item) => sameWebsiteAndName(item, record))
    })
    const group = exact || evidence
    if (group) group.records.push(record)
    else groups.push({ name: record.name, records: [record] })
  }
  return groups
}

// When a partner has no usable logo, its name itself is the text replacement.
function Identity({ entry, L }) {
  const [failed, setFailed] = useState(false)
  const logo = !failed ? usableLogo(entry.logo) : ''
  return (
    <div className="kb-entity-head" data-logo-fallback={logo ? undefined : 'text'}>
      {logo && <img className="kb-entity-logo" src={logo} alt="" width="70" height="52" loading="lazy" decoding="async" onError={() => setFailed(true)} />}
      <h3>{L(entry.name)}</h3>
    </div>
  )
}

function Relation({ entry, L, t, lang, c }) {
  const website = safeWebsite(entry.website)
  return (
    <article className="kb-entity" data-record-id={entry.id}>
      <Identity entry={entry} L={L} />
      <div className="kb-entity-meta">
        <span className="kb-kind">{t(`rel_${entry.kind}`, c.unknown)}</span>
        {entry.demo && <span className="kb-demo">{t('demo')}</span>}
        {entry.country && L(entry.country) && <span>{L(entry.country)}</span>}
        {entry.since && !entry.demo && <span>{c.since} {showNumber(entry.since, lang)}</span>}
      </div>
      {entry.field && L(entry.field) && <p className="kb-entity-field">{L(entry.field)}</p>}
      {entry.description && L(entry.description) && <p className="kb-entity-description">{L(entry.description)}</p>}
      {website && (
        <div className="kb-entity-foot">
          <a className="kb-text-link" href={website} target="_blank" rel="noopener noreferrer">{c.website}<span aria-hidden="true"> ↗</span></a>
        </div>
      )}
    </article>
  )
}

function Brand({ group, L, t, lang, c }) {
  const logo = group.records.find((item) => item.logo)?.logo
  return (
    <article className="kb-brand-item">
      <Identity entry={{ name: group.name, logo }} L={L} />
      {group.records.some((record) => record.demo) && <span className="kb-demo">{t('demo')}</span>}
      {group.records.length > 1 && <p className="kb-brand-group-count">{c.grouped(showNumber(group.records.length, lang))}</p>}
      <div className="kb-brand-records">
        {group.records.map((record, index) => (
          <div className="kb-brand-record" key={`${record.id ?? index}-${index}`} data-record-id={record.id}>
            <strong>{record._source === 'relation' ? t('rel_brand') : L(record.relation) || t('brands_offered')}</strong>
            {L(record.name) !== L(group.name) && <span>{L(record.name)}</span>}
            {record.country && L(record.country) && <span>{L(record.country)}</span>}
            {record.field && L(record.field) && <span>{L(record.field)}</span>}
            {record.since && !record.demo && <span>{c.since} {showNumber(record.since, lang)}</span>}
            {record.description && L(record.description) && <p>{L(record.description)}</p>}
            {safeWebsite(record.website) && <a className="kb-text-link" href={safeWebsite(record.website)} target="_blank" rel="noopener noreferrer">{c.website}<span aria-hidden="true"> ↗</span></a>}
          </div>
        ))}
      </div>
    </article>
  )
}

export default function Partners() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  const { hash } = useLocation()
  const [searchParams, setSearchParams] = useSearchParams()
  const filter = searchParams.get('relation') || 'all'
  const c = COPY[lang]
  const shown = settings.sections?.showPartners !== false
  const partners = [...(data?.partners ?? [])].sort(sortFeatured)
  const agencies = partners.filter((item) => item.kind === 'agency')
  const relations = partners.filter((item) => item.kind !== 'agency' && item.kind !== 'brand')
  const brandRecords = [
    ...(data?.brands ?? []).slice().sort(bySort).map((item) => ({ ...item, _source: 'brand' })),
    ...partners.filter((item) => item.kind === 'brand').map((item) => ({ ...item, _source: 'relation' })),
  ]
  const brands = groupBrandRecords(brandRecords)
  const counts = Object.fromEntries(FILTER_KINDS.map((kind) => [kind, relations.filter((item) => item.kind === kind).length]))
  const activeFilter = filter === 'all' || counts[filter] ? filter : 'all'
  const visible = activeFilter === 'all' ? relations : relations.filter((item) => item.kind === activeFilter)

  // /partners#brands also needs to work when content arrives asynchronously.
  useEffect(() => {
    if (hash !== '#brands' || !shown || !brands.length) return
    const frame = requestAnimationFrame(() => document.getElementById('brands')?.scrollIntoView({ behavior: 'instant', block: 'start' }))
    return () => cancelAnimationFrame(frame)
  }, [hash, shown, brands.length])

  if (!data) return <CompanyLoading lang={lang} />

  const filters = [
    { kind: 'all', label: c.all, count: relations.length },
    ...FILTER_KINDS.filter((kind) => counts[kind]).map((kind) => ({ kind, label: c[kind], count: counts[kind] })),
  ]
  return (
    <main id="main" className="kb-pages kb-partners flex-1">
      <CompanyHero image="/images/trade-documents.webp" imageSet="/images/trade-documents-sm.webp 640w, /images/trade-documents-md.webp 1024w, /images/trade-documents.webp 1600w" width={1600} height={1067} title={t('nav_partners')} summary={shown ? t('partners_d') : c.disabledNote}
        crumbs={[{ label: t('nav_about'), to: '/about' }, { label: t('nav_partners') }]} />

      <section className="kb-section kb-relations-intro" aria-labelledby="kb-relations-intro-title">
        <div className="wrap kb-relations-intro-grid">
          <h2 id="kb-relations-intro-title">{c.approach}</h2>
          <div>
            <p>{L(settings.company?.approach) || t('partners_approach')}</p>
            <p className="kb-source-note">{c.source}</p>
            {(partners.some((item) => item.demo) || brandRecords.some((item) => item.demo)) && <p className="kb-source-note" role="note">{c.demoNote}</p>}
          </div>
        </div>
      </section>

      {!shown ? (
        <section className="kb-section kb-disabled" aria-labelledby="kb-relations-disabled-title">
          <div className="wrap"><h2 id="kb-relations-disabled-title">{c.disabled}</h2><p>{c.disabledNote}</p></div>
        </section>
      ) : (
        <>
          {agencies.length > 0 && (
            <section className="kb-section kb-agencies" aria-labelledby="kb-agencies-title">
              <div className="wrap">
                <div className="kb-section-head">
                  <h2 id="kb-agencies-title">{c.agencies}</h2>
                  <p>{c.agencyNote} {agencies.some((item) => item.demo) && c.agencyDemo}</p>
                </div>
                <div className="kb-entity-grid">
                  {agencies.map((item, i) => <Relation key={item.id ?? i} entry={item} L={L} t={t} lang={lang} c={c} />)}
                </div>
              </div>
            </section>
          )}

          <section className="kb-section kb-relations-list" aria-labelledby="kb-relations-title">
            <div className="wrap">
              <div className="kb-section-head">
                <h2 id="kb-relations-title">{c.relations}</h2><p>{c.relationsNote}</p>
              </div>
              {relations.length > 0 ? (
                <>
                  <div className="kb-filters" role="group" aria-label={c.filter}>
                    {filters.map(({ kind, label, count }) => (
                      <button key={kind} type="button" aria-pressed={activeFilter === kind} onClick={() => {
                        const next = new URLSearchParams(searchParams)
                        if (kind === 'all') next.delete('relation')
                        else next.set('relation', kind)
                        setSearchParams(next)
                      }}>
                        <span>{label}</span><span className="kb-filter-count">{showNumber(count, lang)}</span>
                      </button>
                    ))}
                  </div>
                  <p className="kb-result-count" role="status" aria-live="polite">{c.results(showNumber(visible.length, lang))}</p>
                  <div className="kb-entity-grid" data-filter={activeFilter}>
                    {visible.map((item, i) => <Relation key={item.id ?? i} entry={item} L={L} t={t} lang={lang} c={c} />)}
                  </div>
                </>
              ) : <p className="kb-empty-note">{c.empty}</p>}
            </div>
          </section>

          {brands.length > 0 && (
            <section id="brands" className="kb-section kb-brands" aria-labelledby="kb-brands-title">
              <div className="wrap">
                <div className="kb-section-head"><h2 id="kb-brands-title">{c.brands}</h2><p>{c.brandsNote}</p></div>
                <div className="kb-brand-grid">
                  {brands.map((group, i) => <Brand key={group.records[0]?.id ?? i} group={group} L={L} t={t} lang={lang} c={c} />)}
                </div>
              </div>
            </section>
          )}
        </>
      )}

      <section className="kb-contact" aria-labelledby="kb-partners-contact-title">
        <div className="wrap kb-contact-inner">
          <div><h2 id="kb-partners-contact-title">{c.contact}</h2><p>{c.contactNote}</p></div>
          <Link className="btn-coral" to="/contact?kind=cooperation">{t('suggest_coop')}</Link>
        </div>
      </section>
    </main>
  )
}

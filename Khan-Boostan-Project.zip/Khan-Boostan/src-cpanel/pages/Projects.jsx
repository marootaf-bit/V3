import { useState } from 'react'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero, Cta } from '../parts.jsx'
import Testimonials from '../components/Testimonials.jsx'

const sectorKey = (value) => typeof value === 'string' ? value : (value?.fa || value?.en || '')

const Pin = ({ className }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0" /><circle cx="12" cy="10" r="3" /></svg>
const Search = ({ className }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.34-4.34" /></svg>
const Users = ({ className }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
const Check = ({ className }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M20 6 9 17l-5-5" /></svg>
const Chart = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v16a2 2 0 0 0 2 2h16" /><path d="M7 13h4v6H7z" /><path d="M13 9h4v10h-4z" /></svg>
const Down = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-open:rotate-180"><path d="m6 9 6 6 6-6" /></svg>

function DetailField({ icon: Icon, label, text }) {
  return <div><div className="mb-1.5 flex items-center gap-2 text-[13px] font-bold text-ink"><Icon className="h-4 w-4 text-brass-dark" />{label}</div><p className="text-[13.5px] leading-relaxed text-slate-600">{text}</p></div>
}

export default function Projects() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  const [sector, setSector] = useState('all')
  const [year, setYear] = useState('all')
  if (!data) return <div className="min-h-[70vh]" />
  const all = [...(data.projects ?? [])].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || bySort(a, b))
  const sectors = [...new Map(all.map((p) => p.sector).filter(Boolean).map((value) => [sectorKey(value), value])).values()]
  const years = [...new Set(all.map((p) => p.year).filter(Boolean))]
  const list = all.filter((p) => (sector === 'all' || sectorKey(p.sector) === sector) && (year === 'all' || p.year === year))
  return (
    <>
      <main id="main" className="flex-1">
        <Hero image="/images/project-construction.webp" crumbs={[[null, t('nav_activities')], [null, t('nav_projects')]]} title={t('nav_projects')} sub={t('projects_d')} />
        <section className="py-14 md:py-20">
          <div className="wrap">
            {all.some((p) => p.demo) && <p className="mb-6 rounded-xl border border-[#e4d1c0] bg-[#fff8f2] p-4 text-[13.5px] text-ink" role="note">{lang === 'fa' ? 'سوابق این بخش نمونهٔ نمایشی‌اند؛ نام مشتری، نتیجهٔ همکاری و اجازهٔ نشر هنوز تأیید نشده‌اند.' : 'These case studies are sample content. Client names, outcomes and permission to publish remain unverified.'}</p>}
            {(sectors.length > 1 || years.length > 1) && (
              <div className="rv mb-10 grid gap-4 rounded-card border border-mist-200 bg-white p-5 shadow-card md:grid-cols-2">
                {sectors.length > 1 && <div><div className="mb-2 text-[12.5px] font-bold text-[#8A9199]">{t('filter_sector')}</div><div className="flex flex-wrap gap-2" role="group" aria-label={t('filter_sector')}>
                  <button className={`chip ${sector === 'all' ? 'chip-on' : ''}`} aria-pressed={sector === 'all'} onClick={() => setSector('all')}>{t('all')}</button>
                  {sectors.map((s) => <button className={`chip ${sector === sectorKey(s) ? 'chip-on' : ''}`} aria-pressed={sector === sectorKey(s)} onClick={() => setSector(sectorKey(s))} key={sectorKey(s)}>{L(s)}</button>)}
                </div></div>}
                {years.length > 1 && <div><div className="mb-2 text-[12.5px] font-bold text-[#8A9199]">{t('filter_year')}</div><div className="flex flex-wrap gap-2" role="group" aria-label={t('filter_year')}>
                  <button className={`chip ${year === 'all' ? 'chip-on' : ''}`} aria-pressed={year === 'all'} onClick={() => setYear('all')}>{t('all')}</button>
                  {years.map((y) => <button className={`chip ${year === y ? 'chip-on' : ''}`} aria-pressed={year === y} onClick={() => setYear(y)} key={y}>{y}</button>)}
                </div></div>}
              </div>
            )}
            {list.length === 0 ? <p className="py-14 text-center text-slate-500">{t('no_results')}</p> : (
              <div className="grid gap-6 md:grid-cols-2">
                {list.map((p, i) => (
                  <details className={`card rv rv-d${(i % 2) + 1} group overflow-hidden`} open={i === 0 ? true : undefined} key={p.id}>
                    <summary className="flex cursor-pointer list-none items-start gap-4 p-6 [&::-webkit-details-marker]:hidden">
                      {p.image ? <img src={p.image} alt="" loading="lazy" className="h-20 w-20 shrink-0 rounded-xl object-cover" /> : <span className="grid h-20 w-20 shrink-0 place-items-center rounded-xl bg-mist-100 text-[#A7AEB5]"><Chart /></span>}
                      <div className="min-w-0 flex-1">
                        <span className="mb-1.5 flex flex-wrap items-center gap-2">
                          {p.sector && <span className="tag">{L(p.sector)}</span>}
                          {p.year && <span className="text-[12px] text-[#8A9199]">{p.year}</span>}
                          {p.market && <span className="inline-flex items-center gap-1 text-[12px] text-[#8A9199]"><Pin className="h-3.5 w-3.5" />{L(p.market)}</span>}
                          {p.featured && <span className="rounded-full bg-brass px-2 py-0.5 text-[10px] font-bold text-white">{t('featured_badge')}</span>}
                          {p.demo && <span className="rounded-full border border-[#dfc5b2] bg-[#fff7f1] px-2 py-0.5 text-[10px] font-bold text-[#7b4328]">{t('demo')}</span>}
                        </span>
                        <h2 className="text-[17px] leading-relaxed">{L(p.title)}</h2>
                        <span className="mt-1.5 inline-flex items-center gap-1.5 text-[12.5px] font-bold text-brass-dark">{t('projects_note')} <Down /></span>
                      </div>
                    </summary>
                    <div className="grid gap-4 border-t border-rule px-6 py-5 md:grid-cols-3">
                      {p.need && <DetailField icon={Search} label={t('need_l')} text={L(p.need)} />}
                      {p.action && <DetailField icon={Users} label={t('action_l')} text={L(p.action)} />}
                      {p.result && <DetailField icon={Check} label={t('result_l')} text={L(p.result)} />}
                    </div>
                    {p.client && <div className="border-t border-rule px-6 py-4 text-[13px] text-[#8A9199]">{t('by')}: <b className="text-ink">{L(p.client)}</b>{p.demo && <span className="ms-2">({lang === 'fa' ? 'نام نمونه؛ اجازهٔ نشر تأیید نشده' : 'sample name; publication permission unverified'})</span>}</div>}
                  </details>
                ))}
              </div>
            )}
          </div>
        </section>
        {settings.sections?.showTestimonials !== false && <Testimonials items={data.testimonials ?? []} badges={(data.partners ?? []).slice(0, 6)} />}
        <Cta />
      </main>
    </>
  )
}

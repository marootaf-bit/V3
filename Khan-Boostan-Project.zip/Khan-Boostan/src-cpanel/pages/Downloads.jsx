import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero } from '../parts.jsx'

const KIND = { profile: ['پروفایل شرکت', 'Company profile'], catalog: ['کتالوگ', 'Catalogue'], brochure: ['بروشور', 'Brochure'], certificate: ['گواهی‌نامه', 'Certificate'], form: ['فورم', 'Form'], other: ['سند', 'Document'] }
const DocIcon = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /><path d="M14 2v4a2 2 0 0 0 2 2h4" /></svg>
const ExtIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg>

export default function Downloads() {
  const { data } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  if (!data) return <div className="min-h-[70vh]" />
  const docs = [...(data.documents ?? [])].sort(bySort)
  return (
    <>
      <main id="main" className="flex-1">
        <Hero image="/images/trade-documents.webp" crumbs={[[null, t('downloads_t')]]} title={t('downloads_t')} sub={t('downloads_d')} />
        <section className="py-12 md:py-16">
          <div className="wrap grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {docs.length === 0 && <p className="col-span-full py-14 text-center text-slate-500">{t('no_items')}</p>}
            {docs.map((doc, i) => (
              <div className={`rv rv-d${(i % 3) + 1} card flex flex-col gap-2 p-6`} key={doc.id}>
                <div className="mb-1 flex items-center justify-between gap-2">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-brass-pale text-brass-deep"><DocIcon /></span>
                  <span className="rounded-full bg-mist-100 px-2.5 py-0.5 text-[11px] font-bold text-[#565E66]">{KIND[doc.kind] ? KIND[doc.kind][lang === 'fa' ? 0 : 1] : t('nav_downloads')}</span>
                </div>
                <h3 className="text-[16.5px]">{L(doc.title)}</h3>
                <p className="text-[14px] text-slate-500">{L(doc.description)}</p>
                <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-[#8A9199]">
                  {doc.lang && <span>{t('lang_l')}: {doc.lang === 'fa+en' ? (lang === 'fa' ? 'دری و انگلیسی' : 'Dari & English') : doc.lang === 'fa' ? (lang === 'fa' ? 'دری' : 'Dari') : (lang === 'fa' ? 'انگلیسی' : 'English')}</span>}
                  {doc.size && <span>{t('size_l')}: {doc.size}</span>}
                  {doc.updated && <span>{t('updated_l')}: {doc.updated}</span>}
                </div>
                <span className="mt-auto pt-4">{doc.file ? <a href={doc.file} target="_blank" rel="noopener noreferrer" className="btn-ink btn-sm inline-flex">{t('download_l')} <ExtIcon /></a> : <span className="text-[13px] font-bold text-slate-600">{t('pending')}</span>}</span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  )
}

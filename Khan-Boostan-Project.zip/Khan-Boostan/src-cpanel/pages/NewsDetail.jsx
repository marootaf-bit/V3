import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useContent, useReveal } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero } from '../parts.jsx'
import { NotFoundCompact } from './NotFound.jsx'
import NewsCard, { newsCat } from '../components/NewsCard.jsx'

export default function NewsDetail() {
  const { slug } = useParams()
  const { data } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  const [copied, setCopied] = useState(false)
  if (!data) return <div className="min-h-[70vh]" />
  const n = (data.news ?? []).find((x) => x.id === slug)
  if (!n) return <NotFoundCompact />
  const catLabel = newsCat(n.category, lang)
  const related = (data.news ?? []).filter((x) => x.id !== n.id).sort((a, b) => ((b.category === n.category) - (a.category === n.category)) || (b.date ?? '').localeCompare(a.date ?? '')).slice(0, 3)
  const share = async () => {
    const url = window.location.href
    if (navigator.share) { try { await navigator.share({ title: L(n.title), url }); return } catch {} }
    try { await navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 2000) } catch {}
  }
  return (
    <>
      <main id="main" className="flex-1">
        <Hero image={null} crumbs={[['/news', t('news_t')], [null, L(n.title)]]} title={L(n.title)} sub={L(n.excerpt)} />
        <article className="py-12 md:py-16">
          <div className="wrap-narrow">
            <div className="rv mb-8 flex flex-wrap items-center gap-3 text-[13.5px] text-slate-500">
              <time dateTime={n.date}>{n.date}</time>
              {n.category && <span className="rounded-full bg-mist-100 px-2.5 py-0.5 text-[11.5px] font-bold text-[#565E66]">{catLabel}</span>}
              {n.demo && <span className="rounded-full border border-[#dfc5b2] bg-[#fff7f1] px-2.5 py-0.5 text-[11.5px] font-bold text-[#7b4328]">{t('demo')}</span>}
              <button onClick={share} className="ms-auto inline-flex items-center gap-1.5 rounded-full border border-rule px-3 py-1.5 text-[12.5px] font-bold text-[#565E66] transition-colors hover:border-brass hover:text-brass-dark">
                {copied ? (<><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className="text-ok"><path d="M20 6 9 17l-5-5" /></svg>{t('copied')}</>) : (<><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2" /><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" /></svg>{t('share')}</>)}
              </button>
            </div>
            {n.image && <img src={n.image} alt={L(n.title)} className="rv mb-8 aspect-[16/9] w-full rounded-card object-cover shadow-card" />}
            <div className="rv prose-kb whitespace-pre-line text-[16.5px] leading-[2.1] text-slate-700">{L(n.body)}</div>
            {n.source && <p className="mt-6 border-t border-rule pt-4 text-[13px] text-[#8A9199]">{t('source_l')}: {n.source}</p>}
            <div className="mt-10 flex flex-wrap gap-3">
              <Link to="/news" className="btn-line btn-sm">{t('back')}</Link>
              <Link to="/contact?kind=cooperation" className="btn-brass btn-sm">{t('cooperate')}</Link>
            </div>
            {related.length > 0 && (
              <div className="mt-16">
                <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
                  <div className="max-w-[62ch]">
                    <div className="eyebrow mb-2 text-brass-dark">{t('news_t')}</div>
                    <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('related_news')}</h2>
                  </div>
                </div>
                <div className="grid gap-5 md:grid-cols-3">
                  {related.map((x, i) => (
                    <div className={`rv rv-d${i + 1}`} key={x.id}><NewsCard n={x} /></div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </article>
      </main>
    </>
  )
}

import { Link, useSearchParams } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero, Cta } from '../parts.jsx'
import ProductCard from '../components/ProductCard.jsx'

const faN = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d])

export default function Products() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  const [sp, setSearchParams] = useSearchParams()
  const q = sp.get('q') || ''
  const cat = sp.get('c') || 'all'
  const updateFilters = (key, value) => {
    const next = new URLSearchParams(sp)
    if (value && value !== 'all') next.set(key, value)
    else next.delete(key)
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }
  if (!data) return <div className="min-h-[70vh]" />
  const cats = data.categories ?? []
  const brands = (data.brands ?? []).filter((b) => b)
  const docs = (data.documents ?? []).filter((d) => d.kind === 'catalog')
  let list = [...(data.products ?? [])].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || bySort(a, b))
  if (cat !== 'all') list = list.filter((p) => p.category === cat)
  if (q.trim()) {
    const x = q.trim().toLowerCase()
    list = list.filter((p) => [p.name?.fa, p.name?.en, p.short?.fa, p.short?.en].some((v) => (v ?? '').toLowerCase().includes(x)))
  }
  return (
    <>
      <main id="main" className="site-products flex-1">
        <Hero image="/design/product-spectrum.jpg" imageNote={lang === 'fa' ? 'تصویر مفهومی برای پیش‌نمایش؛ نمای کالای واقعی شرکت نیست.' : 'Concept image for this preview; not actual company inventory.'} crumbs={[[null, t('nav_products')]]} title={t('nav_products')} sub={t('products_d')} />
        <section className="py-12 md:py-16">
          <div className="wrap">
            <div className="rv mb-6 rounded-card border border-mist-200 bg-mist-50 p-4 text-[13.5px] text-[#565E66]">{lang === 'fa' ? 'این بخش کاتالوگ شرکتی است؛ دامنهٔ کالاها بر اساس نیاز بازار و درخواست مشتریان قابل تغییر است و قیمت، سبد خرید و پرداخت آنلاین در آن درج نمی‌شود.' : 'This is a corporate catalogue; the range of goods follows market need and client requests. Prices, carts and online payment are not part of it.'}
              {(data.products ?? []).some((p) => p.demo) && <span className="mt-2 block font-bold text-brass-dark">{lang === 'fa' ? 'کالاها و مشخصات درج‌شده در این نسخه نمونه‌اند و نیاز به تأیید دارند.' : 'Products and specifications in this preview are samples and need verification.'}</span>}</div>
            <div className="mb-9 grid items-center gap-4 lg:grid-cols-[minmax(230px,320px)_minmax(0,1fr)_auto]">
              <label className="flex min-h-[46px] items-center gap-2.5 rounded-xl border border-rule bg-white px-4 transition focus-within:border-brass focus-within:ring-4 focus-within:ring-brass/15">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-slate-400"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.34-4.34" /></svg>
                <input type="search" placeholder={t('search_products')} aria-label={t('search_products')} className="w-full bg-transparent outline-none placeholder:text-slate-400" value={q} onChange={(e) => updateFilters('q', e.target.value)} />
              </label>
              <div className="site-filters flex flex-wrap items-center gap-2" role="group" aria-label={lang === 'fa' ? 'دسته‌بندی' : 'Category'} tabIndex={0}>
                <button className={`chip ${cat === 'all' ? 'chip-on' : ''}`} aria-pressed={cat === 'all'} onClick={() => updateFilters('c', 'all')}>{t('all')}</button>
                {cats.map((c) => (
                  <button className={`chip ${cat === c.id ? 'chip-on' : ''}`} aria-pressed={cat === c.id} onClick={() => updateFilters('c', c.id)} key={c.id}>{L(c.name)}</button>
                ))}
              </div>
              <span className="text-[13.5px] text-slate-500" aria-live="polite">{lang === 'fa' ? faN(list.length) + ' محصول' : list.length + ' products'}</span>
            </div>
            {list.length === 0 ? (
              <div className="grid place-items-center gap-4 py-16 text-center">
                <span className="grid h-14 w-14 place-items-center rounded-full bg-mist-100 text-[#A7AEB5]"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.34-4.34" /></svg></span>
                <p className="text-slate-500">{t('no_results')}</p>
                <button className="btn-line btn-sm" onClick={() => setSearchParams({}, { replace: true, preventScrollReset: true })}>{lang === 'fa' ? 'پاک‌کردن فیلترها' : 'Clear filters'}</button>
              </div>
            ) : (
              <div className="site-product-list grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {list.map((p, i) => (
                  <div className={`rv rv-d${(i % 3) + 1}`} key={p.id}><ProductCard p={p} /></div>
                ))}
              </div>
            )}
            {(brands.length > 0 || docs.length > 0) && (
              <div className="rv mt-14 grid gap-5 md:grid-cols-2">
                {brands.length > 0 && settings.sections?.showPartners !== false && (
                  <Link to="/partners#brands" className="card flex items-center gap-4 p-6 no-underline transition-colors hover:border-brass">
                    <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brass-pale text-brass-dark"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /></svg></span>
                    <span><b className="block text-[16px] text-ink">{t('brands_offered')}</b><span className="text-[13.5px] text-[#565E66]">{lang === 'fa' ? 'فهرست برندها با توضیح دقیق نوع رابطه' : 'Brand list with the exact type of relation'}</span></span>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ms-auto text-brass-dark rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                  </Link>
                )}
                {docs.length > 0 && settings.sections?.showDownloads !== false && (
                  <Link to="/downloads" className="card flex items-center gap-4 p-6 no-underline transition-colors hover:border-brass">
                    <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brass-pale text-brass-dark"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /><path d="M14 2v4a2 2 0 0 0 2 2h4" /></svg></span>
                    <span><b className="block text-[16px] text-ink">{t('catalog_t')}</b><span className="text-[13.5px] text-[#565E66]">{lang === 'fa' ? 'کاتالوگ‌های مرتبط از مرکز دانلود' : 'Related catalogues in the download centre'}</span></span>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ms-auto text-brass-dark rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                  </Link>
                )}
              </div>
            )}
          </div>
        </section>
        <Cta />
      </main>
    </>
  )
}

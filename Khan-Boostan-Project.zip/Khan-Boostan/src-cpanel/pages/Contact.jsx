import { Link, useLocation } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero, ArrowIcon } from '../parts.jsx'

const Stroke = ({ className, children }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>{children}</svg>
const Pin = (props) => <Stroke {...props}><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0" /><circle cx="12" cy="10" r="3" /></Stroke>
const Phone = (props) => <Stroke {...props}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2.4 2.4 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2.4 2.4 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92" /></Stroke>
const Mail = (props) => <Stroke {...props}><rect width="20" height="16" x="2" y="4" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></Stroke>
const Clock = (props) => <Stroke {...props}><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></Stroke>
const Ext = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg>
const WA = () => <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.08-.3-.15-1.26-.47-2.4-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.53.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.5 0 1.46 1.07 2.88 1.22 3.08.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.7.63.71.22 1.36.2 1.87.11.57-.08 1.76-.72 2-1.41.25-.7.25-1.29.18-1.42-.08-.12-.28-.2-.57-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88a9.83 9.83 0 0 1 9.88 9.88c0 5.45-4.44 9.89-9.88 9.89M20.47 3.5A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.9c0 2.1.55 4.14 1.59 5.94L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.68 1.45c6.55 0 11.89-5.34 11.89-11.9 0-3.18-1.24-6.16-3.46-8.4" /></svg>

const SOCIAL = [
  ['facebook', 'Facebook', <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.45 2.89h-2.33v6.99A10 10 0 0 0 22 12" /></svg>],
  ['instagram', 'Instagram', <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" /><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37" /><line x1="17.5" x2="17.51" y1="6.5" y2="6.5" /></svg>],
  ['linkedin', 'LinkedIn', <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12M7.12 20.45H3.56V9h3.56zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.72C24 .77 23.2 0 22.22 0" /></svg>],
  ['twitter', 'X', <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M18.24 2.25h3.31l-7.23 8.26 8.5 11.24h-6.66l-5.21-6.82-5.97 6.82H1.67l7.73-8.84L1.25 2.25h6.83l4.71 6.23zm-1.16 17.52h1.83L7.08 4.13H5.12z" /></svg>],
  ['youtube', 'YouTube', <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81M9.55 15.57V8.43L15.82 12z" /></svg>],
]
function SocialLinks({ contact }) {
  const links = SOCIAL.filter(([field]) => (contact[field] ?? '').trim())
  return links.length ? <div className="flex items-center gap-2">{links.map(([field, label, icon]) => <a href={contact[field]} target="_blank" rel="noopener noreferrer" aria-label={label} className="grid h-9 w-9 place-items-center rounded-full border border-mist-300 text-[#565E66] transition-colors hover:border-brass hover:text-brass-dark" key={field}>{icon}</a>)}</div> : null
}

export default function Contact() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  const location = useLocation()
  useReveal()
  const query = new URLSearchParams(location.search)
  const requested = query.get('kind')
  const kind = ['contact', 'product', 'cooperation'].includes(requested) ? requested : 'contact'
  const subject = (query.get('subject') || '').slice(0, 160)
  const kindLabel = { contact: t('kind_general'), product: t('kind_product'), cooperation: t('kind_partner') }[kind]
  if (!data) return <div className="min-h-[70vh]" />
  const contact = settings.contact ?? {}, sections = settings.sections ?? {}
  const faq = [...(data.faq ?? [])].sort(bySort).filter((x) => x.topic === 'general' || x.topic === 'order').slice(0, 4)
  const waUrl = contact.whatsapp ? `https://wa.me/${String(contact.whatsapp).replace(/[^0-9]/g, '')}` : null
  const ways = [
    [Pin, t('address'), L(contact.address)],
    ...(contact.phone ? [[Phone, t('phone'), contact.phone, `tel:${contact.phone}`]] : []),
    ...(waUrl ? [[WA, t('whatsapp_l'), contact.whatsapp, waUrl, true]] : []),
    ...(contact.email ? [[Mail, t('email'), contact.email, `mailto:${contact.email}`]] : []),
    [Clock, t('hours'), L(contact.hours)],
  ]
  return (
    <>
      <main id="main" className="site-contact flex-1">
        <Hero image="/images/about-office.webp" imageNote={lang === 'fa' ? 'تصویر نمایشی؛ دفتر واقعی شرکت نیست.' : 'Illustrative image; not the company office.'} crumbs={[[null, t('nav_contact')]]} title={t('contact_title')} sub={t('contact_intro')} />
        <section className="kb-contact-channel-band" aria-labelledby="contact-channels-title">
          <div className="wrap">
            <div className="kb-contact-channel-heading">
              <div className="eyebrow">{t('contact_t')}</div>
              <h2 id="contact-channels-title">{t('ways')}</h2>
              <p>{lang === 'fa' ? 'معلومات این بخش از داده‌های پیش‌نمایش است و پیش از نشر رسمی باید تأیید شود.' : 'These details come from preview data and need confirmation before publication.'}</p>
            </div>
            <ul id="contact-ways" className="kb-contact-channel-grid scroll-mt-28">
              {ways.map(([Icon, label, value, href, external], i) => (
                <li className="kb-contact-channel-card" key={i}>
                  <span className="kb-contact-channel-icon"><Icon /></span>
                  <div>
                    <strong>{label}</strong>
                    {href ? <a href={href} dir={href.startsWith('mailto:') || /^[+0-9\s()-]+$/.test(String(value)) ? 'ltr' : undefined} {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>{value}</a> : <span>{value || t('pending')}</span>}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>
        <section className="kb-contact-main">
          <div className="wrap kb-contact-two-col">
            <div className="kb-contact-copy">
              <div className="eyebrow">{t('contact_t')}</div>
              <h2>{lang === 'fa' ? 'گفتگو از یک نیاز روشن آغاز می‌شود.' : 'A good conversation starts with a clear need.'}</h2>
              <p>{lang === 'fa' ? 'برای پرسش دربارهٔ کالا، تأمین یا همکاری، موضوع و مشخصات موردنیاز را آماده کنید. فرمِ روبه‌رو فقط طرح پیش‌نمایش است و پیام نمی‌فرستد.' : 'For questions about goods, sourcing or cooperation, prepare the topic and relevant details. The form alongside is a design preview and cannot send messages.'}</p>
              {contact.email && <a className="btn-coral kb-contact-mail-action" href={`mailto:${contact.email}`}>{lang === 'fa' ? 'تماس از راه ایمیل' : 'Contact by email'} <Mail /></a>}
              <div className="kb-contact-prep">
                <h3>{lang === 'fa' ? 'برای گفتگوی دقیق‌تر' : 'For a more useful conversation'}</h3>
                <ul>
                  <li>{lang === 'fa' ? 'موضوع کالا یا همکاری' : 'The goods or cooperation topic'}</li>
                  <li>{lang === 'fa' ? 'مشخصات و مقدار موردنیاز' : 'Relevant specifications and quantity'}</li>
                  <li>{lang === 'fa' ? 'بازار یا مقصد موردنظر' : 'The intended market or destination'}</li>
                </ul>
              </div>
              <SocialLinks contact={contact} />
              {contact.mapUrl && <a href={contact.mapUrl} target="_blank" rel="noopener noreferrer" className="kb-contact-map-link"><Pin />{t('map_t')}<Ext /></a>}
            </div>
            <section className="kb-contact-form-card" aria-labelledby="contact-preview-title">
              <span className="kb-form-preview-badge">{lang === 'fa' ? 'فقط پیش‌نمایش' : 'Preview only'}</span>
              <h2 id="contact-preview-title">{lang === 'fa' ? 'نمونهٔ فرم تماس' : 'Contact form layout'}</h2>
              <p className="kb-form-disabled-note">{t('form_disabled_note')}</p>
              <div className="kb-contact-request-context">
                <p><b>{t('kind')}:</b> {kindLabel}</p>
                {subject && <p><b>{t('subject_l')}:</b> {subject}</p>}
              </div>
              <form noValidate onSubmit={(event) => event.preventDefault()}>
                <fieldset disabled>
                  <legend className="sr-only">{t('form_title')}</legend>
                  <div className="kb-contact-fields">
                    <div><label className="label" htmlFor="f-name">{t('name')}</label><input id="f-name" className="field" placeholder={t('name_ph')} /></div>
                    <div><label className="label" htmlFor="f-company">{t('company_l')}</label><input id="f-company" className="field" /></div>
                    <div><label className="label" htmlFor="f-phone">{t('phone_l')}</label><input id="f-phone" className="field" dir="ltr" style={{ textAlign: 'end' }} placeholder={t('phone_ph')} /></div>
                    <div><label className="label" htmlFor="f-email">{t('email_l')}</label><input id="f-email" type="email" className="field" dir="ltr" style={{ textAlign: 'end' }} /></div>
                    <div className="kb-contact-full"><label className="label" htmlFor="f-subject">{t('subject_l')}</label><input id="f-subject" className="field" value={subject} readOnly /></div>
                    <div className="kb-contact-full"><label className="label" htmlFor="f-msg">{t('message_l')}</label><textarea id="f-msg" className="field" rows="5" placeholder={t('message_ph')} /></div>
                  </div>
                  <button type="submit" className="btn-brass kb-contact-disabled-submit" disabled>{lang === 'fa' ? 'ارسال پیام (غیرفعال)' : 'Send message (disabled)'}</button>
                </fieldset>
              </form>
              <p className="kb-contact-privacy-note">{lang === 'fa' ? 'هیچ داده‌ای در این فرم ثبت نمی‌شود.' : 'No information is collected by this form.'} <Link to="/privacy">{t('nav_privacy')}</Link></p>
            </section>
          </div>
          {sections.showFaq !== false && faq.length > 0 && (
            <div id="faq" className="wrap mt-16 scroll-mt-28">
              <h2 className="mb-6 text-[clamp(20px,2.2vw,26px)]">{t('faq_t')}</h2>
              <div className="grid gap-4 md:grid-cols-2">{faq.map((q, i) => (
                <details className={`faq-item rv rv-d${(i % 2) + 1}`} open={i === 0 ? true : undefined} key={q.id ?? i}>
                  <summary>{L(q.q)}<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-brass-dark transition-transform"><path d="m6 9 6 6 6-6" /></svg></summary>
                  <div className="faq-body">{L(q.a)}</div>
                </details>
              ))}</div>
            </div>
          )}
        </section>
      </main>
    </>
  )
}

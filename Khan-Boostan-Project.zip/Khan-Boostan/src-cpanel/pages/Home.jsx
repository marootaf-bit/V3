import { Link } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict, publicItemName } from '../lib.jsx'
import { newsCat } from '../components/NewsCard.jsx'

/* ثابت‌های صفحهٔ خانه (عیناً از phase-14) */
const CAT_IMG = { food: '/images/product-rice.webp', agri: '/images/product-dried-fruit.webp', construction: '/images/product-cement.webp', machinery: '/images/product-generator.webp', household: '/images/product-kitchenware.webp', textile: '/images/product-fabric.webp', energy: '/images/product-solar.webp', spare: '/images/product-spareparts.webp' }
const STEPS = {
  fa: [['۰۱', 'درخواست و شناخت نیاز', 'گفتگو با مشتری یا شرکت، تعیین مشخصات و مقدار'], ['۰۲', 'بررسی و تأمین', 'انتخاب تأمین‌کننده بر اساس اصول مشخص، اعلام شفاف قیمت و شرایط'], ['۰۳', 'هماهنگی و آماده‌سازی', 'کنترل کیفیت و بسته‌بندی، تکمیل اسناد'], ['۰۴', 'انتقال و تحویل', 'پیگیری تا تحویل، اطلاع‌رسانی روشن']],
  en: [['01', 'Request & scoping', 'Talk with the client, agree specifications and quantity'], ['02', 'Review & sourcing', 'Choose suppliers on clear principles, transparent pricing'], ['03', 'Coordination & prep', 'Quality control, packing and documents'], ['04', 'Shipping & delivery', 'Follow-up until delivery, clear updates']],
}
const faN = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d])
const feat = (a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0)

export default function Home() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  if (!data) return <div className="min-h-[70vh]" />

  const hero = settings.hero ?? {}, act = settings.activities ?? {}
  const comp = settings.company ?? {}, contact = settings.contact ?? {}, sec = settings.sections ?? {}
  const sortedProducts = [...(data.products ?? [])].sort((a, b) => feat(a, b) || bySort(a, b))
  const products6 = sortedProducts.filter((p, i) => sortedProducts.findIndex((v) => v.category === p.category) === i).slice(0, 6)
  const news3 = [...(data.news ?? [])].sort((a, b) => feat(a, b) || (b.date ?? '').localeCompare(a.date ?? '')).slice(0, 3)
  const projects3 = [...(data.projects ?? [])].sort((a, b) => feat(a, b) || bySort(a, b)).slice(0, 3)
  const steps = STEPS[lang === 'en' ? 'en' : 'fa']
  const cats = data.categories ?? []
  const profileDoc = (data.documents ?? []).find((d) => d.kind === 'profile')
  const principles = comp.principles ?? []
  const catName = (id) => L((cats.find((c) => c.id === id) ?? {}).name, '')
  const heroTitle = L(hero.title) || L(comp.name)
  const titleSplit = heroTitle.split(lang === 'fa' ? /[؛:]/ : /:/)
  const titleLead = titleSplit.length > 1 ? titleSplit.shift().trim() : ''
  const titleCore = titleSplit.join(lang === 'fa' ? '؛ ' : ': ').trim() || heroTitle

  return (
    <main id="main" className="site-home flex-1">
      <section className="home-hero kb-editorial-hero" aria-labelledby="home-title">
        <div className="wrap kb-editorial-grid">
          <div className="home-hero-copy">
            <div className="kb-hero-kicker"><span aria-hidden="true"></span>{lang === 'fa' ? 'تجارت در چند حوزه' : 'Trade across sectors'}</div>
            <h1 id="home-title" aria-label={heroTitle}>
              {titleLead && <span className="kb-hero-title-lead">{titleLead}</span>}
              <span className="kb-hero-title-core">{titleCore}</span>
            </h1>
            <p>{L(hero.text)}</p>
            <div className="kb-hero-actions">
              <Link className="btn-coral" to="/activities">{t('nav_activities')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180" aria-hidden="true"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
              <Link className="btn-line" to="/contact">{t('nav_contact')}</Link>
            </div>
            <p className="kb-hero-assurance">{lang === 'fa' ? 'کاتالوگ چندبخشی · بدون خرید یا پرداخت آنلاین' : 'Multi-sector catalogue · no online checkout'}</p>
          </div>
          <figure className="kb-home-hero-media">
            <img src="/design/commerce-editorial.jpg" alt="" fetchPriority="high" width="1122" height="1402" />
            <figcaption>{lang === 'fa' ? 'تصاویر مفهومیِ این بخش برای پیش‌نمایش‌اند؛ نمای دفتر یا فعالیت واقعی شرکت نیستند.' : 'Concept imagery for this preview; not actual company premises or operations.'}</figcaption>
          </figure>
        </div>
        <nav className="wrap kb-hero-paths" aria-label={lang === 'fa' ? 'مسیرهای تجارتی' : 'Trade pathways'}>
          <Link to="/import"><span aria-hidden="true">01</span>{L(settings.pages?.import?.title, lang === 'fa' ? 'واردات' : 'Import')}<b aria-hidden="true">↗</b></Link>
          <Link to="/export"><span aria-hidden="true">02</span>{L(settings.pages?.export?.title, lang === 'fa' ? 'صادرات' : 'Export')}<b aria-hidden="true">↗</b></Link>
          <Link to="/products"><span aria-hidden="true">03</span>{t('nav_products')}<b aria-hidden="true">↗</b></Link>
        </nav>
      </section>
      <section className="home-intro bg-white py-16 md:py-24">
        <div className="wrap grid items-center gap-12 md:grid-cols-2 md:gap-16">
          <div className="rv">
            <div className="eyebrow mb-3 text-brass-dark">{t('about_t')}</div>
            <h2 className="mb-4" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>
              {lang === 'fa' ? (<>تجارتی که از <span className="text-brass-deep">نیاز بازار</span> آغاز می‌شود</>) : (<>Trade that starts from <span className="text-brass-deep">market need</span></>)}
            </h2>
            <p className="mb-4 text-[15px] leading-relaxed text-[#565E66]">{String(L(comp.about) || '').split('\n')[0]}</p>
            <p className="mb-6 text-[15px] leading-relaxed text-[#565E66]">{L(comp.approach)}</p>
            <Link className="link-more" to="/about">{t('read_more')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
          </div>
          <figure className="rv kb-intro-image">
            <img src="/images/trade-documents.webp" alt="" loading="lazy" width="1600" height="1000" />
            <figcaption>{lang === 'fa' ? 'تصویر نمایشی از اسناد تجارتی' : 'Illustrative trade documents'}</figcaption>
          </figure>
        </div>
      </section>
      <section className="home-trades py-16 md:py-20">
        <div className="wrap">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
            <div className="max-w-[62ch]">
              <div className="eyebrow mb-2 text-brass-dark">{t('nav_activities')}</div>
              <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('trade_intro_t')}</h2>
              <p className="mt-2 text-[#565E66]">{t('trade_intro_d')}</p>
            </div>
            <Link className="btn-line btn-sm" to="/activities">{t('view_all')}</Link>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            <Link className="card group rv rv-d1 relative flex h-full flex-col overflow-hidden no-underline" to="/import">
              <div className="aspect-[16/9] overflow-hidden"><img src="/images/trade-warehouse.webp" alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
              <div className="flex flex-1 flex-col gap-2 p-6 pt-0">
                <span className="relative z-[2] -mt-5 grid h-11 w-11 place-items-center rounded-xl bg-white text-brass-dark shadow-card ring-1 ring-mist-200"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1" /><path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76" /><path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6" /><path d="M12 10v4" /><path d="M12 2v3" /></svg></span>
                <h3 className="mt-2 text-[18px]">{L(settings.pages?.import?.title, lang === 'fa' ? 'واردات کالا' : 'Import of goods')}</h3>
                <p className="line-clamp-3 text-[14px] leading-relaxed text-[#565E66]">{L(settings.pages?.import?.intro)}</p>
              </div>
            </Link>
            <Link className="card group rv rv-d2 relative flex h-full flex-col overflow-hidden no-underline" to="/export">
              <div className="aspect-[16/9] overflow-hidden"><img src="/images/trade-cargo.webp" alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
              <div className="flex flex-1 flex-col gap-2 p-6 pt-0">
                <span className="relative z-[2] -mt-5 grid h-11 w-11 place-items-center rounded-xl bg-white text-brass-dark shadow-card ring-1 ring-mist-200"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" /><path d="m3.3 7 8.7 5 8.7-5" /><path d="M12 22V12" /></svg></span>
                <h3 className="mt-2 text-[18px]">{L(settings.pages?.export?.title, lang === 'fa' ? 'صادرات محصولات' : 'Export of products')}</h3>
                <p className="line-clamp-3 text-[14px] leading-relaxed text-[#565E66]">{L(settings.pages?.export?.intro)}</p>
              </div>
            </Link>
            <Link className="card group rv rv-d3 relative flex h-full flex-col overflow-hidden no-underline" to="/activities">
              <div className="aspect-[16/9] overflow-hidden"><img src="/images/trade-port.webp" alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
              <div className="flex flex-1 flex-col gap-2 p-6 pt-0">
                <span className="relative z-[2] -mt-5 grid h-11 w-11 place-items-center rounded-xl bg-white text-brass-dark shadow-card ring-1 ring-mist-200"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" /><path d="M2 12h20" /></svg></span>
                <h3 className="mt-2 text-[18px]">{lang === 'fa' ? 'تأمین و تجارت بین‌المللی' : 'Sourcing & international trade'}</h3>
                <p className="line-clamp-3 text-[14px] leading-relaxed text-[#565E66]">{L(act.sourcing)}</p>
              </div>
            </Link>
          </div>
        </div>
      </section>
      {sec.showProducts !== false && cats.length > 0 && (
        <section className="home-categories bg-white py-14 md:py-16">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('nav_products')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('categories_t')}</h2>
                <p className="mt-2 text-[#565E66]">{t('categories_d')}</p>
              </div>
              <Link className="btn-line btn-sm" to="/products">{t('view_all')}</Link>
            </div>
            <div className="home-category-grid grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {cats.map((c, i) => {
                const n = (data.products ?? []).filter((p) => p.category === c.id).length
                return (
                  <Link key={c.id} className={`kb-category-tile rv rv-d${(i % 4) + 1} group no-underline`} to={`/products/?c=${c.id}`}>
                    <img src={CAT_IMG[c.id] ?? '/images/product-rice.webp'} alt="" loading="lazy" className="transition-transform duration-300 group-hover:scale-105" />
                    <span className="kb-category-label">
                      <b>{L(c.name)}</b>
                      <span aria-label={lang === 'fa' ? `${faN(n)} مورد نمایشی` : `${n} sample items`}>{lang === 'fa' ? faN(n) : n}</span>
                    </span>
                  </Link>
                )
              })}
            </div>
          </div>
        </section>
      )}
      {sec.showProducts !== false && products6.length > 0 && (
        <section className="home-featured home-process py-16 md:py-24">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('nav_products')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'محصولات منتخب' : 'Selected products'}</h2>
                <p className="mt-2 text-[#565E66]">{lang === 'fa' ? 'نمونه‌ای از کالاهایی که در واردات یا صادرات آن‌ها فعالیت داریم.' : 'A sample of the goods we trade in import or export.'}</p>
              </div>
              <Link className="btn-line btn-sm" to="/products">{t('view_all')}</Link>
            </div>
            <div className="home-product-list grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {products6.map((p, i) => (
                <div key={p.id} className={`rv rv-d${(i % 3) + 1}`}>
                  <Link className="kb-product-card card group flex h-full flex-col overflow-hidden no-underline" to={`/products/${p.id}/`}>
                    <div className="kb-card-media relative aspect-[4/3] overflow-hidden bg-mist-100">
                      <img src={p.image} alt={publicItemName(L(p.name))} loading="lazy" decoding="async" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                      <span className="absolute start-3 top-3 flex gap-1.5">
                        {p.featured && <span className="rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured_badge', lang === 'fa' ? 'ویژه' : 'Featured')}</span>}
                      </span>
                    </div>
                    <div className="kb-card-content flex flex-1 flex-col gap-2 p-5">
                      <span className="kb-card-meta flex items-center justify-between gap-2 text-[12px] font-bold text-brass-dark">
                        {catName(p.category)}
                        <span className="rounded-full border px-2 py-0.5 text-[10.5px] font-bold bg-brass-pale text-brass-dark border-[#F1C9B8]">{t('status_' + p.status, p.status)}</span>
                      </span>
                      <h3 className="text-[17px] leading-relaxed">{publicItemName(L(p.name))}</h3>
                      <p className="line-clamp-2 text-[13.5px] text-[#565E66]">{L(p.short)}</p>
                      <span className="kb-card-action mt-auto inline-flex items-center gap-2 pt-2 text-[13.5px] font-bold text-ink transition-colors group-hover:text-brass-dark">{t('view_details')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:-translate-x-1 rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></span>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
      <section className="home-values bg-white py-16 md:py-20">
        <div className="wrap">
          <div className="mb-8 md:mb-10">
            <div className="eyebrow mb-2 text-brass-dark">{t('why_t')}</div>
            <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('reasons_t')}</h2>
            <p className="mt-2 text-[#565E66]">{t('reasons_d')}</p>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {principles.map((v, i) => (
              <div key={i} className={`rv rv-d${(i % 3) + 1} card flex h-full items-start gap-4 p-6`}>
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-brass-pale font-head text-[15px] font-bold text-brass-dark">{String(i + 1).padStart(2, '0')}</span>
                <span>
                  <b className="mb-1 block text-[16px] text-ink">{L(v.title)}</b>
                  <span className="block text-[13.5px] leading-relaxed text-[#565E66]">{L(v.text)}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="home-process-steps py-16 md:py-24">
        <div className="wrap">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4 md:mb-14">
            <div>
              <div className="eyebrow mb-2 text-brass-dark">{t('nav_process')}</div>
              <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? (<>از درخواست تا تحویل، در <span className="text-brass-deep">چهار گام</span></>) : (<>From request to delivery, in <span className="text-brass-deep">four steps</span></>)}</h2>
            </div>
            <Link className="btn-line btn-sm" to="/process">{lang === 'fa' ? 'جزئیات روند' : t('nav_process')}</Link>
          </div>
          <div className="relative grid gap-8 md:grid-cols-4 md:gap-6">
            <span className="step-line inset-x-[12%] hidden md:block" aria-hidden="true"></span>
            {steps.map((s, i) => (
              <div key={i} className={`rv rv-d${i + 1} relative flex gap-4 md:flex-col md:items-center md:text-center`}>
                <span className="step-dot">{s[0]}</span>
                <div>
                  <h3 className="mb-1.5 text-[17px]">{s[1]}</h3>
                  <p className="text-[14px] leading-relaxed text-[#565E66]">{s[2]}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      {sec.showProjects !== false && projects3.length > 0 && (
        <section className="home-cases bg-white py-16 md:py-20">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div>
                <div className="eyebrow mb-2 text-brass-dark">{lang === 'fa' ? 'سوابق و نمونه‌های همکاری' : 'Track record & cases'}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{lang === 'fa' ? 'سوابق و نمونه‌های همکاری' : 'Track record & selected cases'}</h2>
              </div>
              <Link className="btn-line btn-sm" to="/projects">{t('view_all')}</Link>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              {projects3.map((pr, i) => (
                <article key={pr.id} className={`card rv rv-d${i + 1} flex h-full flex-col gap-2 overflow-hidden p-0`}>
                  <img src={pr.image} alt="" loading="lazy" className="aspect-[16/9] w-full object-cover" />
                  <div className="flex flex-1 flex-col gap-2 p-6">
                    <span className="flex items-center gap-2">
                      <span className="tag">{L(pr.sector)}</span>
                      <span className="text-[12px] text-[#8A9199]">{pr.year}</span>
                    </span>
                    <h3 className="mt-1 text-[16.5px] leading-relaxed">{L(pr.title)}</h3>
                    <p className="line-clamp-3 text-[13.5px] text-[#565E66]">{L(pr.result)}</p>
                    <span className="mt-auto pt-3 text-[12.5px] text-[#8A9199]">{lang === 'fa' ? 'از: ' : 'by: '}{L(pr.client)}</span>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}
      {sec.showNews !== false && news3.length > 0 && (
        <section className="home-news bg-white py-16 md:py-24">
          <div className="wrap">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
              <div className="max-w-[62ch]">
                <div className="eyebrow mb-2 text-brass-dark">{t('nav_news')}</div>
                <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('nav_news')}</h2>
                <p className="mt-2 text-[#565E66]">{t('news_d')}</p>
              </div>
              <Link className="btn-line btn-sm" to="/news">{t('view_all')}</Link>
            </div>
            <div className="home-news-list grid gap-6 md:grid-cols-3">
              {news3.map((n, i) => (
                <div key={n.id} className={`rv rv-d${i + 1}`}>
                  <Link className="kb-news-card card group flex h-full flex-col overflow-hidden no-underline" to={`/news/${n.id}/`}>
                    <div className="kb-card-media relative aspect-[16/9] overflow-hidden bg-mist-100">
                      <img src={n.image} alt={L(n.title)} loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                      {n.featured && <span className="absolute start-3 top-3 rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured', lang === 'fa' ? 'ویژه' : 'Featured')}</span>}
                    </div>
                    <div className="kb-card-content flex flex-1 flex-col gap-2 p-5">
                      <div className="kb-card-meta flex items-center gap-3 text-[12px] text-[#8A9199]">
                        <time dateTime={n.date}>{n.date}</time>
                        <span className="rounded-full bg-mist-100 px-2 py-0.5 text-[10.5px] font-bold text-[#565E66]">{newsCat(n.category, lang)}</span>
                      </div>
                      <h3 className="text-[16px] leading-relaxed">{L(n.title)}</h3>
                      <p className="line-clamp-2 text-[13.5px] text-[#565E66]">{L(n.excerpt)}</p>
                      <span className="mt-auto flex items-center justify-between gap-3 pt-3">
                        <span className="text-[13px] font-bold text-ink transition-colors group-hover:text-brass-dark">{t('read_more', lang === 'fa' ? 'ادامه مطلب' : 'Read more')}</span>
                        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-brass-pale text-brass-dark transition-colors group-hover:bg-brass group-hover:text-white"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></span>
                      </span>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
      {sec.showDownloads !== false && profileDoc && (
        <section className="home-downloads py-12 md:py-14">
          <div className="wrap">
            <div className="card flex flex-wrap items-center justify-between gap-6 p-6 md:p-8">
              <div className="flex items-center gap-4">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brass-pale text-brass-dark"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg></span>
                <div>
                  <h2 className="text-[18px]">{L(profileDoc.title)}</h2>
                  <p className="text-[13.5px] text-[#565E66]">{t('profile_d')}</p>
                </div>
              </div>
              <Link to={profileDoc.file} target="_blank" rel="noopener noreferrer" className="btn-ink">{t('download_l')} <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg></Link>
            </div>
          </div>
        </section>
      )}
      <section className="band-dark kb-home-contact" aria-labelledby="home-contact-title">
        <div className="wrap kb-home-contact-grid">
          <div>
            <div className="eyebrow">{t('contact_t')}</div>
            <h2 id="home-contact-title">{lang === 'fa' ? 'گفتگو را از یک نیاز روشن آغاز کنیم.' : 'Let’s begin with a clear trade need.'}</h2>
            <p>{lang === 'fa' ? 'برای پرسش دربارهٔ کالا، تأمین یا همکاری تجارتی، راه‌های تماس و معلومات موردنیاز را در صفحهٔ تماس ببینید.' : 'For questions about goods, sourcing or trade cooperation, find contact channels and the information to prepare on our contact page.'}</p>
          </div>
          <div className="kb-home-contact-action">
            <span className="kb-home-contact-line" aria-hidden="true"></span>
            <Link className="btn-coral" to="/contact">{t('nav_contact')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180" aria-hidden="true"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
            {contact.email && <a href={`mailto:${contact.email}`} dir="ltr" className="kb-home-contact-email">{contact.email}</a>}
            <small>{lang === 'fa' ? 'ارسال فرم آنلاین در این پیش‌نمایش غیرفعال است.' : 'Online form submission is disabled in this preview.'}</small>
          </div>
        </div>
      </section>
    </main>
  )
}

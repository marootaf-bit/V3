import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict, publicItemName } from '../lib.jsx'
import { Hero } from '../parts.jsx'
import { NotFoundCompact } from './NotFound.jsx'
import ProductCard from '../components/ProductCard.jsx'
import Lightbox from '../components/Lightbox.jsx'

export default function ProductDetail() {
  const { slug } = useParams()
  const { data } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  const [lb, setLb] = useState(null)
  if (!data) return <div className="min-h-[70vh]" />
  const p = (data.products ?? []).find((x) => x.id === slug)
  if (!p) return <NotFoundCompact />
  const cat = (data.categories ?? []).find((c) => c.id === p.category)
  const related = (data.products ?? []).filter((x) => x.id !== p.id && x.category === p.category).slice(0, 3)
  const imgs = p.gallery?.length ? p.gallery : [p.image]
  const rows = [['brand_l', p.brand], ['origin_l', L(p.origin)], ['packaging_l', L(p.packaging)], ['unit_l', L(p.unit)], ['moq_l', p.moq]].filter(([, v]) => v && String(v).trim())
  const displayName = publicItemName(L(p.name))
  const subject = encodeURIComponent(displayName)
  return (
    <>
      <main id="main" className="flex-1">
        <Hero image={null} crumbs={[['/products', t('products_t')], [null, displayName]]} title={displayName} sub={L(p.short)}>
          <nav className="flex flex-wrap items-center gap-2 text-[13px] md:mt-2" aria-label="breadcrumb">
            <Link to="/products" className="text-slate-300 hover:text-white">{t('products_t')}</Link>
            {cat && (<><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rotate-180 opacity-60 rtl:rotate-0"><path d="m15 18-6-6 6-6" /></svg><span className="text-slate-300">{L(cat.name)}</span></>)}
          </nav>
        </Hero>
        <section className="py-12 md:py-16">
          <div className="wrap grid gap-10 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
            <div className="rv">
              <button onClick={() => setLb({ i: 0 })} className="block w-full cursor-zoom-in overflow-hidden rounded-card shadow-card p-0">
                <img src={imgs[0]} alt={displayName} className="aspect-[4/3] w-full object-cover" />
              </button>
              {imgs.length > 1 && (
                <div className="mt-3 grid grid-cols-4 gap-3">
                  {imgs.slice(1, 5).map((x, i) => (
                    <button onClick={() => setLb({ i: i + 1 })} className="cursor-zoom-in p-0" key={i}>
                      <img src={x} alt="" loading="lazy" className="aspect-square w-full rounded-lg object-cover shadow-card" />
                    </button>
                  ))}
                </div>
              )}
              <div className="mt-5 grid gap-3">
                {p.status && (
                  <div className="card flex items-center justify-between gap-3 p-4">
                    <span className="text-[13.5px] font-bold text-ink">{lang === 'fa' ? 'وضعیت عرضه' : 'Supply status'}</span>
                    <span className="rounded-full border px-2.5 py-1 text-[11px] font-bold bg-brass-pale text-brass-dark border-[#F1C9B8]">{t('status_' + p.status, p.status)}</span>
                  </div>
                )}
                {rows.length > 0 && (
                  <dl className="card divide-y divide-rule p-0">
                    {rows.map(([k, v]) => (
                      <div className="flex items-baseline justify-between gap-4 px-5 py-3 text-[14px]" key={k}>
                        <dt className="font-bold text-ink">{t(k)}</dt>
                        <dd className="text-slate-600">{v}</dd>
                      </div>
                    ))}
                  </dl>
                )}
              </div>
            </div>
            <div className="rv">
              <span className="mb-4 flex flex-wrap items-center gap-2">
                {cat && <span className="tag">{L(cat.name)}</span>}
                {p.featured && <span className="rounded-full bg-brass px-2.5 py-0.5 text-[11px] font-bold text-white">{t('featured_badge')}</span>}
              </span>
              <h2 className="mb-4 text-[clamp(22px,2.4vw,30px)]">{lang === 'fa' ? 'معرفی و کاربردها' : 'Overview & applications'}</h2>
              <p className="mb-6 whitespace-pre-line text-slate-600">{L(p.description)}</p>
              {p.specs?.length > 0 && (
                <>
                  <h3 className="mb-3 text-[18px]">{t('specs')}</h3>
                  <dl className="mb-6 overflow-hidden rounded-card border border-rule">
                    {p.specs.map((x, i) => (
                      <div className={`grid grid-cols-[minmax(0,4fr)_minmax(0,8fr)] gap-4 px-5 py-3 text-[14.5px] ${i % 2 ? 'bg-paper' : 'bg-white'}`} key={i}>
                        <dt className="font-bold text-ink">{L(x.k)}</dt>
                        <dd className="text-slate-600">{L(x.v)}</dd>
                      </div>
                    ))}
                  </dl>
                </>
              )}
              <div className="flex flex-wrap gap-3">
                <Link to={`/contact?kind=product&subject=${subject}`} className="btn-brass">{t('get_info')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
                <Link to="/products" className="btn-line">{t('back')}</Link>
              </div>
              <p className="mt-4 flex items-center gap-2 text-[13px] text-[#8A9199]">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /><path d="M14 2v4a2 2 0 0 0 2 2h4" /></svg>
                <Link to="/downloads" className="font-bold text-brass-dark hover:underline">{t('docs_center')}</Link>
              </p>
            </div>
          </div>
          {related.length > 0 && (
            <div className="wrap mt-16">
              <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
                <div className="max-w-[62ch]">
                  <div className="eyebrow mb-2 text-brass-dark">{t('category', lang === 'fa' ? 'دسته‌بندی' : 'Category')}</div>
                  <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('related')}</h2>
                </div>
              </div>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {related.map((x, i) => (
                  <div className={`rv rv-d${i + 1}`} key={x.id}><ProductCard p={x} /></div>
                ))}
              </div>
            </div>
          )}
        </section>
      </main>
      {lb && <Lightbox items={imgs.map((image) => ({ image, caption: null }))} index={lb.i} setIndex={(next) => setLb((current) => ({ i: Math.min(imgs.length - 1, Math.max(0, typeof next === 'function' ? next(current.i) : next)) }))} close={() => setLb(null)} />}
    </>
  )
}

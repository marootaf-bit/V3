import { useState } from 'react'
import { useContent, useReveal, bySort } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero, Cta } from '../parts.jsx'
import Lightbox from '../components/Lightbox.jsx'

const albumKey = (value) => typeof value === 'string' ? value : (value?.fa || value?.en || '')

export default function Gallery() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  const [album, setAlbum] = useState('all')
  const [lb, setLb] = useState(null)
  if (!data) return <div className="min-h-[70vh]" />
  const all = [...(data.gallery ?? [])].sort(bySort)
  // Keep the selected album independent of the display language.
  const albums = [...new Map(all.map((g) => g.album).filter(Boolean).map((value) => [albumKey(value), value])).values()]
  const photos = all.filter((g) => !g.video && (album === 'all' || albumKey(g.album) === album))
  const videos = all.filter((g) => g.video)
  const openPhoto = (index) => setLb({ items: photos.map((g) => ({ image: g.image, caption: g.caption })), index })
  const openVideo = (index) => setLb({ items: videos.map((g) => ({ video: g.video, poster: g.poster || g.image, image: g.image, caption: g.caption })), index })
  return (
    <>
      <main id="main" className="site-gallery flex-1">
        <Hero image="/images/gallery-office.webp" crumbs={[[null, t('nav_news')], [null, t('nav_gallery')]]} title={lang === 'fa' ? 'گالری عکس و ویدیو' : 'Photo & video gallery'} sub={t('gallery_d')} />
        <section className="py-14 md:py-20">
          <div className="wrap">
            {all.some((g) => g.demo) && <p className="mb-6 rounded-xl border border-[#e4d1c0] bg-[#fff8f2] p-4 text-[13.5px] text-ink" role="note">{lang === 'fa' ? 'رسانه‌های این گالری نمونه و نمادین‌اند؛ عکس یا ویدیوی مستندِ فعالیت شرکت محسوب نمی‌شوند.' : 'Gallery media are sample, illustrative assets; they are not documentary footage of the company.'}</p>}
            {albums.length > 1 && <div className="rv mb-9 flex flex-wrap items-center gap-2" role="group" aria-label={t('albums')}>
              <span className="me-2 text-[12.5px] font-bold text-[#8A9199]">{t('albums')}:</span>
              <button className={`chip ${album === 'all' ? 'chip-on' : ''}`} aria-pressed={album === 'all'} onClick={() => setAlbum('all')}>{t('all')}</button>
              {albums.map((a) => (
                <button className={`chip ${album === albumKey(a) ? 'chip-on' : ''}`} aria-pressed={album === albumKey(a)} onClick={() => setAlbum(albumKey(a))} key={albumKey(a)}>{L(a)}</button>
              ))}
            </div>}
            {photos.length === 0 ? <p className="py-14 text-center text-slate-500">{t('no_items')}</p> : <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
              {photos.map((g, i) => (
                <button className={`rv rv-d${(i % 4) + 1} zoom-hover group relative block aspect-[4/3] overflow-hidden rounded-card border border-mist-200 bg-mist-100 p-0 text-start`} onClick={() => openPhoto(i)} key={i}>
                  <img src={g.image} alt={L(g.caption, '')} loading="lazy" className="h-full w-full object-cover" />
                  <span className="absolute end-2 top-2 rounded-full bg-ink/70 px-2.5 py-0.5 text-[10.5px] font-bold text-white backdrop-blur">{L(g.album)}</span>
                  {g.caption && <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/92 to-transparent px-3 pb-2.5 pt-8 text-[12px] font-bold text-white opacity-0 transition-opacity group-hover:opacity-100">{L(g.caption)}</span>}
                </button>
              ))}
            </div>}
            {videos.length > 0 && settings.sections?.showGallery !== false && (
              <div id="videos" className="mt-16 scroll-mt-28">
                <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
                  <div className="max-w-[62ch]">
                    <div className="eyebrow mb-2 text-brass-dark">{t('nav_videos')}</div>
                    <h2 className="" style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{t('nav_videos')}</h2>
                  </div>
                </div>
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  {videos.map((g, i) => (
                    <button className={`rv rv-d${i + 1} group relative block aspect-video overflow-hidden rounded-card border border-mist-200 bg-ink p-0 text-start`} onClick={() => openVideo(i)} key={g.id ?? i}>
                      <img src={g.poster || g.image} alt={L(g.caption, '')} loading="lazy" className="h-full w-full object-cover opacity-85 transition-opacity group-hover:opacity-100" />
                      <span className="absolute inset-0 grid place-items-center">
                        <span className="grid h-14 w-14 place-items-center rounded-full bg-ink/75 text-white backdrop-blur transition-transform group-hover:scale-110"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.14v13.72a1 1 0 0 0 1.5.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86a1 1 0 0 0-1.5.86z" /></svg></span>
                      </span>
                      {g.caption && <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/92 to-transparent px-3 pb-2.5 pt-8 text-[12px] font-bold text-white">{L(g.caption)}</span>}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
        <Cta />
      </main>
      {lb && <Lightbox items={lb.items} index={lb.index} setIndex={(next) => setLb((current) => ({ ...current, index: typeof next === 'function' ? next(current.index) : next }))} close={() => setLb(null)} />}
    </>
  )
}

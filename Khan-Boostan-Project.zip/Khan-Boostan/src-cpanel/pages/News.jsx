import { Link, useSearchParams } from 'react-router-dom'
import { useContent, useReveal } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import { Hero } from '../parts.jsx'
import NewsCard, { newsCat } from '../components/NewsCard.jsx'

export default function News() {
  const { data } = useContent()
  const { t, L, lang } = useDict()
  useReveal()
  const [sp, setSearchParams] = useSearchParams()
  const q = sp.get('q') || ''
  const cat = sp.get('c') || 'all'
  const updateFilters = (key, value) => {
    const next = new URLSearchParams(sp)
    if (value && value !== 'all') next.set(key, value)
    else next.delete(key)
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }
  if (!data) return <div className="min-h-[70vh]" />
  const all = [...(data.news ?? [])].sort((a, b) => (b.date ?? '').localeCompare(a.date ?? ''))
  const cats = [...new Set(all.map((x) => x.category).filter(Boolean))]
  const featured = all.find((x) => x.featured)
  let list = all
  if (cat !== 'all') list = list.filter((x) => x.category === cat)
  if (q.trim()) {
    const x = q.trim().toLowerCase()
    list = list.filter((f) => [f.title?.fa, f.title?.en, f.excerpt?.fa, f.excerpt?.en].some((v) => (v ?? '').toLowerCase().includes(x)))
  }
  const grid = featured && cat === 'all' && !q.trim() ? list.filter((x) => x.id !== featured.id) : list
  const showFeatured = featured && cat === 'all' && !q.trim()
  return (
    <>
      <main id="main" className="site-news flex-1">
        <Hero image="/images/news-exhibition.webp" crumbs={[[null, t('nav_news')]]} title={t('nav_news')} sub={t('news_d')} />
        <section className="py-12 md:py-16">
          <div className="wrap">
            {all.some((item) => item.demo) && <p className="mb-6 rounded-xl border border-[#e4d1c0] bg-[#fff8f2] p-4 text-[13.5px] text-ink" role="note">{lang === 'fa' ? 'خبرهای این پیش‌نمایش نمونه‌اند؛ تاریخ، رویداد و تصاویر پیش از نشر باید تأیید شوند.' : 'News in this preview is sample content; dates, events and images need verification before publication.'}</p>}
            {showFeatured && (
              <Link className="card group rv mb-10 grid overflow-hidden no-underline md:grid-cols-2" to={`/news/${featured.id}/`}>
                <div className="aspect-[16/10] overflow-hidden md:aspect-auto"><img src={featured.image} alt={L(featured.title)} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /></div>
                <div className="flex flex-col justify-center gap-3 p-7 md:p-9">
                  <span className="flex items-center gap-2">
                    <span className="rounded-full bg-brass px-2.5 py-0.5 text-[11px] font-bold text-white">{t('featured_news')}</span>
                    <time className="text-[12.5px] text-[#8A9199]" dateTime={featured.date}>{featured.date}</time>
                    {featured.category && <span className="rounded-full bg-mist-100 px-2 py-0.5 text-[11px] font-bold text-[#565E66]">{newsCat(featured.category, lang)}</span>}
                  </span>
                  <h2 className="text-[clamp(20px,2.2vw,27px)] leading-relaxed">{L(featured.title)}</h2>
                  <p className="line-clamp-3 text-[14.5px] leading-relaxed text-[#565E66]">{L(featured.excerpt)}</p>
                  <span className="inline-flex items-center gap-2 text-[13.5px] font-bold text-brass-dark">{t('read_more')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></span>
                </div>
              </Link>
            )}
            <div className="mb-9 grid items-center gap-4 lg:grid-cols-[minmax(230px,320px)_minmax(0,1fr)]">
              <label className="flex min-h-[46px] items-center gap-2.5 rounded-xl border border-rule bg-white px-4 transition focus-within:border-brass focus-within:ring-4 focus-within:ring-brass/15">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-slate-400"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.34-4.34" /></svg>
                <input type="search" placeholder={t('search_news')} aria-label={t('search_news')} className="w-full bg-transparent outline-none placeholder:text-slate-400" value={q} onChange={(e) => updateFilters('q', e.target.value)} />
              </label>
              <div className="site-filters flex flex-wrap items-center gap-2" role="group" aria-label={lang === 'fa' ? 'دسته‌بندی' : 'Category'} tabIndex={0}>
                <button className={`chip ${cat === 'all' ? 'chip-on' : ''}`} aria-pressed={cat === 'all'} onClick={() => updateFilters('c', 'all')}>{t('all')}</button>
                {cats.map((c) => (
                  <button className={`chip ${cat === c ? 'chip-on' : ''}`} aria-pressed={cat === c} onClick={() => updateFilters('c', c)} key={c}>{newsCat(c, lang)}</button>
                ))}
              </div>
            </div>
            {grid.length === 0 ? (
              <div className="grid place-items-center gap-4 py-16 text-center">
                <p className="text-slate-500">{t('no_results')}</p>
                <button className="btn-line btn-sm" onClick={() => setSearchParams({}, { replace: true, preventScrollReset: true })}>{lang === 'fa' ? 'پاک‌کردن فیلترها' : 'Clear filters'}</button>
              </div>
            ) : (
              <div className="site-news-list grid gap-6 md:grid-cols-3">
                {grid.map((x, i) => (
                  <div className={`rv rv-d${(i % 3) + 1}`} key={x.id}><NewsCard n={x} /></div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
    </>
  )
}

import { useLocation } from 'react-router-dom'
import { useContent, usePageMeta } from '../src/lib/store.jsx'
import { useDict, publicItemName } from './lib.jsx'

// Phase-14 page metadata, computed from the same CMS settings and collection items.
// This component has no markup: it updates title/description/Open Graph on every route.
export default function PageMeta() {
  const { pathname } = useLocation()
  const { settings, data } = useContent()
  const { t, L } = useDict()
  const rawPath = pathname.replace(/\/+$/, '') || '/'
  // React Router matches static paths case-insensitively; preserve a detail slug's case.
  const path = rawPath.toLowerCase()
  const company = settings.company ?? {}
  const pages = settings.pages ?? {}
  let title, description, image

  if (path === '/') {
    title = L(settings.seo?.title)
    description = L(settings.seo?.description)
    image = '/og.jpg'
  } else if (path === '/about') {
    title = t('about_t'); description = L(company.summary)
  } else if (path === '/activities') {
    title = t('activities_h'); description = L(company.tagline)
  } else if (path === '/import' || path === '/export') {
    const page = pages[path.slice(1)] ?? {}
    title = L(page.title); description = L(page.intro)
  } else if (path === '/process') {
    title = t('process_t')
  } else if (path === '/products') {
    title = t('products_t'); description = t('products_d')
  } else if (path.startsWith('/products/')) {
    const slug = rawPath.slice('/products/'.length)
    const product = (data?.products ?? []).find((p) => p.id === slug)
    title = product ? publicItemName(L(product.name)) : undefined
    description = product ? L(product.short) : undefined
    image = product?.image
  } else if (path === '/news') {
    title = t('news_t'); description = t('news_d')
  } else if (path.startsWith('/news/')) {
    const slug = rawPath.slice('/news/'.length)
    const article = (data?.news ?? []).find((n) => n.id === slug)
    title = article ? L(article.title) : undefined
    description = article ? L(article.excerpt) : undefined
    image = article?.image
  } else if (path === '/gallery') {
    title = t('nav_gallery'); description = t('gallery_d')
  } else if (path === '/partners') {
    title = t('nav_partners'); description = t('partners_d')
  } else if (path === '/projects') {
    title = t('nav_projects'); description = t('projects_d')
  } else if (path === '/downloads') {
    title = t('downloads_t'); description = t('downloads_d')
  } else if (path === '/careers') {
    title = t('careers_t'); description = t('careers_d')
  } else if (path === '/contact') {
    title = t('contact_title'); description = t('contact_intro')
  } else if (path === '/privacy') {
    title = t('nav_privacy')
  } else if (path === '/terms') {
    title = t('nav_terms')
  } else {
    title = t('notfound_t')
  }
  usePageMeta(title, description, image)
  return null
}

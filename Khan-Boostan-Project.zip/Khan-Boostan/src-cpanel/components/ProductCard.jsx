import { Link } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { useDict, publicItemName } from '../lib.jsx'

export default function ProductCard({ p }) {
  const { data } = useContent()
  const { t, L } = useDict()
  const cat = (data?.categories ?? []).find((c) => c.id === p.category)
  return (
    <Link className="kb-product-card card group flex h-full flex-col overflow-hidden no-underline" to={`/products/${p.id}/`}>
      <div className="kb-card-media relative aspect-[4/3] overflow-hidden bg-mist-100">
        <img src={p.image} alt={publicItemName(L(p.name))} loading="lazy" decoding="async" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        <span className="absolute start-3 top-3 flex gap-1.5">
          {p.featured && <span className="rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured_badge')}</span>}
        </span>
      </div>
      <div className="kb-card-content flex flex-1 flex-col gap-2 p-5">
        <span className="kb-card-meta flex items-center justify-between gap-2 text-[12px] font-bold text-brass-dark">
          {L(cat?.name, '')}
          <span className="rounded-full border px-2 py-0.5 text-[10.5px] font-bold bg-brass-pale text-brass-dark border-[#F1C9B8]">{t('status_' + p.status, p.status)}</span>
        </span>
        <h3 className="text-[17px] leading-relaxed">{publicItemName(L(p.name))}</h3>
        <p className="line-clamp-2 text-[13.5px] text-[#565E66]">{L(p.short)}</p>
        <span className="kb-card-action mt-auto inline-flex items-center gap-2 pt-2 text-[13.5px] font-bold text-ink transition-colors group-hover:text-brass-dark">{t('view_details')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:-translate-x-1 rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></span>
      </div>
    </Link>
  )
}

// The cPanel wordmark fallback: same shapes/colours, not an invented partner logo.
const KIND_INDEX = { agency: 0, supplier: 1, client: 2, brand: 3, partner: 4, affiliate: 5 }

export default function PartnerMark({ name = '', kind = 'partner', size = 40 }) {
  const first = String(name).trim().charAt(0) || '•'
  const idx = KIND_INDEX[kind] ?? 4
  return (
    <span className="grid shrink-0 place-items-center" style={{ width: size, height: size }} aria-hidden="true">
      <svg viewBox="0 0 40 40" width={size} height={size}>
        <g fill={idx % 2 ? '#D96F4E' : '#2A2F35'}>
          {idx === 0 && <path d="M20 3 34 9v10c0 9-6 15-14 18C12 34 6 28 6 19V9Z" />}
          {idx === 1 && <path d="M20 4 34 12v16L20 36 6 28V12Z" />}
          {idx === 2 && <circle cx="20" cy="20" r="15" />}
          {idx === 3 && <rect x="10" y="10" width="20" height="20" rx="4" transform="rotate(45 20 20)" />}
          {idx === 4 && <rect x="7" y="7" width="26" height="26" rx="7" />}
          {idx === 5 && <path d="M14 6h12l8 8v12l-8 8H14l-8-8V14Z" />}
        </g>
        <text x="20" y="25.5" textAnchor="middle" fontSize="15" fontWeight="800" fill="#fff">{first}</text>
      </svg>
    </span>
  )
}

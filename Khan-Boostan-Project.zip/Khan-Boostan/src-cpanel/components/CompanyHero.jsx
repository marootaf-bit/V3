import { Link } from 'react-router-dom'
import { useDict } from '../lib.jsx'

// Uses the same visual system as the shared interior hero, retaining company-specific page content.
export default function CompanyHero({ image, imageSet, title, summary, crumbs, width = 1536, height = 1024 }) {
  const { lang, t } = useDict()
  return (
    <section className="kb-hero" aria-labelledby="kb-page-title">
      <img className="kb-hero-image" src={image} srcSet={imageSet} sizes={imageSet ? '(max-width: 820px) 100vw, 52vw' : undefined} alt="" aria-hidden="true" width={width} height={height} fetchPriority="high" />
      <div className="wrap kb-hero-content">
        <nav className="kb-crumbs" aria-label={lang === 'fa' ? 'مسیر صفحه' : 'Breadcrumb'}>
          <Link to="/">{t('home')}</Link>
          {crumbs.map(({ label, to }, i) => (
            <span className="kb-crumb" key={`${to ?? 'current'}-${i}`}>
              <span className="kb-crumb-separator" aria-hidden="true">/</span>
              {to ? <Link to={to}>{label}</Link> : <span aria-current="page">{label}</span>}
            </span>
          ))}
        </nav>
        <h1 id="kb-page-title">{title}</h1>
        {summary && <p>{summary}</p>}
      </div>
    </section>
  )
}

import { useDict } from '../lib.jsx'
import SectionHeading from './SectionHeading.jsx'

export default function Testimonials({ items = [], badges = [] }) {
  const { t, L, lang } = useDict()
  if (!items.length) return null
  return (
    <section className="band-dark relative py-16 md:py-20">
      <span aria-hidden="true" className="mouse-glow " style={{ '--glow': 'rgba(238,139,108,.10)', '--gs': '560px' }}></span>
      <div className="wrap relative z-[2]">
        <SectionHeading light eyebrow={t('testimonials_t')} title={items.some((item) => item.demo) ? (lang === 'fa' ? 'نمونهٔ نمایش نظرات مشتریان' : 'Sample testimonials') : (lang === 'fa' ? 'گفتهٔ همکاران تجارتی ما' : 'What our trade partners say')} />
        {items.some((item) => item.demo) && <p className="mb-6 text-[13px] text-mist-200" role="note">{lang === 'fa' ? 'نقل‌قول‌ها و هویت‌ها نمونه‌اند؛ اصالت و اجازهٔ نشر آن‌ها هنوز تأیید نشده است.' : 'Quotes and identities are samples; authenticity and permission to publish remain unverified.'}</p>}
        <div className="grid gap-5 md:grid-cols-3">
          {items.slice(0, 3).map((x, i) => (
            <figure className={`rv rv-d${i + 1} glass flex flex-col gap-4 p-6 transition-transform duration-300 hover:-translate-y-1.5`} key={x.id ?? i}>
              <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor" className="text-brass"><path d="M10 8c-3 0-5 2.2-5 5.2 0 2.2 1.6 3.8 3.7 3.8 1.9 0 3.3-1.4 3.3-3.2 0-1.7-1.2-3-2.9-3-.3 0-.6 0-.8.1.4-1.5 1.7-2.6 3.2-2.9L10 8Zm9 0c-3 0-5 2.2-5 5.2 0 2.2 1.6 3.8 3.7 3.8 1.9 0 3.3-1.4 3.3-3.2 0-1.7-1.2-3-2.9-3-.3 0-.6 0-.8.1.4-1.5 1.7-2.6 3.2-2.9L19 8Z" /></svg>
              <blockquote className="flex-1 text-[14.5px] leading-relaxed text-mist-100">{L(x.quote)}</blockquote>
              <figcaption className="border-t border-white/10 pt-3 text-[13px]"><span className="block font-bold text-white">{L(x.name)}</span><span className="text-mist-300">{L(x.role)} — {L(x.company)}</span></figcaption>
            </figure>
          ))}
        </div>
        {badges.length > 0 && (
          <div className="rv mt-10 border-t border-white/10 pt-8">
            <div className="mb-5 text-center text-[12.5px] font-bold uppercase tracking-[.18em] text-mist-300">{t('partners_t')}</div>
            <div className="flex flex-wrap items-center justify-center gap-3 md:gap-4">
              {badges.map((p, i) => (
                <span className="inline-flex max-w-[190px] items-center gap-2 rounded-full border border-white/25 px-4 py-2 text-[12.5px] font-bold text-mist-100 transition-colors hover:border-brass hover:text-brass" key={p.id ?? i}>
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full border border-white/30 text-[9px]">{L(p.name).trim().charAt(0)}</span>
                  <span className="truncate">{L(p.name)}</span>
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

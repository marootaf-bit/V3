// The content API is asynchronous. Reserve the first screen so the footer
// cannot visibly jump upward and then down while either company page loads.
export default function CompanyLoading({ lang = 'fa' }) {
  return (
    <main id="main" className="kb-pages kb-loading-page flex-1" aria-busy="true">
      <span className="sr-only" role="status">{lang === 'fa' ? 'در حال دریافت محتوا…' : 'Loading content…'}</span>
      <div className="kb-loading-hero" aria-hidden="true" />
      <div className="wrap kb-loading-lines" aria-hidden="true"><span /><span /><span /></div>
    </main>
  )
}

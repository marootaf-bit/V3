import { Link } from 'react-router-dom'
import { useDict } from '../lib.jsx'

const CAT = {
  news: ['خبر', 'News'], note: ['یادداشت', 'Note'], announce: ['اطلاعیه', 'Announcement'], event: ['رویداد', 'Event'],
  guide: ['راهنما', 'Guide'], insight: ['تحلیل', 'Insight'], meeting: ['دیدار', 'Meeting'], partnership: ['همکاری', 'Partnership'],
}
export const newsCat = (c, lang) => (CAT[c] ? CAT[c][lang === 'fa' ? 0 : 1] : c)

export default function NewsCard({ n }) {
  const { t, L, lang } = useDict()
  return (
    <Link className="kb-news-card card group flex h-full flex-col overflow-hidden no-underline" to={`/news/${n.id}/`}>
      <div className="kb-card-media relative aspect-[16/9] overflow-hidden bg-mist-100">
        {n.image ? <img src={n.image} alt={L(n.title)} loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" /> : <span className="grid h-full w-full place-items-center bg-mist-100 text-[#A7AEB5]"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2" /><path d="M18 14h-8" /><path d="M15 18h-5" /><path d="M10 6h8v4h-8V6Z" /></svg></span>}
        {n.featured && <span className="absolute start-3 top-3 rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured_badge')}</span>}
      </div>
      <div className="kb-card-content flex flex-1 flex-col gap-2 p-5">
        <div className="kb-card-meta flex items-center gap-3 text-[12px] text-[#8A9199]">
          <time dateTime={n.date}>{n.date}</time>
          {n.category && <span className="rounded-full bg-mist-100 px-2 py-0.5 text-[10.5px] font-bold text-[#565E66]">{newsCat(n.category, lang)}</span>}
        </div>
        <h3 className="text-[16px] leading-relaxed">{L(n.title)}</h3>
        <p className="line-clamp-2 text-[13.5px] text-[#565E66]">{L(n.excerpt)}</p>
        <span className="mt-auto flex items-center justify-between gap-3 pt-3">
          <span className="text-[13px] font-bold text-ink transition-colors group-hover:text-brass-dark">{t('read_more')}</span>
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-brass-pale text-brass-dark transition-colors group-hover:bg-brass group-hover:text-white"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></span>
        </span>
      </div>
    </Link>
  )
}

export default function SectionHeading({ eyebrow, title, description, light = false }) {
  return (
    <div className="rv mb-8 flex flex-wrap items-end justify-between gap-4 md:mb-10">
      <div className="max-w-[62ch]">
        {eyebrow && <div className={`eyebrow mb-2 ${light ? '!text-brass' : 'text-brass-dark'}`}>{eyebrow}</div>}
        <h2 className={light ? 'text-white' : ''} style={{ fontSize: 'clamp(24px, 2.8vw, 34px)' }}>{title}</h2>
        {description && <p className={`mt-2 ${light ? 'text-mist-300' : 'text-[#565E66]'}`}>{description}</p>}
      </div>
    </div>
  )
}

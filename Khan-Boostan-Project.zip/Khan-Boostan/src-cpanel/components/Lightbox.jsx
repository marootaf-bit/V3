import { useEffect, useRef } from 'react'
import { useDict } from '../lib.jsx'

const Arrow = ({ className }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
const X = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>

// Shared gallery/product viewer: keep keyboard and screen-reader focus inside the dialog.
export default function Lightbox({ items, index, setIndex, close }) {
  const { t, L, lang } = useDict()
  const dialogRef = useRef(null)
  const closeRef = useRef(null)

  useEffect(() => {
    const trigger = document.activeElement
    const background = [...document.querySelectorAll('.public-site > header, .public-site > main, .public-site > footer')]
    const priorInert = background.map((element) => element.inert)
    const previousOverflow = document.body.style.overflow
    background.forEach((element) => { element.inert = true })
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()
    return () => {
      background.forEach((element, i) => { element.inert = priorInert[i] })
      document.body.style.overflow = previousOverflow
      if (trigger?.isConnected) trigger.focus({ preventScroll: true })
    }
  }, [])

  useEffect(() => {
    const handle = (event) => {
      if (event.key === 'Escape') { event.preventDefault(); close(); return }
      if (event.key === 'Tab') {
        const dialog = dialogRef.current
        if (!dialog) return
        const focusable = [...dialog.querySelectorAll('button:not([disabled]), a[href], video[controls], [tabindex]:not([tabindex="-1"])')]
          .filter((element) => element.getClientRects().length > 0)
        if (!focusable.length) { event.preventDefault(); return }
        const first = focusable[0], last = focusable[focusable.length - 1]
        if (!dialog.contains(document.activeElement)) { event.preventDefault(); first.focus() }
        else if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus() }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus() }
        return
      }
      // Native video controls retain their arrow-key seeking behavior.
      if (event.target instanceof HTMLVideoElement) return
      if (event.key === 'ArrowLeft') setIndex((i) => (i + 1) % items.length)
      if (event.key === 'ArrowRight') setIndex((i) => (i - 1 + items.length) % items.length)
    }
    document.addEventListener('keydown', handle)
    return () => document.removeEventListener('keydown', handle)
  }, [items.length, setIndex, close])

  const item = items[index]
  if (!item) return null
  return <div ref={dialogRef} className="fixed inset-0 z-[100] grid place-items-center bg-ink p-4" role="dialog" aria-modal="true" aria-label={lang === 'fa' ? 'نمایش تصویر یا ویدیو' : 'Media viewer'} onClick={close}>
    <button ref={closeRef} type="button" className="absolute end-4 top-4 grid h-11 w-11 place-items-center rounded-full border border-white/20 text-white hover:border-brass hover:text-brass" onClick={(event) => { event.stopPropagation(); close() }} aria-label={t('close')}><X /></button>
    {items.length > 1 && <>
      <button type="button" className="absolute start-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full border border-white/20 text-white hover:border-brass hover:text-brass md:start-6" aria-label={t('prev')} onClick={(event) => { event.stopPropagation(); setIndex((i) => (i - 1 + items.length) % items.length) }}><Arrow className="rtl:rotate-0 rotate-180" /></button>
      <button type="button" className="absolute end-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full border border-white/20 text-white hover:border-brass hover:text-brass md:end-6" aria-label={t('next')} onClick={(event) => { event.stopPropagation(); setIndex((i) => (i + 1) % items.length) }}><Arrow className="rtl:rotate-180" /></button>
    </>}
    <figure className="max-h-full w-full max-w-4xl" onClick={(event) => event.stopPropagation()}>
      {item.video ? <video src={item.video} poster={item.poster || item.image} controls autoPlay playsInline className="max-h-[76vh] w-full rounded-xl bg-black" /> : <img src={item.image} alt={L(item.caption, '')} className="mx-auto max-h-[76vh] w-auto rounded-xl object-contain" />}
      {item.caption && <figcaption className="mt-3 text-center text-[14px] text-mist-200">{L(item.caption)}</figcaption>}
    </figure>
  </div>
}

#!/usr/bin/env python3
"""Create local crawler snapshots for the editable cPanel reconstruction.

Never touches project/deploy or the disconnected live site. Run after the safe
Vite build and copy of static assets, with the local PHP preview on port 8083.
The existing crawler renderer writes snapshots to build-cpanel; this wrapper
replaces preview URLs in robots/sitemap with the real canonical domain.
"""
import pathlib
import subprocess
import sys
import urllib.request

PROJECT = pathlib.Path(__file__).resolve().parents[2]
BUILD = PROJECT / 'build-cpanel'
RENDERER = PROJECT.parent / 'ops' / 'prerender.py'
LOCAL = 'http://127.0.0.1:8083'
CANONICAL = 'https://khanboostan.grandtire.af'

if BUILD.resolve() != (PROJECT / 'build-cpanel').resolve() or not (BUILD / 'index.html').is_file():
    sys.exit('Missing safe build: run vite build --config vite.config.cpanel.js first.')
if not RENDERER.is_file():
    sys.exit('Existing local prerender helper missing: ops/prerender.py')

# Ensure that the preview server is the only URL we ask to render.
try:
    with urllib.request.urlopen(LOCAL + '/api/content', timeout=15) as response:
        if response.status != 200 or b'"products"' not in response.read(200_000):
            raise RuntimeError('The local preview API did not return content.')
except Exception as exc:
    sys.exit(f'Local preview {LOCAL} unavailable: {exc}')

subprocess.run([sys.executable, str(RENDERER), LOCAL, str(BUILD)], check=True)
for name in ('robots.txt', 'sitemap.xml'):
    path = BUILD / name
    content = path.read_text(encoding='utf-8')
    if LOCAL not in content:
        sys.exit(f'Expected only a local preview origin in {name}.')
    path.write_text(content.replace(LOCAL, CANONICAL), encoding='utf-8')

print(f'Canonical origin restored in {BUILD.name}/robots.txt and sitemap.xml.')
print('No files in project/deploy or on cPanel were changed.')

import { Fragment } from 'react'
import { Link } from 'react-router-dom'
import { useDict } from './lib.jsx'

export function Hero({ image, imageNote, crumbs, title, sub, children }) {
  const { t } = useDict()
  return (
    <section className={`site-hero premium-split-hero band-dark relative overflow-hidden${image ? '' : ' site-hero--plain'}`}>
      <div className="premium-hero-visual" aria-hidden={imageNote ? undefined : true}>
        {image && <img src={image} alt="" fetchPriority="high" style={{ objectPosition: 'center 42%' }} />}
        {imageNote && <span className="kb-hero-image-note">{imageNote}</span>}
      </div>
      <div className="site-hero-content wrap relative z-[2]">
        <div className="premium-hero-copy">
          <nav className="mb-4 flex flex-wrap items-center gap-2 text-[13px]" aria-label="breadcrumb">
            <Link className="inline-flex min-h-[32px] items-center text-mist-300 hover:text-white" to="/">{t('home')}</Link>
            {crumbs.map(([to, label], i) => (
              <Fragment key={to ?? i}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rotate-180 opacity-50 rtl:rotate-0"><path d="m15 18-6-6 6-6" /></svg>
                {to ? <Link className="inline-flex min-h-[32px] items-center text-mist-300 hover:text-white" to={to}>{label}</Link> : <span className={i === crumbs.length - 1 ? 'font-bold text-brass' : 'text-mist-300'}>{label}</span>}
              </Fragment>
            ))}
          </nav>
          <h1 className="mb-3 text-white" style={{ fontSize: 'clamp(30px, 3.4vw, 46px)' }}>{title}</h1>
          {sub && <p className="max-w-[52ch] text-[clamp(15.5px,1.2vw,17.5px)] leading-relaxed text-mist-300">{sub}</p>}
        </div>
        {children && <div className="premium-hero-extra">{children}</div>}
      </div>
    </section>
  )
}

export function Cta() {
  const { t, L, lang } = useDict()
  return (
    <section className="band py-14 md:py-16">
      <div className="wrap relative flex flex-wrap items-center justify-between gap-6">
        <div>
          <h2 className="mb-2 text-white" style={{ fontSize: 'clamp(22px, 2.4vw, 30px)' }}>{lang === 'fa' ? 'برای شروع گفتگوی تجارتی آماده‌ایم' : 'Ready to start a trade conversation'}</h2>
          <p className="text-slate-300">{lang === 'fa' ? 'راه‌های تماس موجود را ببینید؛ ارسال آنلاین در این پیش‌نمایش غیرفعال است.' : 'See the available contact details; online sending is disabled in this preview.'}</p>
        </div>
        <Link className="btn-brass" to="/contact">{t('nav_contact')} <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg></Link>
      </div>
    </section>
  )
}

export function FaqList({ items, plus }) {
  const { L } = useDict()
  const mark = plus
    ? <span className="faq-mark"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14" /><path d="M12 5v14" /></svg></span>
    : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-brass-dark transition-transform"><path d="m6 9 6 6 6-6" /></svg>
  return (
    <>
      {items.map((f, i) => (
        <details className={`faq-item rv rv-d${(i % 3) + 1}${plus ? ' faq-plus' : ''}`} open={i === 0 ? true : undefined} key={f.id ?? i}>
          <summary>{L(f.q)}{mark}</summary>
          <div className="faq-body">{L(f.a)}</div>
        </details>
      ))}
    </>
  )
}

export const BoxIcon = ({ className }) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" /><path d="m3.3 7 8.7 5 8.7-5" /><path d="M12 22V12" /></svg>
)
export const ArrowIcon = ({ className }) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
)

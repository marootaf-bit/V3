import { useEffect, useRef, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useContent, useLang } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'

export default function Header() {
  const { data, settings } = useContent()
  const { t, L, lang } = useDict()
  const { setLang } = useLang()
  const [open, setOpen] = useState(false)
  const [aboutOpen, setAboutOpen] = useState(false)
  const menuButton = useRef(null)
  const aboutButton = useRef(null)
  const aboutPinned = useRef(false)
  const loc = useLocation()
  const comp = settings.company ?? {}, contact = settings.contact ?? {}, pages = settings.pages ?? {}
  const teamEnabled = settings.sections?.showTeam !== false && (!data || (data.team ?? []).length > 0)
  const companyArea = ['/about', '/partners', '/team'].includes(loc.pathname)
  const act = (p) => loc.pathname === p || loc.pathname.startsWith(p + '/') || (p === '/about' && loc.pathname === '/partners')
  useEffect(() => { setOpen(false); setAboutOpen(false); aboutPinned.current = false }, [loc.pathname, loc.hash])
  useEffect(() => {
    if (!open) return
    const onEscape = (event) => {
      if (event.key === 'Escape') { setOpen(false); menuButton.current?.focus() }
    }
    document.addEventListener('keydown', onEscape)
    return () => document.removeEventListener('keydown', onEscape)
  }, [open])
  const groups = [
    { to: '/', label: t('home') },
    { to: '/about', label: t('nav_about'), items: [['/about', t('nav_intro')], ...(teamEnabled ? [['/about#team', t('nav_team')]] : []), ['/partners', t('nav_partners')]] },
    { to: '/activities', label: t('nav_activities'), items: [['/activities', t('nav_overview')], ['/import', L(pages.import?.title, t('nav_import'))], ['/export', L(pages.export?.title, t('nav_export'))], ['/projects', lang === 'fa' ? 'سوابق و نمونه‌های همکاری' : 'Track record & cases']] },
    { to: '/products', label: t('nav_products') },
    { to: '/news', label: t('nav_news'), items: [['/news', t('nav_news_events')], ['/gallery', t('nav_gallery')], ['/gallery#videos', t('nav_videos')]] },
    { to: '/contact', label: t('nav_contact') },
  ]
  const navCls = (to) => `relative inline-flex min-h-[44px] items-center gap-1.5 rounded-full px-3.5 text-[14px] font-semibold transition-colors ${act(to) ? 'text-ink' : 'text-[#565E66] hover:text-ink'}`
  const ddCls = 'block rounded-lg px-3 py-2.5 text-[13.5px] font-semibold no-underline transition-colors text-[#565E66] hover:bg-mist-50 hover:text-ink'
  const caret = <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5 opacity-60 transition-transform duration-200 group-hover:rotate-180"><path d="m6 9 6 6 6-6" /></svg>
  return (
    <header className={`sticky top-0 z-50${companyArea ? ' kb-company-header' : ''}`}>
      <div className="hidden bg-ink text-mist-200 md:block">
        <div className="wrap flex min-h-[38px] items-center justify-between gap-4 text-[12.5px]">
          <div className="flex items-center gap-5">
            {contact.email && <a href={`mailto:${contact.email}`} dir="ltr" className="inline-flex items-center gap-1.5 hover:text-white hover:underline"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5 text-brass"><rect width="20" height="16" x="2" y="4" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></svg>{contact.email}</a>}
            <span className="inline-flex items-center gap-1.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5 text-brass"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>{L(contact.hours)}</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5 text-brass"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0" /><circle cx="12" cy="10" r="3" /></svg>{L(contact.address) || 'Afghanistan'}</span>
            <span className="h-3 w-px bg-white/20"></span>
            <button onClick={() => setLang('fa')} aria-pressed={lang === 'fa'} className={lang === 'fa' ? 'font-bold text-brass' : 'hover:text-white'}>دری</button>
            <button onClick={() => setLang('en')} aria-pressed={lang === 'en'} className={lang === 'en' ? 'font-bold text-brass' : 'hover:text-white'}>EN</button>
          </div>
        </div>
      </div>
      <div className="border-b bg-white/95 backdrop-blur-md transition-shadow border-mist-200/70">
        <div className="wrap flex min-h-[70px] items-center justify-between gap-4">
          <Link className="flex items-center gap-3 no-underline" to="/">
            <span className="kb-brand-mark"><img src="/images/logo.png" alt="" width="52" height="52" decoding="async" /></span>
            <span className="leading-tight"><span className="block font-head text-[17px] font-bold text-ink">{L(comp.name)}</span><span className="block text-[11.5px] text-[#8A9199]">{L(comp.tagline)}</span></span>
          </Link>
          <nav className="hidden items-center gap-0.5 xl:flex" aria-label="main">
            {groups.map((g) => (
              <div className={`group relative${g.to === '/about' ? ' inline-flex items-center kb-about-nav' : ''}`} key={g.to}
                onPointerEnter={g.to === '/about' ? (event) => { if (event.pointerType !== 'touch') setAboutOpen(true) } : undefined}
                onPointerLeave={g.to === '/about' ? (event) => {
                  if (event.pointerType !== 'touch' && !event.currentTarget.contains(document.activeElement)) { setAboutOpen(false); aboutPinned.current = false }
                } : undefined}
                onFocusCapture={g.to === '/about' ? (event) => {
                  if (event.target.matches('a[href="/about"]') && !event.currentTarget.contains(event.relatedTarget)) setAboutOpen(true)
                } : undefined}
                onBlurCapture={g.to === '/about' ? (event) => { if (!event.currentTarget.contains(event.relatedTarget)) { setAboutOpen(false); aboutPinned.current = false } } : undefined}
                onKeyDown={g.to === '/about' ? (event) => {
                  if (event.key === 'Escape' && aboutOpen) {
                    event.preventDefault()
                    event.stopPropagation()
                    setAboutOpen(false)
                    aboutPinned.current = false
                    aboutButton.current?.focus()
                  }
                } : undefined}>
                <Link className={navCls(g.to)} style={g.to === '/about' ? { paddingInlineEnd: 0 } : undefined} to={g.to}>{g.label}{g.to !== '/about' && g.items && caret}</Link>
                {g.to === '/about' && (
                  <button ref={aboutButton} type="button" className="kb-about-toggle inline-flex min-h-[44px] min-w-[40px] items-center justify-center rounded-full text-[#565E66] hover:text-ink focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-[3px] focus-visible:outline-[#B8532F]"
                    aria-label={lang === 'fa' ? 'باز و بسته کردن زیرمنوی درباره ما' : 'Toggle About submenu'} aria-expanded={aboutOpen} aria-controls="kb-about-submenu"
                    onClick={() => {
                      // Hover may already have opened the panel before the first click.
                      // The first click pins it open; the next click closes it.
                      aboutPinned.current = !aboutPinned.current
                      setAboutOpen(aboutPinned.current)
                    }}>
                    <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`h-3.5 w-3.5 transition-transform duration-150${aboutOpen ? ' rotate-180' : ''}`}><path d="m6 9 6 6 6-6" /></svg>
                  </button>
                )}
                {g.items && (
                  <div id={g.to === '/about' ? 'kb-about-submenu' : undefined}
                    className={`absolute start-0 top-full z-50 pt-2 ${g.to === '/about'
                      ? `kb-about-submenu transition-opacity duration-150 ${aboutOpen ? 'visible opacity-100' : 'invisible pointer-events-none opacity-0'}`
                      : 'invisible opacity-0 transition-all duration-150 group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100'}`}>
                    <div className="w-60 rounded-xl border border-mist-200 bg-white p-2 shadow-[0_24px_50px_-24px_rgba(42,47,53,.4)]">
                      {g.items.map(([to, label]) => <Link className={ddCls} to={to} key={to}>{label}</Link>)}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>
          <div className="flex items-center gap-2.5">
            <div className="inline-flex rounded-full border border-mist-300 bg-white p-[3px] md:hidden" role="group" aria-label="language">
              <button aria-pressed={lang === 'fa'} onClick={() => setLang('fa')} className={`min-h-[32px] min-w-[40px] rounded-full text-[13px] font-bold ${lang === 'fa' ? 'bg-ink text-white' : 'text-[#8A9199]'}`}>دری</button>
              <button aria-pressed={lang === 'en'} onClick={() => setLang('en')} className={`min-h-[32px] min-w-[40px] rounded-full text-[13px] font-bold ${lang === 'en' ? 'bg-ink text-white' : 'text-[#8A9199]'}`}>EN</button>
            </div>
            <Link className="btn-coral btn-sm hidden sm:inline-flex" to="/contact?kind=cooperation">{t('cooperate')}</Link>
            <button ref={menuButton} className="kb-mobile-menu-button rounded-lg border border-mist-300 p-2 text-ink" onClick={() => setOpen(!open)} aria-label={lang === 'fa' ? 'فهرست' : 'Menu'} aria-expanded={open} aria-controls={open ? 'kb-mobile-nav' : undefined}>
              {open
                ? <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>
                : <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="6" y2="6" /><line x1="4" x2="20" y1="12" y2="12" /><line x1="4" x2="20" y1="18" y2="18" /></svg>}
            </button>
          </div>
        </div>
        {open && (
          <nav id="kb-mobile-nav" className="wrap max-h-[70vh] overflow-y-auto border-t border-mist-200 bg-white pb-5 xl:hidden" aria-label="mobile">
            {groups.map((g) => (
              <div className="border-b border-mist-100 py-1.5 last:border-0" key={g.to}>
                <Link to={g.to} onClick={() => setOpen(false)} className={`block min-h-[44px] py-2.5 text-[15px] font-bold ${act(g.to) ? 'text-ink' : 'text-[#565E66]'}`}>{g.label}</Link>
                {g.items && (
                  <div className="grid ps-4">
                    {(g.to === '/about' ? g.items : g.items.filter(([to]) => to !== g.to)).map(([to, label]) => (
                      <Link to={to} onClick={() => setOpen(false)} className="block min-h-[38px] py-1.5 text-[13.5px] text-[#6B7278] no-underline" key={to}>{label}</Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="mt-3 flex items-center justify-between gap-3 pt-2">
              <Link to="/downloads" className="text-[13.5px] font-bold text-brass-dark">{t('nav_downloads')}</Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}

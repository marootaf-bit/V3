import { Link } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'

export default function Footer() {
  const { settings } = useContent()
  const { t, L, lang } = useDict()
  const comp = settings.company ?? {}, contact = settings.contact ?? {}, pages = settings.pages ?? {}
  const pub = t('pending')
  const li = 'inline-flex min-h-[34px] items-center hover:text-brass'
  const rec = lang === 'fa' ? 'سوابق و نمونه‌های همکاری' : 'Track record & cases'
  return (
    <footer className="mt-auto bg-[#22262B] text-mist-200">
      <div className="wrap grid gap-10 border-b border-white/10 py-12 md:grid-cols-[1.5fr_.9fr_1.1fr_1.2fr]">
        <div>
          <Link className="flex items-center gap-3 no-underline" to="/">
            <span className="kb-brand-mark kb-brand-mark--footer"><img src="/images/logo.png" alt="" width="52" height="52" loading="lazy" decoding="async" /></span>
            <span className="leading-tight"><span className="block font-head text-[17px] font-bold text-white">{L(comp.name)}</span><span className="block text-[11.5px] text-mist-300">{L(comp.tagline)}</span></span>
          </Link>
          <p className="mt-4 max-w-[42ch] text-[14px] leading-relaxed text-[#9AA1A8]">{L(comp.summary)}</p>
          <div className="mt-5"></div>
        </div>
        <div>
          <h3 className="mb-4 text-[14.5px] font-bold text-white">{t('activities_t')}</h3>
          <ul className="grid gap-1.5 text-[14px]">
            <li><Link className={li} to="/import">{L(pages.import?.title)}</Link></li>
            <li><Link className={li} to="/export">{L(pages.export?.title)}</Link></li>
            <li><Link className={li} to="/products">{t('nav_products')}</Link></li>
            <li><Link className={li} to="/projects">{rec}</Link></li>
            <li><Link className={li} to="/process">{t('nav_process')}</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="mb-4 text-[14.5px] font-bold text-white">{t('pages')}</h3>
          <ul className="grid gap-1.5 text-[14px]">
            <li><Link className={li} to="/about">{t('nav_about')}</Link></li>
            <li><Link className={li} to="/partners">{t('nav_partners')}</Link></li>
            <li><Link className={li} to="/news">{t('nav_news')}</Link></li>
            <li><Link className={li} to="/gallery">{t('nav_gallery')}</Link></li>
            <li><Link className={li} to="/downloads">{t('nav_downloads')}</Link></li>
            <li><Link className={li} to="/contact">{t('nav_contact')}</Link></li>
            <li><Link className={li} to="/privacy">{t('nav_privacy')}</Link></li>
            <li><Link className={li} to="/terms">{t('nav_terms')}</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="mb-4 text-[14.5px] font-bold text-white">{t('contact_t')}</h3>
          <ul className="grid gap-3 text-[14px]">
            <li className="flex items-start gap-2.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-1.5 shrink-0 text-brass"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0" /><circle cx="12" cy="10" r="3" /></svg><span>{L(contact.address) || pub}</span></li>
            <li className="flex items-start gap-2.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-1.5 shrink-0 text-brass"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2.4 2.4 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2.4 2.4 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92" /></svg><span dir="ltr">{contact.phone || pub}</span></li>
            <li className="flex items-start gap-2.5"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-1.5 shrink-0 text-brass"><rect width="20" height="16" x="2" y="4" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></svg>{contact.email ? <a href={`mailto:${contact.email}`} dir="ltr" className="break-all underline-offset-4 hover:text-white hover:underline">{contact.email}</a> : <span>{pub}</span>}</li>
          </ul>
        </div>
      </div>
      <div className="wrap flex flex-wrap items-center justify-between gap-3 py-5 text-[13px] text-[#9AA1A8]">
        <span>© {new Date().getFullYear()} {L(comp.legal)}</span>
        <span className="flex items-center gap-4">
          <Link className="hover:text-white" to="/privacy">{t('nav_privacy')}</Link>
          <Link className="hover:text-white" to="/terms">{t('nav_terms')}</Link>
          <Link className="hover:text-white" to="/admin/">{t('admin')}</Link>
        </span>
      </div>
    </footer>
  )
}

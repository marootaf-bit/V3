<?php
// Local preview for the NEW React build + the existing PHP content API.
$deploy = getenv('KB_DOCROOT') ?: '/home/user/project/deploy';
$api    = $deploy . '/api';
$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

if (preg_match('#^/api(/|$)#', $uri)) {
    chdir($api);
    $_SERVER['SCRIPT_NAME'] = '/api/index.php';
    require $api . '/index.php';
    return true;
}
$fs = $deploy . $uri;
if ($uri !== '/' && is_dir($fs) && is_file(rtrim($fs,'/') . '/index.html')) {
    header('Cache-Control: no-cache'); header('Content-Type: text/html; charset=utf-8');
    readfile(rtrim($fs,'/') . '/index.html'); return true;
}
if ($uri !== '/' && is_file($fs)) {
    $ext = strtolower(pathinfo($fs, PATHINFO_EXTENSION));
    $mime = ['html'=>'text/html; charset=utf-8','js'=>'text/javascript','css'=>'text/css','json'=>'application/json',
             'svg'=>'image/svg+xml','webp'=>'image/webp','png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg',
             'woff'=>'font/woff','woff2'=>'font/woff2','ico'=>'image/x-icon','txt'=>'text/plain; charset=utf-8'][$ext] ?? null;
    if ($mime) header('Content-Type: ' . $mime);
    if ($ext === 'html') header('Cache-Control: no-cache');
    readfile($fs);
    return true;
}
header('Cache-Control: no-cache');
readfile($deploy . '/index.html');
return true;

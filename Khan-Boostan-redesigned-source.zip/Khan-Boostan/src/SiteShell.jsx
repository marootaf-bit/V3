import { lazy, Suspense } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import { useDict } from './lib.jsx'
import { ScrollProgress } from '../src/lib/motion.jsx'
import PageMeta from './PageMeta.jsx'
import Header from './shell/Header.jsx'
import Footer from './shell/Footer.jsx'
import FloatingContact from './shell/FloatingContact.jsx'
import SkipLink from './components/public/SkipLink.jsx'
import PublicLoading from './components/public/PublicLoading.jsx'

const Home = lazy(() => import('./pages/Home.jsx'))
const About = lazy(() => import('./pages/About.jsx'))
const TeamRedirect = lazy(() => import('./pages/TeamRedirect.jsx'))
const Activities = lazy(() => import('./pages/Activities.jsx'))
const TradeGuide = lazy(() => import('./pages/TradeGuide.jsx'))
const TradePage = lazy(() => import('./pages/TradePage.jsx'))
const Process = lazy(() => import('./pages/Process.jsx'))
const Products = lazy(() => import('./pages/Products.jsx'))
const ProductDetail = lazy(() => import('./pages/ProductDetail.jsx'))
const News = lazy(() => import('./pages/News.jsx'))
const NewsDetail = lazy(() => import('./pages/NewsDetail.jsx'))
const Gallery = lazy(() => import('./pages/Gallery.jsx'))
const Partners = lazy(() => import('./pages/Partners.jsx'))
const PartnerDetail = lazy(() => import('./pages/PartnerDetail.jsx'))
const Projects = lazy(() => import('./pages/Projects.jsx'))
const Contact = lazy(() => import('./pages/Contact.jsx'))
const Downloads = lazy(() => import('./pages/Downloads.jsx'))
const Careers = lazy(() => import('./pages/Careers.jsx'))
const Legal = lazy(() => import('./pages/Legal.jsx'))
const NotFound = lazy(() => import('./pages/NotFound.jsx'))

export default function SiteShell() {
  const { lang } = useDict()
  const { pathname } = useLocation()
  const normalizedPath = pathname.replace(/\/+$/, '') || '/'
  const routeHasPrimaryAction = ['/', '/about', '/activities', '/import', '/export', '/process', '/products', '/gallery', '/partners', '/projects', '/contact'].includes(normalizedPath) || normalizedPath.startsWith('/products/') || normalizedPath.startsWith('/news/')
  const showFooterCta = !routeHasPrimaryAction
  const printAbout = normalizedPath === '/about'
  const printHidden = printAbout ? 'print:tw-hidden' : ''
  return <div className={`public-site tw-flex tw-min-h-screen tw-flex-col tw-overflow-x-clip tw-bg-white tw-font-sans tw-text-kb-ink ${printAbout ? 'print:tw-min-h-0 print:tw-overflow-visible print:tw-bg-white' : ''}`}>
    <SkipLink lang={lang} />
    <div className={printHidden}><ScrollProgress /></div>
    <PageMeta />
    <div className={printHidden}><Header /></div>
    <Suspense fallback={<PublicLoading />}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/team" element={<TeamRedirect />} />
        <Route path="/activities" element={<Activities />} />
        <Route path="/trade-guide" element={<TradeGuide />} />
        <Route path="/import" element={<TradePage kind="import" />} />
        <Route path="/export" element={<TradePage kind="export" />} />
        <Route path="/process" element={<Process />} />
        <Route path="/products" element={<Products />} />
        <Route path="/products/:slug" element={<ProductDetail />} />
        <Route path="/news" element={<News />} />
        <Route path="/news/:slug" element={<NewsDetail />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/partners/:slug" element={<PartnerDetail />} />
        <Route path="/partners" element={<Partners />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/downloads" element={<Downloads />} />
        <Route path="/careers" element={<Careers />} />
        <Route path="/privacy" element={<Legal kind="privacy" />} />
        <Route path="/terms" element={<Legal kind="terms" />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
    <div className={printHidden}><Footer showCta={showFooterCta} /></div>
    <FloatingContact />
  </div>
}

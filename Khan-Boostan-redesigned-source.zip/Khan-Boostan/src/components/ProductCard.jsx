import { Link } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicItemName, publicItemSummary, publicSlug } from '../lib.jsx'
import ArrowIcon from './public/ArrowIcon.jsx'
import ProductImageFrame from './public/ProductImageFrame.jsx'

export default function ProductCard({ p, returnTo }) {
  const { data } = useContent()
  const { t, L, lang } = usePublicDict()
  const cat = (data?.categories ?? []).find((c) => c.id === p.category)
  const name = publicItemName(L(p.name))
  const categoryName = cat ? L(cat.name) : ''
  const sharedImage = Boolean(p.image && (data?.products ?? []).filter((item) => item.image === p.image).length > 1)
  const summary = publicItemSummary(p, L, lang)
  const fa = lang !== 'en'
  const linkState = returnTo ? { returnTo } : undefined
  const productParams = new URLSearchParams({ lang: lang === 'en' ? 'en' : 'fa' })
  if (returnTo) productParams.set('from', returnTo)
  const productHref = `/products/${publicSlug(p.id)}?${productParams.toString()}`
  return <Link className="tw-group tw-flex tw-h-full tw-flex-col tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-text-start tw-no-underline tw-transition-shadow hover:tw-shadow-kb motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={productHref} state={linkState}>
    <div className="tw-relative tw-aspect-[4/3] tw-overflow-hidden tw-bg-kb-paper"><ProductImageFrame src={p.image} alt={name} categoryId={p.category} categoryName={categoryName} sharedImage={sharedImage} fa={fa} />{p.featured && <span className="tw-absolute tw-start-3 tw-top-3 tw-rounded-full tw-bg-kb-gold tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-navy">{t('featured_badge')}</span>}</div>
    <div className="tw-flex tw-flex-1 tw-flex-col tw-gap-2 tw-p-4 sm:tw-p-5"><span className="tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-[11px] tw-font-bold tw-text-kb-muted">{cat && L(cat.name) && L(cat.name)}{p.status && <span className="tw-rounded-full tw-bg-kb-paper tw-px-2 tw-py-0.5 tw-text-kb-blue">{t('status_' + p.status, fa ? 'قابل تأمین' : 'On request')}</span>}</span><h3 className="tw-break-words tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{name}</h3>{summary && <p className="tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-6 tw-text-kb-body">{summary}</p>}<span className="tw-mt-auto tw-inline-flex tw-items-center tw-gap-2 tw-pt-2 tw-text-sm tw-font-bold tw-text-kb-blue group-hover:tw-text-kb-navy">{t('view_details')}<ArrowIcon /></span></div>
  </Link>
}

import { useState } from 'react'
import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import ArrowIcon from './ArrowIcon.jsx'

const LABELS = {
  fa: { agency: 'نمایندگی رسمی', partner: 'شریک تجارتی', supplier: 'تأمین‌کننده', client: 'مشتری', brand: 'برند عرضه‌شده', affiliate: 'شرکت وابسته' },
  en: { agency: 'Official agency', partner: 'Trade partner', supplier: 'Supplier', client: 'Client', brand: 'Brand offered', affiliate: 'Affiliated company' },
}

export default function HomeRelationships({ partners, fa, lang, t, L }) {
  const [selectedType, setSelectedType] = useState('all')
  const labels = LABELS[lang === 'en' ? 'en' : 'fa']
  const nameFor = (item) => String(L(item.name) ?? '').trim()
  const namedPartners = partners.filter((item) => nameFor(item) && labels[item.kind])
  if (!namedPartners.length) return null
  const types = [...new Set(namedPartners.map((item) => item.kind).filter((kind) => labels[kind]))]
  const visiblePartners = selectedType === 'all' ? namedPartners : namedPartners.filter((item) => item.kind === selectedType)

  return <section id="home-relationships" className="tw-scroll-mt-20 tw-bg-kb-paper tw-py-12 sm:tw-py-16" aria-labelledby="home-relations-title"><SiteContainer>
    <div className="tw-mb-5 tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between"><div><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2"><h2 id="home-relations-title" className="tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{fa ? 'روابط تجارتی' : 'Trade relationships'}</h2></div></div><Link to="/partners" className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('view_all')}<ArrowIcon /></Link></div>
    <div className="tw-mb-4 tw-flex tw-flex-wrap tw-gap-2" role="group" aria-label={fa ? 'فیلتر بر اساس نوع رابطه' : 'Filter by relationship type'}>
      <button type="button" aria-pressed={selectedType === 'all'} aria-controls="home-relationships-results" onClick={() => setSelectedType('all')} className={`tw-inline-flex tw-min-h-9 tw-items-center tw-rounded-full tw-border tw-px-3 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${selectedType === 'all' ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-line tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`}>{fa ? 'همه' : 'All'}</button>
      {types.map((kind) => <button type="button" key={kind} aria-pressed={selectedType === kind} aria-controls="home-relationships-results" onClick={() => setSelectedType(kind)} className={`tw-inline-flex tw-min-h-9 tw-items-center tw-rounded-full tw-border tw-px-3 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${selectedType === kind ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-line tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`}>{labels[kind]}</button>)}
    </div>
    <div id="home-relationships-results" className="tw-flex tw-flex-wrap tw-justify-center tw-gap-3" aria-live="polite">{visiblePartners.map((item) => <article className="tw-flex tw-min-h-28 tw-basis-full tw-items-center tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-basis-[calc(50%_-_0.375rem)] lg:tw-basis-[calc(33.333333%_-_0.5rem)] xl:tw-basis-[calc(20%_-_0.6rem)]" key={item.id}><span className="tw-grid tw-h-10 tw-w-10 tw-shrink-0 tw-place-items-center tw-rounded-full tw-bg-kb-paper tw-font-head tw-text-sm tw-font-bold tw-text-kb-blue" aria-hidden="true">{nameFor(item).slice(0, 1) || 'K'}</span><span className="tw-min-w-0"><b className="tw-block tw-break-words tw-text-xs tw-leading-5 tw-text-kb-navy">{nameFor(item)}</b><span className="tw-mt-1 tw-block tw-whitespace-normal tw-break-words tw-text-[10px] tw-font-bold tw-text-kb-muted">{labels[item.kind]}</span></span></article>)}</div>
  </SiteContainer></section>
}

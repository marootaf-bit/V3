import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function HomeProfile({ profile, L, lang, fa, t }) {
  if (!profile) return null
  return <section id="home-profile" className="tw-scroll-mt-20 tw-bg-kb-paper tw-py-8 sm:tw-py-10" aria-labelledby="home-profile-title"><SiteContainer className="tw-flex tw-flex-col tw-gap-4 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-flex-row sm:tw-items-center sm:tw-justify-between sm:tw-p-7">
    <div><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-3"><Eyebrow>{fa ? 'پروفایل شرکت' : 'COMPANY PROFILE'}</Eyebrow></div><h2 id="home-profile-title" className="tw-mt-2 tw-text-xl tw-font-bold tw-text-kb-navy">{L(profile.title, t('profile_t'))}</h2><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{t('profile_d')}</p></div>
    <a href={profile.file} download={profile.file.split('/').pop()} className="tw-inline-flex tw-min-h-11 tw-shrink-0 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-blue tw-px-5 tw-text-sm tw-font-bold tw-text-white hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{fa ? 'دانلود' : 'Download'}<ArrowIcon /></a>
  </SiteContainer></section>
}

import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function AboutMilestones({ milestones, c, lang }) {
  if (!milestones.length) return null
  const format = (value) => new Intl.NumberFormat(lang === 'fa' ? 'fa-AF' : 'en', { useGrouping: false }).format(Number(value))
  return <section className="tw-bg-white tw-py-10 sm:tw-py-14" aria-labelledby="about-history-title"><SiteContainer>
    <div className="tw-mb-6 tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between"><div><Eyebrow>{lang === 'fa' ? 'پرونده‌های تجارتی' : 'TRADE CASES'}</Eyebrow><h2 id="about-history-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{c.milestones}</h2></div><p className="tw-max-w-xl tw-text-sm tw-leading-6 tw-text-kb-body">{lang === 'fa' ? 'نمای کوتاه از سال‌ها و حوزه‌های درج‌شده در پرونده‌های تجارتی.' : 'A concise view of the years and sectors in the trade-case archive.'}</p></div>
    <div className="tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-4">{milestones.map((item) => <article className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4" key={item.year}><b className="tw-block tw-font-head tw-text-3xl tw-text-kb-blue">{format(item.year)}</b><span className="tw-mt-1 tw-block tw-text-xs tw-font-bold tw-text-kb-navy">{lang === 'fa' ? `${format(item.count)} پرونده` : `${item.count} trade ${item.count === 1 ? 'case' : 'cases'}`}</span><p className="tw-mt-2 tw-text-xs tw-leading-5 tw-text-kb-muted">{item.sectors.join(' · ')}</p></article>)}</div>
    <Link className="tw-mt-5 tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to="/projects">{c.moreCases}<ArrowIcon kind="up" size={14} /></Link>
  </SiteContainer></section>
}

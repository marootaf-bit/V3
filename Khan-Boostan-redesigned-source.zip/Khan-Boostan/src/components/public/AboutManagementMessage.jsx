import SiteContainer from './SiteContainer.jsx'
import CopyPageLink from './CopyPageLink.jsx'
import { publicTeamName } from '../../lib.jsx'

export default function AboutManagementMessage({ speaker, message, lang, L, c }) {
  if (!speaker || !message) return null
  return <section id="about-message" className="tw-scroll-mt-24 tw-bg-kb-navy tw-py-8 tw-text-white sm:tw-py-11 print:tw-bg-white print:tw-text-kb-ink" aria-labelledby="about-message-title"><SiteContainer className="tw-grid tw-gap-4 md:tw-grid-cols-[.7fr_1.3fr] md:tw-gap-8">
    <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2"><h2 id="about-message-title" className="tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-white sm:tw-text-3xl print:tw-text-kb-navy">{c.messageTitle}</h2><CopyPageLink id="about-message" lang={lang} sectionLabel={c.messageTitle} /></div>
    <figure className="tw-rounded-kb-lg tw-border tw-border-white/15 tw-bg-white/5 tw-p-4 sm:tw-p-6 print:tw-break-inside-avoid print:tw-border-kb-line print:tw-bg-white">
      {speaker.demo ? <p className="tw-max-w-[70ch] tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-white/90 sm:tw-text-base sm:tw-leading-8 print:tw-text-kb-body">{message}</p> : <blockquote className="tw-max-w-[70ch] tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-white/90 sm:tw-text-base sm:tw-leading-8 print:tw-text-kb-body">“{message}”</blockquote>}
      <figcaption className="tw-mt-5 tw-flex tw-flex-wrap tw-items-center tw-gap-3 tw-border-t tw-border-white/15 tw-pt-4">
        {speaker.photo && <img src={speaker.photo} alt="" width="55" height="55" loading="lazy" decoding="async" className="tw-h-12 tw-w-12 tw-shrink-0 tw-rounded-full tw-object-cover sm:tw-h-14 sm:tw-w-14" />}
        <span className="tw-flex tw-min-w-0 tw-flex-col"><strong className="tw-text-sm tw-text-white print:tw-text-kb-navy">{publicTeamName(speaker, L, lang)}</strong><span className="tw-mt-1 tw-text-xs tw-leading-5 tw-text-white/75 print:tw-text-kb-body">{L(speaker.role)}</span></span>
      </figcaption>
    </figure>
  </SiteContainer></section>
}

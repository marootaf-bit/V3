import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'

export default function AboutResponsibility({ title, text, lang }) {
  return <section className="tw-bg-kb-paper tw-py-10 sm:tw-py-14" aria-labelledby="about-responsibility-title"><SiteContainer className="tw-grid tw-gap-4 md:tw-grid-cols-[.8fr_1.2fr] md:tw-items-start md:tw-gap-10"><div><Eyebrow>{lang === 'fa' ? 'رویکرد در معاملات' : 'TRANSACTION CONSIDERATIONS'}</Eyebrow><h2 id="about-responsibility-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{title}</h2></div><p className="tw-text-sm tw-leading-7 tw-text-kb-body">{text}</p></SiteContainer></section>
}

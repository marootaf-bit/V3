import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import HomeMedia from './HomeMedia.jsx'

const INTRO_IMAGES = {
  workers: '/images/gallery-loading.webp',
  cargo: '/images/trade-cargo.webp',
}
const TEAM_AVATARS = ['/images/team-6.jpg', '/images/team-1.jpg', '/images/team-3.jpg', '/images/team-4.jpg']

function CheckIcon() {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m5 12 4 4L19 6" /></svg>
}

function GlobeIcon() {
  return <svg className="tw-h-8 tw-w-8 tw-shrink-0 tw-text-kb-gold sm:tw-h-10 sm:tw-w-10" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="15" cy="17" r="10" /><path d="M5 17h20M15 7c3.2 3 4.6 6.3 4.6 10S18.2 24 15 27c-3.2-3-4.6-6.3-4.6-10S11.8 10 15 7Z" /><path d="m21 8 6-2-2 6m2-6-7 7" /></svg>
}

function WorldMapWatermark() {
  return <svg className="tw-pointer-events-none tw-absolute tw-inset-0 tw-h-full tw-w-full tw-text-white/10" viewBox="0 0 320 180" fill="currentColor" aria-hidden="true"><path d="m20 44 13-16 23-6 22 7 12 12-6 10 8 10-11 8-3 18-11 8-9-10-2-16-14-6-13-7-9-12zM85 89l15-7 18 5 11 14-4 15-10 13-9-8-3-16-11-5zM135 43l17-10 15 2 8 8 17-4 20 7 14 15-8 8-15-4-6 11-14 2-8 12-10-5 1-15-12-7-14 7-12-7-5-12zM177 99l17-7 18 5 9 15-5 21-11 16-13-9-1-17-12-9zM238 116l17-7 14 8 8 13-8 13-16-2-12-11z" /></svg>
}

function splitApproach(copy) {
  if (!copy) return []
  return String(copy)
    .split(/\r?\n+/u)
    .flatMap((line) => line.match(/[^.!?؟۔]+[.!?؟۔]?/gu) ?? [])
    .map((sentence) => sentence.trim())
    .filter(Boolean)
}

export default function HomeIntro({ summary, approach, fa }) {
  const approachItems = approach && approach !== summary ? splitApproach(approach) : []

  return <section id="home-intro" dir={fa ? 'rtl' : 'ltr'} className="tw-relative tw-isolate tw-overflow-hidden tw-bg-white tw-py-12 sm:tw-py-16" aria-labelledby="home-intro-title">
    <SiteContainer dir={fa ? 'rtl' : 'ltr'} className="tw-relative tw-z-10 tw-grid tw-items-center tw-gap-8 md:tw-gap-10 lg:tw-grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:tw-gap-14">
      <div className="tw-min-w-0 tw-max-w-2xl tw-rounded-kb-lg tw-border tw-border-kb-blue/15 tw-bg-kb-blue/10 tw-p-4 tw-text-start tw-shadow-kb sm:tw-p-6">
        <h2 id="home-intro-title" className="tw-break-words tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-4xl lg:tw-text-5xl">{fa ? 'خان بوستان کی است؟' : 'Who is Khan Boostan?'}</h2>
        {summary && <p className="tw-mt-5 tw-whitespace-pre-line tw-break-words tw-text-base tw-leading-8 tw-text-kb-ink sm:tw-text-lg">{summary}</p>}
        {approachItems.length > 0 && <ul className="tw-mt-5 tw-grid tw-gap-3">
          {approachItems.map((item, index) => <li className="tw-flex tw-items-start tw-gap-3" key={`${index}-${item}`}>
            <span className="tw-mt-1 tw-grid tw-h-6 tw-w-6 tw-shrink-0 tw-place-items-center tw-rounded-full tw-border tw-border-kb-gold/40 tw-bg-kb-gold/5 tw-text-kb-gold"><CheckIcon /></span>
            <span className="tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-7 tw-text-kb-body sm:tw-text-base">{item}</span>
          </li>)}
        </ul>}
        <div className="tw-mt-6 tw-flex tw-items-center">
          <Link to="/about" className="tw-inline-flex tw-min-h-11 tw-items-center tw-justify-center tw-gap-2 tw-rounded-kb tw-bg-kb-blue tw-px-5 tw-py-2.5 tw-text-sm tw-font-bold tw-text-white tw-shadow-kb tw-transition-colors hover:tw-bg-kb-navy motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'بیشتر' : 'More'}<ArrowIcon /></Link>
        </div>
      </div>

      <div className="tw-relative tw-mx-auto tw-aspect-[1.15] tw-w-full tw-max-w-[520px] sm:tw-aspect-[1.35] lg:tw-max-w-none" aria-hidden="true">
        <div className="tw-absolute tw-inset-0" dir="ltr">
          <div className={`tw-absolute tw-start-0 tw-top-0 tw-flex tw-h-[22%] tw-w-[48%] tw-items-center tw-gap-1 tw-overflow-hidden tw-rounded-md tw-border tw-border-kb-line tw-bg-white tw-p-2 tw-shadow-kb sm:tw-gap-2 sm:tw-p-3${fa ? ' tw-flex-row-reverse' : ''}`} dir="ltr">
            <div className="tw-flex tw-shrink-0 tw-items-center" dir="ltr">{TEAM_AVATARS.map((src, index) => <span className={`tw-relative tw-grid tw-h-5 tw-w-5 tw-shrink-0 tw-place-items-center tw-overflow-hidden tw-rounded-full tw-border-2 tw-border-white tw-bg-white tw-shadow-md sm:tw-h-9 sm:tw-w-9${index ? ' -tw-ml-2' : ''}`} style={{ zIndex: TEAM_AVATARS.length - index }} key={src}><HomeMedia className="tw-h-full tw-w-full tw-object-cover tw-object-top" src={src} alt="" /></span>)}</div>
            <strong dir={fa ? 'rtl' : 'ltr'} className="tw-min-w-0 tw-break-words tw-font-head tw-text-[10px] max-[359px]:tw-text-[9px] tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-sm">{fa ? 'تیم خان بوستان' : 'Khan Boostan Team'}</strong>
          </div>

          <div className="tw-group tw-absolute tw-end-0 tw-top-0 tw-h-[55%] tw-w-[48%] tw-overflow-hidden tw-rounded-md tw-bg-kb-paper tw-shadow-kb"><HomeMedia className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.04] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" src={INTRO_IMAGES.workers} alt="" /></div>

          <div className="tw-group tw-absolute tw-start-0 tw-bottom-0 tw-h-[72%] tw-w-[51%] tw-overflow-hidden tw-rounded-md tw-bg-kb-paper tw-shadow-kb"><HomeMedia className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.04] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" src={INTRO_IMAGES.cargo} alt="" /></div>

          <div className="tw-absolute tw-end-0 tw-bottom-0 tw-flex tw-h-[30%] tw-w-[46%] tw-flex-col tw-justify-center tw-gap-1 tw-overflow-hidden tw-rounded-md tw-bg-kb-navy tw-p-2 tw-text-white tw-shadow-kb sm:tw-h-[35%] sm:tw-p-5" dir="ltr">
            <WorldMapWatermark />
            <div className="tw-relative tw-z-10 tw-flex tw-items-center tw-gap-2 sm:tw-gap-3" dir={fa ? 'rtl' : 'ltr'}><strong dir="ltr" className="tw-font-head tw-text-3xl tw-font-bold tw-leading-none tw-text-white sm:tw-text-5xl">{fa ? '۳۰+' : '30+'}</strong><GlobeIcon /></div>
            <span className="tw-relative tw-z-10 tw-block tw-text-[10px] tw-font-medium tw-leading-4 tw-text-white/90 sm:tw-text-sm sm:tw-leading-5" dir={fa ? 'rtl' : 'ltr'}>{fa ? 'سال تجربه' : 'Years of Experience'}</span>
          </div>
        </div>
      </div>
    </SiteContainer>
  </section>
}

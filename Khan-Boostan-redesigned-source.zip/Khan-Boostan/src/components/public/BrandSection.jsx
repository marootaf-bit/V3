import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import BrandCard from './BrandCard.jsx'

export default function BrandSection({ brands, allBrands, categories, lang, c, L, selectedCategory, onCategoryChange }) {
  if (!allBrands.length) return null
  const hasFilter = categories.length > 0
  const brandCount = brands.length
  const gridLayout = brandCount === 1
    ? 'tw-mx-auto tw-w-full tw-max-w-xl'
    : brandCount === 2
      ? 'tw-mx-auto tw-w-full tw-max-w-4xl sm:tw-grid-cols-2'
      : 'sm:tw-grid-cols-2 lg:tw-grid-cols-3'
  const centeredRemainderIndex = brandCount > 2
    ? brandCount % 3 === 1 ? brandCount - 1 : brandCount % 3 === 2 ? brandCount - 2 : -1
    : -1
  return <section id="brands" className="tw-scroll-mt-24 tw-bg-kb-paper tw-py-10 sm:tw-py-14" aria-labelledby="brands-title"><SiteContainer>
    <div className="tw-mb-5 tw-grid tw-gap-3 md:tw-grid-cols-[minmax(0,1fr)_minmax(260px,.8fr)] md:tw-items-end">
      <div><Eyebrow>{c.brands}</Eyebrow><h2 id="brands-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{lang === 'fa' ? 'برندها و روابط عرضه' : 'Brands and distribution'}</h2></div>
      <p className="tw-text-sm tw-leading-6 tw-text-kb-body">{c.brandsNote}</p>
    </div>
    {hasFilter && <div className="tw-mb-4 tw-flex tw-flex-col tw-gap-2 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between">
      <div className="tw-w-full sm:tw-max-w-sm"><label htmlFor="brand-category-filter" className="tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body">{c.brandCategoryLabel}</label><select id="brand-category-filter" value={selectedCategory} onChange={(event) => onCategoryChange(event.target.value)} className="tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink focus:tw-border-kb-blue focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-blue/20"><option value="all">{c.allCategories}</option>{categories.map((category) => <option value={category.id} key={category.id}>{L(category.name)}</option>)}</select></div>
      {selectedCategory !== 'all' && <button type="button" onClick={() => onCategoryChange('all')} className="tw-inline-flex tw-min-h-10 tw-items-center tw-justify-center tw-rounded-kb tw-border tw-border-kb-blue tw-px-4 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-bg-kb-blue hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{c.clearFilters}</button>}
    </div>}
    {brands.length > 0 ? <div className={`tw-grid tw-gap-3 ${gridLayout}`}>{brands.map((item, index) => <BrandCard key={item.id ?? index} item={item} L={L} lang={lang} categories={categories} className={index === centeredRemainderIndex ? 'lg:tw-col-start-2' : ''} />)}</div> : <p className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 tw-text-sm tw-text-kb-body" role="status" aria-live="polite">{c.brandNoMatches}</p>}
  </SiteContainer></section>
}

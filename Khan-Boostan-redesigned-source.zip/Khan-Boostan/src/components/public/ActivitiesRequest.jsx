import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import PrimaryLink from './PrimaryLink.jsx'

export default function ActivitiesRequest({ requestPoints, fa }) {
  return <section className="tw-bg-kb-paper tw-py-12 sm:tw-py-16" aria-labelledby="activities-request-title"><SiteContainer>
    <div className="tw-flex tw-flex-col tw-gap-5 md:tw-flex-row md:tw-items-end md:tw-justify-between"><div className="tw-max-w-3xl"><Eyebrow>{fa ? 'برای آغاز گفتگو' : 'TO START THE CONVERSATION'}</Eyebrow><h2 id="activities-request-title" className="tw-mt-2 tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-4xl">{fa ? 'در درخواست خود چه معلوماتی بفرستید؟' : 'What should an enquiry include?'}</h2><p className="tw-mt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{fa ? 'با نوشتن مشخصات کالا، مقدار و مقصد، درخواست خود را روشن‌تر بیان کنید.' : 'Share the product details, quantity and destination to describe your enquiry clearly.'}</p></div><PrimaryLink to="/contact?kind=product" className="tw-shrink-0">{fa ? 'فرستادن درخواست' : 'Send an enquiry'}<ArrowIcon /></PrimaryLink></div>
    <ol className="tw-mt-7 tw-grid tw-gap-3 sm:tw-grid-cols-2 xl:tw-grid-cols-4">{requestPoints.map(([title, copy], index) => <li className="tw-flex tw-min-h-28 tw-items-start tw-gap-4 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4" key={title}><span className="tw-flex tw-h-9 tw-w-9 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-bg-kb-paper tw-text-xs tw-font-bold tw-text-kb-blue">{fa ? String(index + 1).replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[digit]).padStart(2, '۰') : String(index + 1).padStart(2, '0')}</span><span><b className="tw-block tw-text-sm tw-leading-5 tw-text-kb-navy">{title}</b><small className="tw-mt-1 tw-block tw-text-xs tw-leading-5 tw-text-kb-muted">{copy}</small></span></li>)}</ol>
  </SiteContainer></section>
}

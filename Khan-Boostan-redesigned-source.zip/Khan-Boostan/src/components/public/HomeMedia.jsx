import { useState } from 'react'

/** Home-only image wrapper: keeps the existing media, but replaces a failed request with abstract artwork. */
export default function HomeMedia({ src, alt = '', className = '', loading = 'lazy', decoding = 'async', ...props }) {
  const [failedSource, setFailedSource] = useState('')
  const decorative = !alt.trim()
  const frameClass = `tw-grid tw-place-items-center tw-overflow-hidden tw-bg-kb-paper ${className}`.trim()

  if (!src || failedSource === src) return <span className={frameClass} role={decorative ? undefined : 'img'} aria-label={decorative ? undefined : alt} aria-hidden={decorative ? 'true' : undefined}>
    <svg className="tw-h-12 tw-w-12 tw-text-kb-blue/70" viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m5 17 19-11 19 11v21L24 46 5 38z" />
      <path d="m5 17 19 11 19-11M24 28v18" />
      <path d="M12 12h9M32 36h6" stroke="#C4873B" strokeWidth="2" />
      <circle cx="35" cy="12" r="3" fill="#C4873B" stroke="none" />
    </svg>
  </span>

  return <img src={src} alt={alt} loading={loading} decoding={decoding} onError={() => setFailedSource(src)} className={className} {...props} />
}

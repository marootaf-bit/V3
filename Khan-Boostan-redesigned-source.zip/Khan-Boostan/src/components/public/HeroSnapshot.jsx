import { useContent } from '../../../src/lib/store.jsx'
import { usePublicDict } from '../../lib.jsx'
import SiteContainer from './SiteContainer.jsx'

export default function HeroSnapshot() {
  const { settings } = useContent()
  const { L, t } = usePublicDict()
  const highlights = (settings.home?.highlights ?? []).filter((item) => item.id !== 'markets')
  if (!highlights.length) return null
  return <section className="tw-border-b tw-border-kb-line tw-bg-white tw-py-4 sm:tw-py-5" aria-label={t('glance')}><SiteContainer className="tw-grid tw-gap-3 lg:tw-grid-cols-[.35fr_1.65fr] lg:tw-items-center lg:tw-gap-5">
    <div className="tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-2 lg:tw-flex-col lg:tw-items-start">
      <p className="tw-font-head tw-text-lg tw-font-bold tw-text-kb-navy sm:tw-text-xl">{t('glance')}</p>
    </div>
    <dl className="tw-grid tw-grid-cols-2 tw-gap-2 sm:tw-grid-cols-3">{highlights.map((item, index) => <div className={`tw-flex tw-min-h-0 tw-flex-col tw-justify-center tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-3 sm:tw-min-h-20 sm:tw-p-4 ${highlights.length % 2 === 1 && index === highlights.length - 1 ? 'tw-col-span-2 sm:tw-col-span-1' : ''}`} key={item.id}><dt className="tw-text-[10px] tw-leading-4 tw-text-kb-muted sm:tw-text-[11px] sm:tw-leading-5">{L(item.label)}</dt><dd className="tw-mt-1 tw-text-xs tw-font-bold tw-leading-5 tw-text-kb-navy sm:tw-text-sm sm:tw-leading-6">{L(item.value)}</dd></div>)}</dl>
  </SiteContainer></section>
}

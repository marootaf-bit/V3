import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'

export default function PremiumReveals({ data }) {
  const { pathname } = useLocation()
  useEffect(() => {
    if (!data || !['/about', '/partners'].includes(pathname) || !('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const isAbout = pathname === '/about'
    const profileClass = isAbout ? 'about-motion-target' : 'partners-motion-target'
    const visibleClass = isAbout ? 'about-motion-visible' : 'partners-motion-visible'
    const selector = isAbout
      ? '.kb-about .ref-page-hero-copy,.kb-about .kb-intro-grid,.kb-about .kb-scope-grid,.kb-about .kb-purpose-grid,.kb-about .kb-values-grid,.kb-about .kb-message-grid,.kb-about .kb-team-grid,.kb-about .kb-teaser-grid,.kb-about .kb-milestone,.kb-about .kb-credential-card,.kb-about .kb-about-relation-grid > a,.kb-about .kb-responsibility-inner'
      : '.kb-partners .ref-page-hero-copy,.kb-partners .kb-relations-nav-inner,.kb-partners .kb-relation-section .kb-section-head,.kb-partners .kb-entity-grid,.kb-partners .kb-brand-grid,.kb-partners .kb-partners-crosslinks .wrap'
    const targets = [...document.querySelectorAll(selector)]
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) if (entry.isIntersecting) {
        entry.target.classList.add(visibleClass)
        observer.unobserve(entry.target)
      }
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.08 })
    for (const target of targets) { target.classList.add(profileClass); observer.observe(target) }
    return () => {
      observer.disconnect()
      targets.forEach((target) => target.classList.remove(profileClass, visibleClass))
    }
  }, [data, pathname])
  return null
}

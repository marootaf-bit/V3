import { Link } from 'react-router-dom'
import { publicBrandLabel } from '../../lib.jsx'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function BrandDirectory({ brands, categories, L, lang, fa }) {
  const visibleBrands = brands.filter((brand) => Boolean(publicBrandLabel(brand, L, lang, categories)))
  if (!visibleBrands.length) return null
  return <section className="tw-border-t tw-border-kb-line tw-bg-white tw-py-10 sm:tw-py-12" aria-labelledby="catalogue-brands-title"><SiteContainer>
    <div className="tw-flex tw-flex-col tw-gap-4 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between"><div><Eyebrow>{fa ? 'برندهای عرضه‌شده' : 'BRANDS OFFERED'}</Eyebrow><h2 id="catalogue-brands-title" className="tw-mt-2 tw-max-w-3xl tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{fa ? 'برند و حوزهٔ کالا، جدا از روابط شرکتی.' : 'Brand lines, distinct from company relationships.'}</h2><p className="tw-mt-2 tw-max-w-3xl tw-text-sm tw-leading-6 tw-text-kb-body">{fa ? 'حوزه‌های محصول مرتبط با هر برند را مرور کنید.' : 'Browse the product areas associated with each brand.'}</p></div><Link to="/partners#brands" className="tw-inline-flex tw-min-h-10 tw-shrink-0 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'فهرست کامل برندها' : 'Full brand directory'}<ArrowIcon /></Link></div>
    <div className="tw-mt-6 tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-4">{visibleBrands.map((brand, index) => <article className="tw-flex tw-min-h-28 tw-items-start tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4" key={brand.id ?? index}><span className="tw-flex tw-h-10 tw-w-10 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-kb tw-bg-white tw-text-lg tw-font-bold tw-text-kb-blue" aria-hidden="true">{(publicBrandLabel(brand, L, lang, categories).trim()[0] || '•').toLocaleUpperCase()}</span><div className="tw-min-w-0"><b className="tw-block tw-text-sm tw-leading-5 tw-text-kb-navy">{publicBrandLabel(brand, L, lang, categories)}</b>{brand.relation && L(brand.relation) && <p className="tw-mt-1 tw-text-xs tw-leading-5 tw-text-kb-body">{L(brand.relation)}</p>}{brand.country && L(brand.country) && <small className="tw-mt-1 tw-block tw-text-[10px] tw-text-kb-muted">{L(brand.country)}</small>}</div></article>)}</div>
  </SiteContainer></section>
}

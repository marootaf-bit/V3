export default function PathwayIcon({ type, size = 34 }) {
  const common = { width: size, height: size, viewBox: '0 0 32 32', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true }
  return <svg {...common}>
    {type === 'import' && <><path d="M16 4v14" /><path d="m10 13 6 6 6-6" /><path d="M6 21h20v7H6z" /><path d="M11 24h10" /></>}
    {type === 'export' && <><circle cx="16" cy="16" r="11" /><path d="M5 16h22M16 5c3 3 4 7 4 11s-1 8-4 11c-3-3-4-7-4-11s1-8 4-11Z" /><path d="m21 8 5-1-1 5" /></>}
    {type === 'sourcing' && <><circle cx="13.5" cy="13.5" r="8.5" /><path d="m20 20 7 7" /><path d="M10 14h7M13.5 10.5v7" /></>}
  </svg>
}

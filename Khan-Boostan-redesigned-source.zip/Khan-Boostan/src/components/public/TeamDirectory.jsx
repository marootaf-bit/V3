import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import CopyPageLink from './CopyPageLink.jsx'
import { publicTeamName } from '../../lib.jsx'

const publicTeamBio = (member, L) => L(member?.bio)

export default function TeamDirectory({ members, L, lang, t }) {
  const visibleMembers = members.filter((member) => publicTeamName(member, L, lang))
  if (!visibleMembers.length) return null
  const centerLastCard = visibleMembers.length % 3 === 1
  return <section id="team" className="tw-scroll-mt-28 tw-bg-kb-paper tw-py-8 sm:tw-py-11 print:tw-bg-white" aria-labelledby="about-team-title"><SiteContainer>
    <Eyebrow>{t('team_t')}</Eyebrow>
    <div className="tw-mt-2 tw-flex tw-items-center tw-gap-2"><h2 id="about-team-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{t('nav_team')}</h2><CopyPageLink id="team" lang={lang} sectionLabel={t('nav_team')} /></div>
    <div className="tw-mt-5 tw-grid tw-grid-cols-1 tw-items-stretch tw-gap-3 sm:tw-grid-cols-2 lg:tw-mt-6 lg:tw-grid-cols-3">
      {visibleMembers.map((member, index) => {
        const centerFinal = centerLastCard && index === members.length - 1
        const bio = publicTeamBio(member, L)
        return <article className={`tw-grid tw-h-full tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-3.5 sm:tw-gap-4 sm:tw-p-4 print:tw-break-inside-avoid ${member.photo ? 'tw-grid-cols-[4.5rem_minmax(0,1fr)]' : 'tw-grid-cols-1'} ${centerFinal ? 'sm:tw-col-span-2 lg:tw-col-span-1 lg:tw-col-start-2' : ''}`} key={member.id ?? index} data-member-id={member.id}>
          {member.photo && <img src={member.photo} alt="" width="96" height="118" loading="lazy" decoding="async" className="tw-aspect-[4/5] tw-w-[4.5rem] tw-rounded-kb tw-object-cover" />}
          <div className="tw-min-w-0"><h3 className="tw-break-words tw-text-sm tw-font-bold tw-leading-6 tw-text-kb-navy">{publicTeamName(member, L, lang)}</h3>{L(member.role) && <p className="tw-mt-1 tw-text-xs tw-font-bold tw-leading-5 tw-text-kb-blue">{L(member.role)}</p>}{bio && <p className="tw-mt-2 tw-break-words tw-text-xs tw-leading-5 tw-text-kb-body">{bio}</p>}</div>
        </article>
      })}
    </div>
  </SiteContainer></section>
}

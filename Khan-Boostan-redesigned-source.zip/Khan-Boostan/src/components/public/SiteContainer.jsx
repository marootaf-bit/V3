export default function SiteContainer({ as: Element = 'div', className = '', children, ...props }) {
  return <Element className={`tw-mx-auto tw-w-full tw-max-w-[1320px] tw-px-4 sm:tw-px-6 lg:tw-px-8 ${className}`.trim()} {...props}>{children}</Element>
}

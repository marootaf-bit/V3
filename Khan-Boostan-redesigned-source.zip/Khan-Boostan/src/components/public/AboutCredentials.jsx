import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function AboutCredentials({ documents, L, lang, c, description }) {
  if (!documents.length) return null
  return <section className="tw-bg-white tw-py-10 sm:tw-py-14" aria-labelledby="about-credentials-title"><SiteContainer><div className="tw-mb-5 tw-grid tw-gap-3 md:tw-grid-cols-2 md:tw-items-end"><div><Eyebrow>{lang === 'fa' ? 'اسناد شرکت' : 'COMPANY DOCUMENTS'}</Eyebrow><h2 id="about-credentials-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{c.credentials}</h2></div><p className="tw-text-sm tw-leading-6 tw-text-kb-body">{description}</p></div><div className="tw-grid tw-gap-3 md:tw-grid-cols-2">{documents.map((doc, index) => <article className="tw-flex tw-flex-col tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 sm:tw-flex-row sm:tw-items-start sm:tw-justify-between" key={doc.id ?? index}><div><span className="tw-inline-flex tw-rounded-full tw-bg-white tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-blue">{lang === 'fa' ? 'سند' : 'DOC'}</span><h3 className="tw-mt-2 tw-text-sm tw-font-bold tw-text-kb-navy">{L(doc.title)}</h3><p className="tw-mt-1 tw-text-xs tw-leading-5 tw-text-kb-body">{doc.description}</p></div><Link className="tw-inline-flex tw-min-h-9 tw-shrink-0 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to="/downloads">{lang === 'fa' ? 'مرکز اسناد' : 'Document centre'}<ArrowIcon kind="up" size={13} /></Link></article>)}</div></SiteContainer></section>
}

import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'

const CAPABILITY_IDS = ['food', 'agri', 'construction', 'household', 'textile']
const CAPABILITY_IMAGES = ['/images/trade-highway.webp', '/images/gallery-loading.webp']

export default function HomeCapabilities({ categories, products, L, fa, lang }) {
  const capabilities = CAPABILITY_IDS.map((id) => categories.find((item) => item.id === id)).filter((item) => item && L(item.name))
  if (!capabilities.length) return null
  const count = (id) => products.filter((item) => item.category === id && L(item.name)).length
  const formatCount = new Intl.NumberFormat(lang === 'fa' ? 'fa-AF' : 'en', { useGrouping: false })
  return <section className="tw-bg-kb-paper tw-py-12 sm:tw-py-14" aria-labelledby="home-capabilities-title"><SiteContainer>
    <div className="tw-mb-6 tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between"><div><Eyebrow>{fa ? 'توانمندی‌ها' : 'CAPABILITIES'}</Eyebrow><h2 id="home-capabilities-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{fa ? 'حوزه‌های کالا' : 'Product ranges'}</h2></div></div>
    <div className="tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-3 xl:tw-grid-cols-5">{capabilities.map((item) => <Link to={`/products?c=${item.id}`} className="tw-flex tw-min-h-28 tw-flex-col tw-justify-between tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 hover:tw-border-kb-blue/40 focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" key={item.id}><span className="tw-flex tw-items-center tw-justify-between tw-gap-2"><b className="tw-text-sm tw-leading-6 tw-text-kb-navy">{L(item.name)}</b><span className="tw-shrink-0 tw-text-xs tw-font-bold tw-text-kb-blue">{formatCount.format(count(item.id))}{fa ? ' قلم' : ' items'}</span></span></Link>)}</div>
    <div className="tw-mt-5 tw-grid tw-grid-cols-2 tw-gap-3 sm:tw-gap-4" aria-hidden="true">{CAPABILITY_IMAGES.map((src) => <img className="tw-aspect-[16/7] tw-w-full tw-rounded-kb-lg tw-object-cover" src={src} alt="" loading="lazy" key={src} />)}</div>
  </SiteContainer></section>
}

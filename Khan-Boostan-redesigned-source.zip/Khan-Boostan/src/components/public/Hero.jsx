import { Link } from 'react-router-dom'
import { usePublicDict } from '../../lib.jsx'
import SiteContainer from './SiteContainer.jsx'
import HeroSnapshot from './HeroSnapshot.jsx'

export default function Hero({ image, showImage = true, showSnapshot = false, crumbs = [], title, sub, children, compact = false }) {
  const { t, lang } = usePublicDict()
  const photo = image || '/images/hero-trade.webp'
  const overlayDirection = lang === 'en' ? 'tw-bg-gradient-to-r' : 'tw-bg-gradient-to-l'
  const spacing = compact ? 'tw-py-7 sm:tw-py-10 lg:tw-py-12' : 'tw-py-10 sm:tw-py-14 lg:tw-py-16'
  const crumbSpacing = compact ? 'tw-mb-4 sm:tw-mb-5' : 'tw-mb-7'
  return <><section className={`tw-relative tw-isolate tw-flex tw-flex-col tw-justify-center tw-overflow-hidden tw-bg-kb-navy lg:tw-min-h-[calc(91svh_-_78.26px)] ${spacing}`} aria-labelledby="public-page-title">
    {showImage && <img className="tw-absolute tw-inset-0 tw-h-full tw-w-full tw-object-cover tw-object-center" src={photo} alt="" aria-hidden="true" fetchpriority="high" />}
    <div className={`tw-absolute tw-inset-0 ${overlayDirection} tw-from-kb-navy/95 tw-via-kb-navy/85 tw-to-kb-navy/55`} aria-hidden="true" />
    <SiteContainer className="tw-relative tw-z-10">
      <nav className={`${crumbSpacing} tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-xs tw-text-white/75`} aria-label={lang === 'fa' ? 'مسیر صفحه' : 'Breadcrumb'}>
        <Link className="tw-rounded-sm hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to="/">{t('home')}</Link>
        {crumbs.map(([to, label], index) => to ? <Link key={`${to}-${index}`} className="tw-rounded-sm hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to={to}>{label}</Link> : <b key={`current-${index}`} className="tw-font-medium tw-text-white" aria-current="page">{label}</b>)}
      </nav>
      <div className="tw-max-w-3xl tw-text-start">
        <h1 id="public-page-title" className="tw-max-w-3xl tw-break-words tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-white sm:tw-text-4xl lg:tw-text-5xl">{title}</h1>
        {sub && <p className={`${compact ? 'tw-mt-3 tw-leading-7' : 'tw-mt-4 tw-leading-8'} tw-max-w-2xl tw-whitespace-pre-line tw-break-words tw-text-base tw-text-white/85 sm:tw-text-lg`}>{sub}</p>}
        {children && <div className="tw-mt-6 tw-flex tw-flex-wrap tw-items-center tw-gap-3">{children}</div>}
      </div>
      <div className={`${compact ? 'tw-mt-7 sm:tw-mt-8' : 'tw-mt-10 sm:tw-mt-12'} tw-h-1 tw-w-16 tw-bg-kb-gold`} aria-hidden="true" />
    </SiteContainer>
  </section>{showSnapshot && <HeroSnapshot />}</>
}

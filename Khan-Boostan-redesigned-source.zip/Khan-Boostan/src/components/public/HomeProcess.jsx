import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import HomeMedia from './HomeMedia.jsx'

export default function HomeProcess({ steps, fa }) {
  const listRef = useRef(null)
  const [hasEntered, setHasEntered] = useState(false)
  const [expandedIndex, setExpandedIndex] = useState(null)

  useEffect(() => {
    const node = listRef.current
    if (!node) return undefined
    if (!('IntersectionObserver' in window)) {
      setHasEntered(true)
      return undefined
    }
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        setHasEntered(true)
        observer.disconnect()
      }
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' })
    observer.observe(node)
    return () => observer.disconnect()
  }, [])

  return <section id="home-process" dir={fa ? 'rtl' : 'ltr'} className="tw-scroll-mt-20 tw-bg-kb-paper tw-py-12 sm:tw-py-16" aria-labelledby="home-process-title"><SiteContainer>
    <div className="tw-mb-7 tw-flex tw-flex-col tw-gap-4 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between">
      <div>
        <Eyebrow>{fa ? 'روند همکاری' : 'COOPERATION PROCESS'}</Eyebrow>
        <h2 id="home-process-title" className="tw-mt-2 tw-max-w-3xl tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-4xl">{fa ? 'روند همکاری: از درخواست تا تحویل' : 'Cooperation process: request to delivery'}</h2>
      </div>
      <Link to="/process" className="tw-inline-flex tw-min-h-10 tw-shrink-0 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'جزئیات روند' : 'View details'}<ArrowIcon /></Link>
    </div>
    <ol ref={listRef} className="tw-grid tw-items-stretch tw-gap-4 sm:tw-grid-cols-2 lg:tw-grid-cols-4">
      {steps.map(([no, title, copy, image], index) => {
        const expanded = expandedIndex === index
        const detailsId = `home-process-step-details-${index}`
        return <li
          className={`tw-h-full tw-transition-all tw-duration-500 motion-reduce:tw-transition-none motion-reduce:tw-translate-y-0 motion-reduce:tw-opacity-100 ${hasEntered ? 'tw-translate-y-0 tw-opacity-100' : 'tw-translate-y-5 tw-opacity-0'}`}
          key={no}
          style={{ transitionDelay: hasEntered ? `${index * 90}ms` : '0ms' }}
        >
          <div className={`tw-group tw-flex tw-h-full tw-flex-col tw-overflow-hidden tw-rounded-kb-lg tw-border tw-bg-white tw-transition-all tw-duration-300 hover:tw-border-kb-blue hover:tw-shadow-md motion-reduce:tw-transition-none ${expanded ? 'tw-border-kb-blue tw-shadow-md' : 'tw-border-kb-line tw-shadow-sm'}`}>
            <button
              type="button"
              aria-expanded={expanded}
              aria-controls={detailsId}
              onClick={() => setExpandedIndex((current) => current === index ? null : index)}
              className="tw-block tw-w-full tw-appearance-none tw-border-0 tw-bg-transparent tw-p-0 tw-text-start tw-font-sans focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-inset focus-visible:tw-ring-kb-blue active:tw-scale-[0.99] tw-transition-transform motion-reduce:tw-transition-none"
            >
              <div className={`tw-relative tw-w-full tw-overflow-hidden tw-bg-kb-paper tw-transition-[height] tw-duration-300 motion-reduce:tw-transition-none ${expanded ? 'tw-h-52' : 'tw-h-44'}`}>
                <HomeMedia className="tw-h-full tw-w-full tw-object-cover tw-transition-transform tw-duration-500 tw-ease-out group-hover:tw-scale-105 group-active:tw-scale-[1.02] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100 motion-reduce:group-active:tw-scale-100" src={image} alt="" loading={index === 0 ? 'eager' : 'lazy'} />
                <div className="tw-pointer-events-none tw-absolute tw-inset-0 tw-bg-gradient-to-b tw-from-black/20 tw-to-transparent" aria-hidden="true" />
                <span className="tw-absolute tw-end-4 tw-top-4 tw-grid tw-h-9 tw-w-9 tw-place-items-center tw-rounded-full tw-border tw-border-kb-blue/30 tw-bg-white/90 tw-text-xs tw-font-bold tw-text-kb-blue tw-shadow-sm tw-backdrop-blur-sm tw-transition-colors group-hover:tw-border-kb-blue group-hover:tw-bg-kb-blue group-hover:tw-text-white motion-reduce:tw-transition-none">{no}</span>
              </div>
              <div className="tw-flex tw-items-start tw-justify-between tw-gap-3 tw-p-5">
                <div className="tw-min-w-0">
                  <h3 className="tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy tw-transition-colors group-hover:tw-text-kb-blue motion-reduce:tw-transition-none">{title}</h3>
                  <p className={`tw-mt-2 tw-text-xs tw-leading-relaxed tw-text-kb-muted ${expanded ? '' : 'tw-line-clamp-1'}`}>{copy}</p>
                </div>
                <span className={`tw-grid tw-h-7 tw-w-7 tw-shrink-0 tw-place-items-center tw-rounded-full tw-border tw-border-kb-line tw-text-kb-blue tw-transition-transform tw-duration-300 motion-reduce:tw-transition-none ${expanded ? 'tw-rotate-180' : ''}`} aria-hidden="true"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6" /></svg></span>
              </div>
            </button>
            <div id={detailsId} aria-hidden={!expanded} className={`tw-grid tw-transition-[grid-template-rows,opacity] tw-duration-300 motion-reduce:tw-transition-none ${expanded ? 'tw-grid-rows-[1fr] tw-opacity-100' : 'tw-grid-rows-[0fr] tw-opacity-0'}`}>
              <div className="tw-min-h-0 tw-overflow-hidden tw-px-5">
                <Link to="/process" tabIndex={expanded ? 0 : -1} className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-border-t tw-border-kb-line tw-pt-3 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'جزئیات این مرحله' : 'Step details'}<ArrowIcon /></Link>
              </div>
            </div>
          </div>
        </li>
      })}
    </ol>
  </SiteContainer></section>
}

import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function AboutScope({ scope, c, t }) {
  if (!scope.length) return null
  return <section className="tw-bg-kb-paper tw-py-10 sm:tw-py-14" aria-labelledby="about-scope-title"><SiteContainer>
    <div className="tw-mb-6 tw-grid tw-gap-3 md:tw-grid-cols-2 md:tw-items-end"><div><Eyebrow>{t('trade_intro_t')}</Eyebrow><h2 id="about-scope-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{t('trade_intro_t')}</h2></div><p className="tw-text-sm tw-leading-6 tw-text-kb-body">{c.scopeNote}</p></div>
    <div className="tw-grid tw-gap-4 md:tw-grid-cols-2">{scope.map((item) => <article className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5" key={item.id}><h3 className="tw-text-lg tw-font-bold tw-text-kb-navy">{item.title}</h3><p className="tw-mt-2 tw-text-sm tw-leading-7 tw-text-kb-body">{item.text}</p></article>)}</div>
    <Link className="tw-mt-5 tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to="/activities">{c.activityMore}<ArrowIcon kind="up" size={14} /></Link>
  </SiteContainer></section>
}

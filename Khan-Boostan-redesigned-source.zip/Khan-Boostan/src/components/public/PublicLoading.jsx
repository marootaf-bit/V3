import { usePublicDict } from '../../lib.jsx'
import SiteContainer from './SiteContainer.jsx'

export default function PublicLoading() {
  const { t } = usePublicDict()
  return <main id="main" className="tw-flex-1 tw-py-16" aria-busy="true"><SiteContainer><div className="tw-flex tw-min-h-24 tw-items-center tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-6" role="status" aria-live="polite"><span className="tw-h-5 tw-w-5 tw-animate-spin tw-rounded-full tw-border-2 tw-border-kb-blue/25 tw-border-t-kb-blue motion-reduce:tw-animate-none" aria-hidden="true" /><b className="tw-text-sm tw-text-kb-ink">{t('loading')}</b></div></SiteContainer></main>
}

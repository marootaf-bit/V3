import SiteContainer from './SiteContainer.jsx'
import CopyPageLink from './CopyPageLink.jsx'

export default function AboutFaqSection({ items, L, c, lang }) {
  if (!items.length) return null
  return <section id="about-faq" className="tw-scroll-mt-24 tw-bg-white tw-py-8 sm:tw-py-10 print:tw-bg-white" aria-labelledby="about-faq-title"><SiteContainer>
    <div className="tw-flex tw-items-center tw-gap-2"><h2 id="about-faq-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{c.faqTitle}</h2><CopyPageLink id="about-faq" lang={lang} sectionLabel={c.faqTitle} /></div>
    <div className="tw-mt-4 tw-grid tw-gap-3 md:tw-grid-cols-2">
      {items.map((item, index) => <article key={item.id ?? index} className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 sm:tw-p-5 print:tw-break-inside-avoid">
        <h3 className="tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{L(item.q)}</h3>
        <p className="tw-mt-2 tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{L(item.a)}</p>
      </article>)}
    </div>
  </SiteContainer></section>
}

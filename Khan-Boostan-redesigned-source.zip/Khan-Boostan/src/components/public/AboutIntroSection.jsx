import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import CopyPageLink from './CopyPageLink.jsx'

export default function AboutIntroSection({ c, L, companyLegal, fullIntroduction, natureNote, history, structure, lang }) {
  return <section id="about-intro" className="tw-scroll-mt-24 tw-bg-kb-paper tw-py-8 sm:tw-py-11 print:tw-bg-white" aria-labelledby="about-intro-title"><SiteContainer className="tw-grid tw-gap-6 lg:tw-grid-cols-[1.15fr_.85fr] lg:tw-gap-10">
    <div>
      <div className="tw-mb-5 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-p-5">
        <Eyebrow>{c.official}</Eyebrow>
        <p className="tw-mt-2 tw-text-base tw-font-bold tw-leading-7 tw-text-kb-navy sm:tw-text-lg">{L(companyLegal)}</p>
        {companyLegal?.en && L(companyLegal) !== companyLegal.en && <p className="tw-mt-1 tw-text-sm tw-font-medium tw-text-kb-muted" dir="ltr">{companyLegal.en}</p>}
      </div>
      <div className="tw-flex tw-items-center tw-gap-2"><h2 id="about-intro-title" className="tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{c.intro}</h2><CopyPageLink id="about-intro" lang={lang} sectionLabel={c.intro} /></div>
      {fullIntroduction && <p className="tw-mt-4 tw-max-w-[68ch] tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{fullIntroduction}</p>}
      {natureNote && <p className="tw-mt-4 tw-max-w-[68ch] tw-border-s-2 tw-border-kb-gold tw-ps-3 tw-text-sm tw-leading-7 tw-text-kb-body"><strong className="tw-font-bold tw-text-kb-navy">{c.natureTitle}:</strong> {natureNote}</p>}
      {(history || structure) && <div className="tw-mt-5 tw-grid tw-gap-3 sm:tw-grid-cols-2">
        {history && <article className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-p-5"><h3 className="tw-text-sm tw-font-bold tw-text-kb-navy">{c.history}</h3><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{history}</p></article>}
        {structure && <article className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-p-5"><h3 className="tw-text-sm tw-font-bold tw-text-kb-navy">{c.structure}</h3><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{structure}</p></article>}
      </div>}
    </div>
    <aside className="tw-grid tw-grid-cols-2 tw-content-start tw-gap-3 lg:tw-grid-cols-1 lg:tw-gap-4" aria-label={lang === 'en' ? 'Company images' : 'تصویرهای شرکت'}>
      <figure className="tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white"><img className="tw-aspect-[4/3] tw-w-full tw-object-cover" src="/images/about-office.webp" srcSet="/images/about-office-sm.webp 640w, /images/about-office-md.webp 1000w, /images/about-office.webp 1536w" sizes="(max-width: 900px) 50vw, 40vw" alt="" width="1536" height="1024" loading="lazy" decoding="async" /><figcaption className="tw-p-3"><span className="tw-text-xs tw-font-semibold tw-leading-5 tw-text-kb-navy">{c.photo}</span></figcaption></figure>
      <figure className="tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white"><img className="tw-aspect-[4/3] tw-w-full tw-object-cover" src="/images/news-meeting.webp" srcSet="/images/news-meeting-sm.webp 640w, /images/news-meeting-md.webp 1000w, /images/news-meeting.webp 1536w" sizes="(max-width: 900px) 50vw, 40vw" alt="" width="1536" height="1024" loading="lazy" decoding="async" /><figcaption className="tw-p-3"><span className="tw-text-xs tw-font-semibold tw-leading-5 tw-text-kb-navy">{c.meetingPhoto}</span></figcaption></figure>
    </aside>
  </SiteContainer></section>
}

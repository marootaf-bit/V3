export default function SkipLink({ lang = 'fa' }) {
  const moveToMain = (event) => {
    event.preventDefault()
    const target = document.getElementById('main')
    if (!target) return
    target.setAttribute('tabindex', '-1')
    target.focus({ preventScroll: true })
    target.scrollIntoView({ behavior: 'auto', block: 'start' })
  }
  return <a href="#main" className="tw-sr-only focus:tw-not-sr-only focus:tw-fixed focus:tw-start-3 focus:tw-top-3 focus:tw-z-[100] focus:tw-rounded-kb focus:tw-bg-kb-blue focus:tw-px-4 focus:tw-py-3 focus:tw-font-bold focus:tw-text-white focus:tw-shadow-kb-lift focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-gold" onClick={moveToMain}>{lang === 'fa' ? 'رفتن به محتوای اصلی' : 'Skip to main content'}</a>
}

import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function ActivitiesProcess({ processSteps, fa }) {
  return <section className="tw-bg-white tw-py-12 sm:tw-py-16" aria-labelledby="activities-process-title"><SiteContainer>
    <div className="tw-mb-7 tw-flex tw-flex-col tw-gap-4 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between"><div><Eyebrow>{fa ? 'روند همکاری' : 'COOPERATION PROCESS'}</Eyebrow><h2 id="activities-process-title" className="tw-max-w-3xl tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-4xl">{fa ? 'از درخواست تا تحویل' : 'From enquiry to delivery'}</h2></div><Link className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to="/process">{fa ? 'مشاهدهٔ جزئیات' : 'View details'}<ArrowIcon /></Link></div>
    <ol className="tw-grid tw-gap-4 sm:tw-grid-cols-2 xl:tw-grid-cols-4">{processSteps.map(([title, copy], index) => <li className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4" key={title}><span className="tw-grid tw-h-8 tw-w-8 tw-place-items-center tw-rounded-full tw-border tw-border-kb-gold/50 tw-bg-white tw-text-[11px] tw-font-bold tw-text-kb-blue">{fa ? String(index + 1).padStart(2, '0').replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[digit]) : String(index + 1).padStart(2, '0')}</span><h3 className="tw-mt-2 tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{title}</h3><p className="tw-mt-2 tw-text-xs tw-leading-5 tw-text-kb-body">{copy}</p></li>)}</ol>
  </SiteContainer></section>
}

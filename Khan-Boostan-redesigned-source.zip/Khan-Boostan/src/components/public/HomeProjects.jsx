import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import HomeMedia from './HomeMedia.jsx'
import { publicItemName, publicSlug } from '../../lib.jsx'

export default function HomeProjects({ projects, L, fa, lang, t }) {
  if (!projects.length) return null
  const year = (value) => new Intl.NumberFormat(lang === 'fa' ? 'fa-AF' : 'en', { useGrouping: false }).format(Number(value) || 0)
  const caseLinkLabel = (item) => `${t('view_details')}: ${publicItemName(L(item.title))}`

  return <section id="home-projects" className="tw-scroll-mt-20 tw-bg-white tw-py-12 sm:tw-py-16" aria-labelledby="home-projects-title">
    <SiteContainer>
      <div className="tw-mb-6 tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between">
        <div>
          <Eyebrow>{fa ? 'پرونده‌های تجارتی' : 'TRADE CASES'}</Eyebrow>
          <h2 id="home-projects-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{fa ? 'پرونده‌های همکاری' : 'Trade cases'}</h2>
        </div>
        <Link to="/projects" className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('view_all')}<ArrowIcon /></Link>
      </div>
      <div className="tw-flex tw-flex-wrap tw-justify-center tw-gap-4">
        {projects.filter((item) => L(item.title)).map((item) => <article className="tw-flex tw-basis-full tw-shrink-0 tw-flex-col tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white sm:tw-basis-[calc(50%_-_0.5rem)] lg:tw-basis-[calc(33.333333%_-_0.666667rem)]" key={item.id}>
          <Link to={`/projects#project-${publicSlug(item.id)}`} aria-label={caseLinkLabel(item)} className="tw-block tw-aspect-[16/9] tw-overflow-hidden tw-bg-kb-paper focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">
            <HomeMedia src={item.image || '/images/project-construction.webp'} alt="" className="tw-h-full tw-w-full tw-object-cover tw-transition-transform hover:tw-scale-[1.03] motion-reduce:tw-transition-none motion-reduce:hover:tw-scale-100" />
          </Link>
          <div className="tw-flex tw-flex-1 tw-flex-col tw-p-4">
            <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-[10px] tw-font-bold tw-text-kb-muted">
              <span>{L(item.sector)}</span>
              {item.year && <><span aria-hidden="true">·</span><span>{year(item.year)}</span></>}
            </div>
            <h3 className="tw-mt-2 tw-break-words tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy"><Link to={`/projects#project-${publicSlug(item.id)}`} className="hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{publicItemName(L(item.title))}</Link></h3>
            {L(item.result) && <p className="tw-mt-2 tw-whitespace-pre-line tw-break-words tw-text-xs tw-leading-6 tw-text-kb-body">{L(item.result)}</p>}
            {publicItemName(L(item.client)) && <p className="tw-mt-auto tw-break-words tw-pt-2 tw-text-xs tw-font-bold tw-text-kb-muted">{fa ? 'از:' : 'From:'} {publicItemName(L(item.client))}</p>}
          </div>
        </article>)}
      </div>
    </SiteContainer>
  </section>
}

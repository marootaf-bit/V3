import { Link } from 'react-router-dom'

const variants = {
  blue: 'tw-bg-kb-blue tw-text-white hover:tw-bg-kb-navy',
  gold: 'tw-bg-kb-gold tw-text-kb-navy hover:tw-bg-kb-navy hover:tw-text-white',
  light: 'tw-bg-white tw-text-kb-navy hover:tw-bg-kb-paper',
  outline: 'tw-border tw-border-white/70 tw-bg-white/5 tw-text-white hover:tw-bg-white hover:tw-text-kb-navy',
}

export default function PrimaryLink({ to, variant = 'blue', className = '', children, ...props }) {
  return <Link to={to} className={`tw-inline-flex tw-min-h-11 tw-items-center tw-justify-center tw-gap-2 tw-rounded-kb tw-px-5 tw-py-2.5 tw-text-sm tw-font-bold tw-transition-colors motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold focus-visible:tw-ring-offset-2 ${variants[variant] ?? variants.blue} ${className}`.trim()} {...props}>{children}</Link>
}

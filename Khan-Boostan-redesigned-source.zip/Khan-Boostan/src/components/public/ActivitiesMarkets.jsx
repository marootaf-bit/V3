import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function ActivitiesMarkets({ categories, industries, L, fa }) {
  const visibleCategories = categories.filter((category) => Boolean(L(category.name)))
  const visibleIndustries = industries.filter((item) => Boolean(L(item.title) || L(item.text)))
  if (!visibleCategories.length && !visibleIndustries.length) return null
  return <section className="tw-bg-kb-paper tw-py-12 sm:tw-py-16" aria-labelledby="activities-markets-title"><SiteContainer>
    <Eyebrow>{fa ? 'فعالیت‌های تجارتی' : 'Trade activities'}</Eyebrow><h2 id="activities-markets-title" className="tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-4xl">{fa ? 'حوزه‌های کالا' : 'Product areas'}</h2>
    {visibleCategories.length > 0 && <div className="tw-mt-5 tw-divide-y tw-divide-kb-line tw-border-y tw-border-kb-line">{visibleCategories.map((category) => <Link className="tw-flex tw-min-h-16 tw-items-center tw-gap-3 tw-py-2 hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={`/products/?c=${category.id}`} key={category.id}><div className="tw-min-w-0 tw-flex-1"><h3 className="tw-text-sm tw-text-kb-navy">{L(category.name)}</h3>{L(category.description) && <small className="tw-mt-1 tw-block tw-text-xs tw-leading-5 tw-text-kb-muted">{L(category.description)}</small>}</div><ArrowIcon kind="up" size={14} className="tw-shrink-0 tw-text-kb-gold" /></Link>)}</div>}
    {visibleIndustries.length > 0 && <div className="tw-mt-6 tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-4">{visibleIndustries.map((item, index) => <article className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4" key={`${L(item.title)}-${index}`}>{L(item.title) && <h3 className="tw-text-sm tw-font-bold tw-text-kb-navy">{L(item.title)}</h3>}{L(item.text) && <p className="tw-mt-2 tw-text-xs tw-leading-5 tw-text-kb-body">{L(item.text)}</p>}</article>)}</div>}
  </SiteContainer></section>
}

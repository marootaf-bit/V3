import SiteContainer from './SiteContainer.jsx'

export default function HomeTicker({ item, L, lang }) {
  if (!item || !L(item.value) || !L(item.label)) return null
  return <section className="tw-bg-kb-navy tw-py-4 tw-text-white" aria-label={lang === 'en' ? 'Khan Boostan import, export and active markets' : 'واردات، صادرات و بازارهای فعال خان بوستان'}><SiteContainer className="tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-center sm:tw-justify-between"><p className="tw-font-head tw-text-xs tw-font-bold tw-tracking-[.12em] tw-text-white/90" dir="ltr">KHAN BOOSTAN • IMPORT • EXPORT •</p><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2"><b className="tw-text-sm tw-font-bold tw-text-white">{L(item.value)} {L(item.label)}</b></div></SiteContainer></section>
}

import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import HomeMedia from './HomeMedia.jsx'

export default function HomeGallery({ items, fa, lang, L, t }) {
  if (!items.length) return null
  return <section id="home-gallery" className="tw-scroll-mt-20 tw-bg-white tw-py-12 sm:tw-py-16" aria-labelledby="home-gallery-title"><SiteContainer>
    <div className="tw-mb-7 tw-flex tw-flex-col tw-gap-4 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between">
      <div><Eyebrow>{fa ? 'تصاویر' : 'PICTURES'}</Eyebrow><h2 id="home-gallery-title" className="tw-mt-2 tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-4xl">{t('gallery_t')}</h2></div>
      <Link to="/gallery" className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('view_all')}<ArrowIcon /></Link>
    </div>
    <div className="tw-flex tw-flex-wrap tw-items-start tw-justify-center tw-gap-3">{items.map((item, index) => <figure className="tw-flex tw-basis-[calc(50%_-_0.375rem)] tw-shrink-0 tw-flex-col tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white md:tw-basis-[calc(33.333333%_-_0.5rem)] lg:tw-basis-[calc(25%_-_0.5625rem)]" key={item.id ?? index}>
      <Link to={item.video ? '/gallery#videos' : '/gallery'} className="tw-group tw-relative tw-block tw-aspect-[4/3] tw-w-full tw-overflow-hidden tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">
        <HomeMedia className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.04] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" src={item.poster || item.image} alt="" />
        <span className="tw-absolute tw-inset-0 tw-bg-gradient-to-t tw-from-kb-navy/45 tw-via-transparent tw-to-transparent" aria-hidden="true" />
        {item.video && <span className="tw-absolute tw-inset-0 tw-grid tw-place-items-center" aria-hidden="true"><span className="tw-grid tw-h-12 tw-w-12 tw-place-items-center tw-rounded-full tw-bg-kb-navy/80 tw-text-white"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.14v13.72a1 1 0 0 0 1.5.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86a1 1 0 0 0-1.5.86z" /></svg></span></span>}
        <span className="tw-sr-only">{L(item.caption) || (fa ? 'دیدن در گالری' : 'View in gallery')}</span>
      </Link>
      {L(item.caption) && <figcaption className="tw-whitespace-pre-line tw-break-words tw-p-3 tw-text-xs tw-leading-5 tw-text-kb-body sm:tw-p-4">{L(item.caption)}</figcaption>}
    </figure>)}</div>
  </SiteContainer></section>
}

import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'

const ROUTE_MOTION = {
  '/': [
    ['.ref-home-hero-copy', 'home-motion-hero'], ['.ref-overview-copy', 'home-motion-origin'], ['.ref-metric', 'home-motion-count'],
    ['.ref-capability-item', 'home-motion-route'], ['.ref-path-card', 'home-motion-path'],
    ['.ref-category-card', 'home-motion-catalogue'], ['.ref-workflow-visual', 'home-motion-image'],
    ['.ref-step', 'home-motion-step'], ['.ref-journal-feature', 'home-motion-feature'],
    ['.ref-journal-row,.ref-journal-case', 'home-motion-story'], ['.ref-home-network-card', 'home-motion-network'],
    ['.ref-home-gallery-tile', 'home-motion-gallery'],
  ],
  '/products': [
    ['.ref-shop-hero-copy', 'product-motion-hero'], ['.ref-category-chip', 'product-motion-chip'], ['.ref-product-card', 'product-motion-card'],
    ['.ref-directory-item', 'product-motion-row'], ['.ref-brand-line-card', 'product-motion-brand'],
  ],
  '/news': [
    ['.ref-page-hero-copy', 'news-motion-heading'], ['.ref-media-hero-meta', 'news-motion-issue'],
    ['.ref-news-hub-inner > a', 'news-motion-sidebar'], ['.ref-news-feature', 'news-motion-feature'],
    ['.ref-news-sidebar-item', 'news-motion-sidebar'], ['.ref-news-ledger-row', 'news-motion-ledger'],
  ],
  '/activities': [
    ['.ref-page-hero-copy', 'activities-motion-hero'], ['.ref-activity-path-card', 'activities-motion-route'], ['.ref-trade-category', 'activities-motion-category'],
    ['.ref-activity-brief-list li', 'activities-motion-brief'], ['.ref-activity-assurance-copy,.ref-activity-markets', 'activities-motion-quality'],
    ['.ref-activity-faq .faq-item', 'activities-motion-faq'],
  ],
  '/process': [
    ['.ref-page-hero-copy', 'process-motion-hero'], ['.ref-process-step', 'process-motion-tab'],
    ['.ref-process-prep-card', 'process-motion-check'],
  ],
  '/projects': [
    ['.ref-page-hero-copy', 'projects-motion-hero'], ['.ref-case-studies-heading', 'projects-motion-feature'],
    ['.ref-case-study-card', 'projects-motion-case'], ['.ref-case-archive-row', 'projects-motion-record'],
  ],
  '/product-detail': [['.ref-page-hero-copy', 'product-detail-motion-hero'], ['.ref-product-detail-body', 'product-detail-motion-body']],
  '/news-detail': [['.ref-page-hero-copy', 'news-detail-motion-hero'], ['main > article', 'news-detail-motion-body']],
}

export default function RouteMotion() {
  const { pathname } = useLocation()
  useEffect(() => {
    const profile = ROUTE_MOTION[pathname] ?? (pathname.startsWith('/products/') ? ROUTE_MOTION['/product-detail'] : pathname.startsWith('/news/') ? ROUTE_MOTION['/news-detail'] : null)
    const main = document.querySelector('#main')
    if (!profile || !main || !('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const targets = []
    const classByNode = new Map()
    for (const [selector, className] of profile) {
      const nodes = [...main.querySelectorAll(selector)]
      nodes.forEach((node, index) => {
        node.classList.add(className)
        node.style.setProperty('--route-motion-delay', `${Math.min(index, 6) * 48}ms`)
        targets.push([node, className])
        classByNode.set(node, className)
      })
    }
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) if (entry.isIntersecting) {
        const className = classByNode.get(entry.target)
        if (className) entry.target.classList.add(`${className}-visible`)
        observer.unobserve(entry.target)
      }
    }, { rootMargin: '0px 0px -7% 0px', threshold: 0.08 })
    targets.forEach(([node]) => observer.observe(node))
    return () => {
      observer.disconnect()
      for (const [node, className] of targets) {
        node.classList.remove(className, `${className}-visible`)
        node.style.removeProperty('--route-motion-delay')
      }
    }
  }, [pathname])
  return null
}

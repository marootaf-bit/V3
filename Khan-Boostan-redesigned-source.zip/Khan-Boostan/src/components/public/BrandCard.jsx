import { publicBrandLabel } from '../../lib.jsx'

export default function BrandCard({ item, L, lang, categories, className = '' }) {
  const title = publicBrandLabel(item, L, lang, categories)
  if (!title) return null
  return <article className={`tw-flex tw-min-h-28 tw-items-start tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 ${className}`.trim()}><span className="tw-grid tw-h-11 tw-w-11 tw-shrink-0 tw-place-items-center tw-rounded-kb tw-bg-kb-paper tw-text-lg tw-font-bold tw-text-kb-blue" aria-hidden="true">{(title[0] || '•').toLocaleUpperCase()}</span><div className="tw-min-w-0"><h3 className="tw-break-words tw-text-sm tw-font-bold tw-leading-5 tw-text-kb-navy">{title}</h3>{item.relation && L(item.relation) && <p className="tw-mt-1 tw-whitespace-pre-line tw-break-words tw-text-xs tw-leading-5 tw-text-kb-body">{L(item.relation)}</p>}{item.description && L(item.description) && <p className="tw-mt-2 tw-whitespace-pre-line tw-break-words tw-text-xs tw-leading-5 tw-text-kb-muted">{L(item.description)}</p>}</div></article>
}

import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'

export default function HomePrinciples({ principles, L, fa }) {
  const visiblePrinciples = principles.filter((item) => L(item.title) || L(item.text))
  const formatIndex = new Intl.NumberFormat(fa ? 'fa-AF' : 'en-US', { minimumIntegerDigits: 2, useGrouping: false })
  if (!visiblePrinciples.length) return null
  return <section id="home-principles" className="tw-scroll-mt-20 tw-bg-kb-paper tw-py-12 sm:tw-py-16" aria-labelledby="home-principles-title"><SiteContainer>
    {visiblePrinciples.length > 0 && <div><div className="tw-mb-6 tw-max-w-3xl"><Eyebrow>{fa ? 'اصول همکاری' : 'WORKING PRINCIPLES'}</Eyebrow><h2 id="home-principles-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{fa ? 'رویکرد همکاری' : 'Approach to cooperation'}</h2></div><div className="tw-grid tw-gap-3 md:tw-grid-cols-3">{visiblePrinciples.map((item, index) => <article className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5" key={`${L(item.title)}-${index}`}><span className="tw-text-xs tw-font-bold tw-tracking-[.1em] tw-text-kb-navy">{formatIndex.format(index + 1)}</span>{L(item.title) && <h3 className="tw-mt-3 tw-text-base tw-font-bold tw-text-kb-navy">{L(item.title)}</h3>}{L(item.text) && <p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{L(item.text)}</p>}</article>)}</div></div>}

  </SiteContainer></section>
}

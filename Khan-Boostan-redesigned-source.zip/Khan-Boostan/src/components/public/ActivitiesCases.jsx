import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function ActivitiesCases({ projects, L, fa, t }) {
  const visibleProjects = projects.filter((item) => L(item.title))
  if (!visibleProjects.length) return null
  return <section className="tw-bg-white tw-py-12 sm:tw-py-16" aria-labelledby="activities-cases-title"><SiteContainer>
    <div className="tw-mb-6 tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between"><div><Eyebrow>{fa ? 'پرونده‌های تجارتی' : 'TRADE CASES'}</Eyebrow><h2 id="activities-cases-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{fa ? 'پرونده‌های مرتبط' : 'Related trade cases'}</h2></div><Link to="/projects" className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('view_all')}<ArrowIcon /></Link></div>
    <div className="tw-grid tw-gap-4 lg:tw-grid-cols-3">{visibleProjects.map((item) => <article className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5" key={item.id}><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-[10px] tw-font-bold tw-text-kb-muted"><span>{L(item.sector)}</span>{item.year && <><span aria-hidden="true">·</span><span>{item.year}</span></>}</div><h3 className="tw-mt-2 tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{L(item.title)}</h3>{L(item.result) && <p className="tw-mt-2 tw-text-xs tw-leading-5 tw-text-kb-body">{L(item.result)}</p>}</article>)}</div>
  </SiteContainer></section>
}

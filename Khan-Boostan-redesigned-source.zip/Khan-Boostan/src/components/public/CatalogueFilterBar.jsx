import SiteContainer from './SiteContainer.jsx'
import ArrowIcon from './ArrowIcon.jsx'

const controlClass = 'tw-min-h-10 tw-w-full tw-min-w-0 tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink tw-outline-none focus:tw-border-kb-blue focus:tw-ring-2 focus:tw-ring-kb-blue/20'

export default function CatalogueFilterBar({
  fa,
  t,
  L,
  query,
  onQueryChange,
  categories,
  categoryId,
  categoryCounts = {},
  onCategoryChange,
  countText,
  sortBy = 'default',
  sortOptions = [],
  onSortChange,
  filters = [],
  onFilterChange,
  activeFilters = [],
  onClearAll,
}) {
  const numberFormat = new Intl.NumberFormat(fa ? 'fa-AF' : 'en-US', { useGrouping: false })
  const advancedFilterCount = activeFilters.filter((filter) => filter.key !== 'q' && filter.key !== 'c').length
  const clearFilter = (key) => onFilterChange?.(key, key === 'c' ? 'all' : '')

  return <SiteContainer>
    <div className="tw-grid tw-gap-3 lg:tw-grid-cols-[minmax(260px,1fr)_220px_auto] lg:tw-items-end">
      <label className="tw-flex tw-min-h-11 tw-w-full tw-min-w-0 tw-items-center tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-kb-muted focus-within:tw-border-kb-blue focus-within:tw-ring-2 focus-within:tw-ring-kb-blue/20">
        <span className="tw-sr-only">{t('search_products')}</span>
        <ArrowIcon kind="search" />
        <input className="tw-min-w-0 tw-flex-1 tw-bg-transparent tw-text-sm tw-text-kb-ink tw-outline-none placeholder:tw-text-kb-muted" type="search" placeholder={t('search_products')} value={query} onChange={(event) => onQueryChange(event.target.value)} />
        {query && <button className="tw-flex tw-h-8 tw-w-8 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-text-lg tw-text-kb-muted hover:tw-bg-kb-paper hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" type="button" onClick={() => onQueryChange('')} aria-label={fa ? 'پاک‌کردن جستجو' : 'Clear search'}>×</button>}
      </label>

      <label className="tw-grid tw-gap-1">
        <span className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{fa ? 'مرتب‌سازی' : 'Sort by'}</span>
        <select className={controlClass} value={sortBy} onChange={(event) => onSortChange(event.target.value)} dir={fa ? 'rtl' : 'ltr'}>
          {sortOptions.map((option) => <option value={option.value} key={option.value}>{option.label}{option.count > 0 ? ` (${numberFormat.format(option.count)})` : ''}</option>)}
        </select>
      </label>

      {filters.length > 0 && <details className="tw-min-w-0 lg:tw-relative">
        <summary className="tw-flex tw-min-h-10 tw-cursor-pointer tw-list-none tw-items-center tw-justify-center tw-gap-2 tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-4 tw-text-sm tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">
          {fa ? 'فیلترهای بیشتر' : 'More filters'}
          {advancedFilterCount > 0 && <span className="tw-rounded-full tw-bg-kb-paper tw-px-2 tw-py-0.5 tw-text-[10px] tw-text-kb-blue">{numberFormat.format(advancedFilterCount)}</span>}
        </summary>
        <div className="tw-mt-3 tw-grid tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 tw-shadow-kb sm:tw-grid-cols-2 lg:tw-absolute lg:tw-end-0 lg:tw-top-full lg:tw-z-40 lg:tw-mt-2 lg:tw-w-[min(720px,calc(100vw-3rem))] lg:tw-grid-cols-3">
          {filters.map((filter) => <label className="tw-grid tw-min-w-0 tw-gap-1" key={filter.key}>
            <span className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{filter.label}</span>
            <select className={controlClass} value={filter.value} onChange={(event) => onFilterChange?.(filter.key, event.target.value)} dir={fa ? 'rtl' : 'ltr'}>
              <option value="">{fa ? 'همه' : 'Any'}</option>
              {filter.options.map((option) => <option value={option.value} key={option.value}>{option.label}{option.count > 0 ? ` (${numberFormat.format(option.count)})` : ''}</option>)}
            </select>
          </label>)}
        </div>
      </details>}
    </div>

    <div className="tw-mt-3 tw-min-w-0">
      <div className="tw-mb-2 tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-2">
        <p className="tw-text-[11px] tw-font-bold tw-text-kb-muted">{fa ? 'دسته‌بندی' : 'CATEGORY'}</p>
        <span className="tw-text-xs tw-font-bold tw-text-kb-muted" role="status" aria-live="polite">{countText}</span>
      </div>
      <div className="tw-min-w-0 tw-overflow-x-auto tw-pb-2 sm:tw-overflow-visible" tabIndex={0} role="group" aria-label={fa ? 'فیلتر دسته‌بندی؛ برای دیدن همهٔ گزینه‌ها پیمایش کنید' : 'Filter by category; scroll to see all options'}>
        <div className="tw-flex tw-w-max tw-gap-2 sm:tw-w-full sm:tw-flex-wrap">
          <button type="button" aria-pressed={categoryId === 'all'} className={`tw-inline-flex tw-min-h-9 tw-shrink-0 tw-items-center tw-gap-2 tw-rounded-full tw-border tw-px-3 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${categoryId === 'all' ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-control tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`} onClick={() => onCategoryChange('all')}>
            <span>{t('all')}</span><span className={`tw-rounded-full tw-px-1.5 tw-py-0.5 tw-text-[10px] ${categoryId === 'all' ? 'tw-bg-white/15 tw-text-white' : 'tw-bg-kb-paper tw-text-kb-muted'}`}>{numberFormat.format(categoryCounts.all ?? 0)}</span>
          </button>
          {categories.map((item) => {
            const active = categoryId === item.id
            const label = L(item.name)
            const count = categoryCounts[item.id] ?? 0
            return <button type="button" key={item.id} aria-pressed={active} className={`tw-inline-flex tw-min-h-9 tw-shrink-0 tw-items-center tw-gap-2 tw-rounded-full tw-border tw-px-3 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${active ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-control tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`} onClick={() => onCategoryChange(item.id)}>
              <span>{label}</span><span className={`tw-rounded-full tw-px-1.5 tw-py-0.5 tw-text-[10px] ${active ? 'tw-bg-white/15 tw-text-white' : 'tw-bg-kb-paper tw-text-kb-muted'}`}>{numberFormat.format(count)}</span>
            </button>
          })}
        </div>
      </div>
    </div>

    {activeFilters.length > 0 && <div className="tw-mt-1 tw-flex tw-flex-wrap tw-items-center tw-gap-2" role="group" aria-label={fa ? 'فیلترهای انتخاب‌شده' : 'Selected filters'}>
      <span className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{fa ? 'فیلترهای فعال:' : 'Active filters:'}</span>
      {activeFilters.map((filter) => <button type="button" key={`${filter.key}-${filter.label}`} onClick={() => clearFilter(filter.key)} aria-label={`${fa ? 'حذف فیلتر' : 'Remove filter'}: ${filter.label}`} className="tw-inline-flex tw-max-w-full tw-min-h-8 tw-items-center tw-gap-2 tw-rounded-full tw-border tw-border-kb-line tw-bg-kb-paper tw-px-3 tw-text-[10px] tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">
        <span className="tw-min-w-0 tw-whitespace-normal tw-break-words tw-text-start">{filter.label}</span><span aria-hidden="true" className="tw-shrink-0 tw-text-sm">×</span>
      </button>)}
      <button type="button" onClick={onClearAll} className="tw-min-h-8 tw-rounded-kb tw-px-2 tw-text-[10px] tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'پاک‌کردن همه' : 'Clear all'}</button>
    </div>}
  </SiteContainer>
}

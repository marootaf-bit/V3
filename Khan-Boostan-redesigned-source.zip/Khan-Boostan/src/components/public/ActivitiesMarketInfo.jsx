import SiteContainer from './SiteContainer.jsx'

export default function ActivitiesMarketInfo({ markets, supplierPrinciples, quality, L, fa }) {
  const visibleMarkets = markets.map((market) => L(market)).filter(Boolean)
  const visiblePrinciples = supplierPrinciples.map((point) => L(point)).filter(Boolean)
  const qualityText = L(quality)
  if (!visibleMarkets.length && !visiblePrinciples.length && !qualityText) return null
  return <section className="tw-bg-kb-paper tw-py-12 sm:tw-py-16" aria-label={fa ? 'بازارها، تأمین‌کنندگان و کیفیت' : 'Markets, suppliers and quality'}><SiteContainer className="tw-grid tw-gap-7 lg:tw-grid-cols-3">
    {visibleMarkets.length > 0 && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-p-6"><h2 className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy">{fa ? 'بازارها' : 'Markets'}</h2><ul className="tw-mt-4 tw-flex tw-flex-wrap tw-gap-2">{visibleMarkets.map((market, index) => <li className="tw-rounded-full tw-bg-kb-paper tw-px-3 tw-py-2 tw-text-xs tw-font-bold tw-text-kb-navy" key={`${market}-${index}`}>{market}</li>)}</ul></div>}
    {visiblePrinciples.length > 0 && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-p-6"><h2 className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy">{fa ? 'اصول همکاری با تأمین‌کنندگان' : 'Supplier principles'}</h2><ul className="tw-mt-4 tw-space-y-3">{visiblePrinciples.map((point, index) => <li className="tw-flex tw-items-start tw-gap-3 tw-text-sm tw-leading-6 tw-text-kb-body" key={`${point}-${index}`}><span className="tw-mt-1 tw-font-bold tw-text-kb-gold" aria-hidden="true">✓</span><span>{point}</span></li>)}</ul></div>}
    {qualityText && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-p-6"><h2 className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy">{fa ? 'کنترل کیفیت' : 'Quality control'}</h2><p className="tw-mt-4 tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{qualityText}</p></div>}
  </SiteContainer></section>
}

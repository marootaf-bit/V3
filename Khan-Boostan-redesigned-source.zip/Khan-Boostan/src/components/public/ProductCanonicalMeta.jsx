import { useEffect } from 'react'

export default function ProductCanonicalMeta({ pathname, lang }) {
  useEffect(() => {
    const url = new URL(pathname, window.location.origin)
    url.searchParams.set('lang', lang === 'en' ? 'en' : 'fa')

    let canonical = document.querySelector('link[rel="canonical"]')
    const hadCanonical = Boolean(canonical)
    const previousCanonical = canonical?.getAttribute('href') ?? ''
    if (!canonical) {
      canonical = document.createElement('link')
      canonical.rel = 'canonical'
      document.head.appendChild(canonical)
    }
    canonical.href = url.href

    let ogUrl = document.querySelector('meta[property="og:url"]')
    const hadOgUrl = Boolean(ogUrl)
    const previousOgUrl = ogUrl?.getAttribute('content') ?? ''
    if (!ogUrl) {
      ogUrl = document.createElement('meta')
      ogUrl.setAttribute('property', 'og:url')
      document.head.appendChild(ogUrl)
    }
    ogUrl.content = url.href

    return () => {
      if (hadCanonical) canonical.setAttribute('href', previousCanonical)
      else canonical.remove()
      if (hadOgUrl) ogUrl.setAttribute('content', previousOgUrl)
      else ogUrl.remove()
    }
  }, [pathname, lang])
  return null
}

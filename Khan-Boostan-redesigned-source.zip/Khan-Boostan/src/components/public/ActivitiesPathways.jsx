import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function ActivitiesPathways({ pathways, fa, t }) {
  return <section className="tw-bg-white tw-py-10 sm:tw-py-12" aria-label={fa ? 'واردات و صادرات' : 'Import and export'}><SiteContainer className="tw-grid tw-gap-4 md:tw-grid-cols-2">
    {pathways.map((item) => <article className="tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white" key={item.key}>
      <Link className="tw-group tw-block tw-aspect-[16/10] tw-overflow-hidden tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={item.to} aria-label={item.label}><img className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.04] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" src={item.image} alt="" loading="lazy" /></Link>
      <div className="tw-p-5"><h2 className="tw-text-xl tw-font-bold tw-leading-7 tw-text-kb-navy"><Link className="hover:tw-text-kb-blue focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={item.to}>{item.label}</Link></h2><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{item.copy}</p><Link className="tw-mt-3 tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={item.to}>{t('view_details')}<ArrowIcon /></Link></div>
    </article>)}
  </SiteContainer></section>
}

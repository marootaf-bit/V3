import { useEffect, useState } from 'react'
import SiteContainer from './SiteContainer.jsx'

export default function HomeQuickNav({ items, fa }) {
  const [activeHref, setActiveHref] = useState(items[0]?.href ?? '')
  const sectionKey = items.map((item) => item.href).join('|')

  useEffect(() => {
    if (!('IntersectionObserver' in window)) return undefined
    const targets = items.map((item) => document.querySelector(item.href)).filter(Boolean)
    if (!targets.length) return undefined
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)
      if (visible[0]) setActiveHref(`#${visible[0].target.id}`)
    }, { rootMargin: '-12% 0px -50% 0px', threshold: 0 })
    targets.forEach((target) => observer.observe(target))
    return () => observer.disconnect()
  }, [sectionKey])

  if (!items.length) return null
  return <section className="tw-sticky tw-top-0 tw-z-30 tw-border-b tw-border-kb-line tw-bg-white/95 tw-py-1 tw-shadow-sm tw-backdrop-blur-sm" aria-label={fa ? 'دسترسی سریع به بخش‌های خانه' : 'Quick links to home sections'}>
    <SiteContainer className="tw-flex tw-min-h-10 tw-items-center tw-gap-2 sm:tw-gap-3">
      <span className="tw-shrink-0 tw-text-[10px] tw-font-bold tw-text-kb-muted sm:tw-text-[11px]">{fa ? 'پرش به:' : 'Jump to:'}</span>
      <nav className="tw-min-w-0 tw-flex-1 tw-overflow-x-auto tw-py-1" tabIndex={0} aria-label={fa ? 'فهرست بخش‌های خانه' : 'Home section index'}>
        <ul className="tw-flex tw-w-max tw-gap-1.5 sm:tw-gap-2">
          {items.map((item) => {
            const active = item.href === activeHref
            return <li key={item.href}><a href={item.href} aria-current={active ? 'location' : undefined} className={`tw-inline-flex tw-min-h-9 tw-items-center tw-whitespace-nowrap tw-rounded-full tw-border tw-px-2.5 tw-text-[11px] tw-font-bold tw-transition-colors motion-reduce:tw-transition-none sm:tw-px-3 sm:tw-text-xs focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${active ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-line tw-bg-kb-paper tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`}>{item.label}</a></li>
          })}
        </ul>
      </nav>
      <a href="#main" className="tw-inline-flex tw-h-9 tw-w-9 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-border tw-border-kb-line tw-bg-white tw-text-base tw-font-bold tw-text-kb-blue hover:tw-border-kb-blue hover:tw-bg-kb-paper focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" aria-label={fa ? 'بازگشت به آغاز صفحهٔ خانه' : 'Back to top of home page'} title={fa ? 'بالا' : 'Back to top'}>↑</a>
    </SiteContainer>
  </section>
}

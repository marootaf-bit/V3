import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function AboutContact({ c, t }) {
  return <section className="tw-bg-kb-navy tw-py-10 tw-text-white sm:tw-py-14" aria-labelledby="about-contact-title"><SiteContainer className="tw-flex tw-flex-col tw-gap-5 md:tw-flex-row md:tw-items-center md:tw-justify-between"><div><Eyebrow tone="gold">{t('contact_t')}</Eyebrow><h2 id="about-contact-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-white sm:tw-text-3xl">{c.contactTitle}</h2><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-white/75">{c.contactText}</p></div><Link to="/contact" className="tw-inline-flex tw-min-h-11 tw-shrink-0 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-gold tw-px-5 tw-text-sm tw-font-bold tw-text-kb-navy hover:tw-bg-white hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-white">{t('nav_contact')}<ArrowIcon /></Link></SiteContainer></section>
}

import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ContactForm from './ContactForm.jsx'
import ContactMethodIcon from './ContactMethodIcon.jsx'
import HomeMedia from './HomeMedia.jsx'

export default function HomeContact({ contact, lang, t, L }) {
  const email = String(L(contact?.email) ?? '').trim()
  const hours = String(L(contact?.hours) ?? '').trim()
  const enquiryFields = lang === 'fa' ? ['نام کالا', 'مشخصات', 'مقدار', 'مقصد'] : ['Goods', 'Specifications', 'Quantity', 'Destination']
  const homeT = (key, fallback) => {
    if (key === 'send') return lang === 'fa' ? 'بازکردن پیش‌نویس ایمیل' : 'Open email draft'
    if (key === 'phone_ph') return lang === 'fa' ? 'شمارهٔ تماس شما' : 'Your phone number'
    return t(key, fallback)
  }

  return <section id="home-contact" className="tw-scroll-mt-20 tw-bg-kb-paper tw-py-12 sm:tw-py-16" aria-labelledby="home-contact-title"><SiteContainer className="tw-grid tw-items-start tw-gap-8 lg:tw-grid-cols-[.85fr_1.15fr] lg:tw-gap-10">
    <div>
      <Eyebrow>{t('nav_contact')}</Eyebrow>
      <h2 id="home-contact-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{lang === 'fa' ? 'برای شروع گفتگوی تجارتی آماده‌ایم' : 'Ready to start a trade conversation'}</h2>
      <p className="tw-mt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{lang === 'fa' ? 'برای درخواست روشن، موارد کوتاه زیر را در پیام خود بگنجانید.' : 'For a clear enquiry, include the short details below in your message.'}</p>
      <ul className="tw-mt-4 tw-flex tw-flex-wrap tw-gap-2" aria-label={lang === 'fa' ? 'معلومات لازم برای درخواست' : 'Details to include in an enquiry'}>{enquiryFields.map((field) => <li className="tw-rounded-full tw-border tw-border-kb-line tw-bg-white tw-px-3 tw-py-1.5 tw-text-xs tw-font-bold tw-text-kb-body" key={field}>{field}</li>)}</ul>
      <ul className="tw-mt-6 tw-grid tw-gap-3">{email && <li className="tw-flex tw-items-start tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><ContactMethodIcon kind="mail" /><span><b className="tw-block tw-text-xs tw-text-kb-muted">{t('email')}</b><a className="tw-mt-1 tw-block tw-break-all tw-text-sm tw-font-bold tw-text-kb-blue hover:tw-underline" href={`mailto:${email}`}>{email}</a></span></li>}{hours && <li className="tw-flex tw-items-start tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><ContactMethodIcon kind="clock" /><span><b className="tw-block tw-text-xs tw-text-kb-muted">{t('hours')}</b><span className="tw-mt-1 tw-block tw-text-sm tw-text-kb-navy">{hours}</span></span></li>}</ul>
      <div className="tw-mt-6 tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line" aria-hidden="true"><HomeMedia className="tw-aspect-[16/9] tw-w-full tw-object-cover" src="/images/trade-detail.webp" alt="" /></div>
    </div>
    <ContactForm email={email} initialKind="contact" lang={lang} t={homeT} variant="home" />
  </SiteContainer></section>
}

import { useState } from 'react'
import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import PrimaryLink from './PrimaryLink.jsx'
import ArrowIcon from './ArrowIcon.jsx'

function highlightedTitle(title, fa) {
  const text = String(title ?? '')
  const phrase = fa ? 'واردات، صادرات' : 'import, export'
  const index = text.toLocaleLowerCase().indexOf(phrase.toLocaleLowerCase())
  if (index < 0) return text

  const end = index + phrase.length
  return <>{text.slice(0, index)}<span className="tw-text-kb-gold">{text.slice(index, end)}</span>{text.slice(end)}</>
}

export default function HomeHero({ image, title, summary, fa }) {
  const [videoFailed, setVideoFailed] = useState(false)
  const overlayDirection = fa ? 'tw-bg-gradient-to-l' : 'tw-bg-gradient-to-r'

  return <section className="tw-relative tw-isolate tw-flex tw-min-h-[360px] tw-items-center tw-overflow-hidden tw-bg-kb-navy sm:tw-min-h-[420px] lg:tw-min-h-[calc(91svh_-_78.26px)]" aria-labelledby="home-hero-title">
    <img className="tw-absolute tw-inset-0 tw-hidden tw-h-full tw-w-full tw-object-cover tw-object-center motion-reduce:tw-block" src={image} alt="" aria-hidden="true" width="1600" height="900" style={videoFailed ? { display: 'block' } : undefined} />
    <video className="tw-absolute tw-inset-0 tw-h-full tw-w-full tw-object-cover tw-object-center motion-reduce:tw-hidden" autoPlay loop muted playsInline preload="metadata" poster={image} aria-hidden="true" tabIndex={-1} onError={() => setVideoFailed(true)}>
      <source src="/videos/hero-loop.mp4" type="video/mp4" onError={() => setVideoFailed(true)} />
    </video>
    <div className={`tw-absolute tw-inset-0 ${overlayDirection} tw-from-kb-navy/95 tw-via-kb-navy/85 tw-to-kb-navy/50`} aria-hidden="true" />
    <SiteContainer className="tw-relative tw-z-10 tw-flex tw-items-center tw-py-12 sm:tw-py-16 lg:tw-py-16">
      <div className="tw-max-w-3xl tw-text-start">
        <h1 id="home-hero-title" className="tw-max-w-3xl tw-break-words tw-font-head tw-text-3xl tw-font-bold tw-leading-[1.15] tw-text-white sm:tw-text-4xl lg:tw-text-5xl 2xl:tw-text-6xl">{highlightedTitle(title, fa)}</h1>
        {summary && <p className="tw-mt-4 tw-max-w-2xl tw-whitespace-pre-line tw-break-words tw-text-base tw-leading-7 tw-text-white/90 sm:tw-mt-5 sm:tw-leading-8 sm:tw-text-lg">{summary}</p>}
        <div className="tw-mt-6 tw-flex tw-flex-wrap tw-gap-3 sm:tw-mt-7">
          <PrimaryLink to="/activities" variant="gold">{fa ? 'مرور فعالیت‌های تجارتی' : 'Explore trade activities'}<ArrowIcon /></PrimaryLink>
          <Link to="/contact" className="tw-inline-flex tw-min-h-11 tw-items-center tw-gap-2 tw-rounded-kb tw-border tw-border-white/60 tw-bg-white/5 tw-px-5 tw-py-2.5 tw-text-sm tw-font-bold tw-text-white tw-transition-colors hover:tw-bg-white hover:tw-text-kb-navy motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{fa ? 'تماس با شرکت' : 'Contact the company'}<ArrowIcon kind="up" /></Link>
        </div>
      </div>
    </SiteContainer>
  </section>
}

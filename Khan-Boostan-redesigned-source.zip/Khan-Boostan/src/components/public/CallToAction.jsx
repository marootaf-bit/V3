import { usePublicDict } from '../../lib.jsx'
import SiteContainer from './SiteContainer.jsx'
import PrimaryLink from './PrimaryLink.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function CallToAction({ showActivitiesLink = false }) {
  const { lang } = usePublicDict()
  const fa = lang !== 'en'
  return <section className="tw-bg-kb-navy tw-py-8 tw-text-white sm:tw-py-11" aria-labelledby="public-cta-title"><SiteContainer className="tw-flex tw-flex-col tw-items-start tw-justify-between tw-gap-5 md:tw-flex-row md:tw-items-center md:tw-gap-6">
    <div className="tw-max-w-2xl"><h2 id="public-cta-title" className="tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-white sm:tw-text-3xl">{fa ? 'برای شروع گفتگوی تجارتی آماده‌ایم' : 'Ready to start a trade conversation'}</h2><p className="tw-mt-3 tw-max-w-xl tw-text-sm tw-leading-7 tw-text-white/80">{fa ? 'کالا، مشخصات، مقدار و مقصد موردنظر را بنویسید تا درخواست بررسی شود.' : 'Share the goods, specifications, quantity and destination so the enquiry can be reviewed.'}</p></div>
    <div className="tw-flex tw-w-full tw-flex-col tw-flex-wrap tw-gap-3 sm:tw-w-auto sm:tw-flex-row">
      {showActivitiesLink && <PrimaryLink to="/activities" variant="outline" className="tw-w-full tw-shrink-0 sm:tw-w-auto">{fa ? 'فعالیت‌های تجارتی' : 'Trade activities'}<ArrowIcon /></PrimaryLink>}
      <PrimaryLink to="/contact" variant="gold" className="tw-w-full tw-shrink-0 sm:tw-w-auto">{fa ? 'تماس با ما' : 'Contact us'}<ArrowIcon /></PrimaryLink>
    </div>
  </SiteContainer></section>
}

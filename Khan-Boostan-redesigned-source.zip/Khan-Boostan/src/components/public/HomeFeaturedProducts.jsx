import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import { publicItemName, publicItemSummary, publicSlug } from '../../lib.jsx'

export default function HomeFeaturedProducts({ products, categoryName, L, lang, fa, t }) {
  if (!products.length) return null
  return <section className="tw-bg-white tw-py-14 sm:tw-py-16" aria-labelledby="home-products-title"><SiteContainer>
    <div className="tw-mb-7 tw-flex tw-flex-col tw-gap-4 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between"><div><Eyebrow>{fa ? 'محصولات' : 'PRODUCTS'}</Eyebrow><h2 id="home-products-title" className="tw-mt-2 tw-font-head tw-text-3xl tw-font-bold tw-text-kb-navy sm:tw-text-4xl">{fa ? 'محصولات منتخب' : 'Selected products'}</h2></div><Link to="/products" className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'مشاهدهٔ همه' : 'View all'}<ArrowIcon /></Link></div>
    <div className="tw-grid tw-gap-4 sm:tw-grid-cols-2 lg:tw-grid-cols-4">
      {products.map((product) => <article className="tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-transition-shadow hover:tw-shadow-kb motion-reduce:tw-transition-none" key={product.id}>
        <Link to={`/products/${publicSlug(product.id)}`} className="tw-group tw-relative tw-block tw-aspect-[4/3] tw-overflow-hidden tw-bg-kb-paper focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><img className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.03] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" src={product.image} alt={publicItemName(L(product.name))} loading="lazy" /><span className="tw-absolute tw-bottom-3 tw-start-3 tw-rounded-full tw-bg-kb-navy/90 tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-white">{t(`status_${product.status}`, fa ? 'قابل استعلام' : 'ON REQUEST')}</span></Link>
        <div className="tw-p-4"><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2"><small className="tw-text-[11px] tw-font-bold tw-text-kb-muted">{categoryName(product.category)}</small>{product.featured && <span className="tw-rounded-full tw-bg-kb-gold tw-px-2 tw-py-0.5 tw-text-[9px] tw-font-bold tw-text-kb-navy">{t('featured_badge')}</span>}</div><h3 className="tw-mt-2 tw-break-words tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy"><Link className="hover:tw-text-kb-blue focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={`/products/${publicSlug(product.id)}`}>{publicItemName(L(product.name))}</Link></h3>{publicItemSummary(product, L, lang) && <p className="tw-mt-2 tw-whitespace-pre-line tw-break-words tw-text-xs tw-leading-5 tw-text-kb-body">{publicItemSummary(product, L, lang)}</p>}<Link className="tw-mt-3 tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={`/products/${publicSlug(product.id)}`}>{t('view_details')}<ArrowIcon /></Link></div>
      </article>)}
    </div>
  </SiteContainer></section>
}

export default function Eyebrow({ children, className = '', tone = 'default' }) {
  const toneClass = {
    default: 'tw-text-kb-navy',
    gold: 'tw-text-kb-gold',
    light: 'tw-text-white/90',
  }[tone] ?? 'tw-text-kb-navy'

  return <span className={`tw-inline-flex tw-items-center tw-gap-2 tw-text-[11px] tw-font-bold tw-uppercase tw-tracking-[.14em] ${toneClass} ${className}`.trim()}>{children}</span>
}

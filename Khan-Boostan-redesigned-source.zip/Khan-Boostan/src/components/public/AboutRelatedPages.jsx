import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import CopyPageLink from './CopyPageLink.jsx'
import ArrowIcon from './ArrowIcon.jsx'

export default function AboutRelatedPages({ c, lang }) {
  const items = [
    { to: '/partners', title: c.partnersTitle, text: c.partnersText },
    { to: '/careers', title: c.careersTitle, text: c.careersText },
  ]
  return <section id="about-related-pages" className="tw-scroll-mt-24 tw-bg-kb-paper tw-py-8 sm:tw-py-10 print:tw-bg-white" aria-labelledby="about-related-title"><SiteContainer>
    <div className="tw-flex tw-items-center tw-gap-2"><h2 id="about-related-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{c.relatedTitle}</h2><CopyPageLink id="about-related-pages" lang={lang} sectionLabel={c.relatedTitle} /></div>
    <div className="tw-mt-4 tw-grid tw-gap-3 sm:tw-grid-cols-2">
      {items.map((item) => <article key={item.to} className="tw-flex tw-h-full tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-p-5 print:tw-break-inside-avoid"><h3 className="tw-text-base tw-font-bold tw-text-kb-navy">{item.title}</h3><p className="tw-mt-2 tw-flex-1 tw-text-sm tw-leading-6 tw-text-kb-body">{item.text}</p><Link to={item.to} className="tw-mt-3 tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-self-start tw-rounded-kb tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{c.openPage}<ArrowIcon kind="up" size={14} /></Link></article>)}
    </div>
  </SiteContainer></section>
}

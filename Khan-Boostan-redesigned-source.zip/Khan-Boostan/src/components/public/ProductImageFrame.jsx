import { useState } from 'react'

function CategoryGlyph({ categoryId }) {
  const shared = { width: 54, height: 54, viewBox: '0 0 48 48', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true' }
  if (categoryId === 'food' || categoryId === 'agri') return <svg {...shared}><path d="M11 33c1-13 9-22 26-24-1 17-9 25-22 27" /><path d="M9 40c8-10 16-17 28-26" /><path d="M10 40h28" /></svg>
  if (categoryId === 'construction') return <svg {...shared}><path d="m7 17 17-10 17 10v20L24 47 7 37z" /><path d="m7 17 17 10 17-10M24 27v20" /><path d="M16 12v10m16-10v10" /></svg>
  if (categoryId === 'energy') return <svg {...shared}><path d="M27 5 12 27h11l-2 16 15-23H25z" /></svg>
  if (categoryId === 'household') return <svg {...shared}><path d="m6 22 18-15 18 15" /><path d="M11 20v21h26V20M20 41V28h9v13" /></svg>
  if (categoryId === 'textile') return <svg {...shared}><path d="M8 11h32M8 19h32M8 27h32M8 35h32" /><path d="m14 8 20 30M28 8 8 38" /></svg>
  if (categoryId === 'machinery' || categoryId === 'spare') return <svg {...shared}><circle cx="24" cy="24" r="7" /><path d="M20 5h8l2 6 5 2 5-3 5 7-4 5 1 5 5 4-4 8-7-1-4 3-1 6h-8l-2-6-5-2-5 3-5-7 4-5-1-5-5-4 4-8 7 1 4-3z" /></svg>
  return <svg {...shared}><path d="m6 17 18-10 18 10v21L24 46 6 38z" /><path d="m6 17 18 10 18-10M24 27v19" /></svg>
}

function Fallback({ alt, categoryId, categoryName, fa, missing = false }) {
  const label = missing
    ? (fa ? `تصویر ${alt} بارگذاری نشد` : `Image did not load for ${alt}`)
    : (fa ? `تصویر ${alt} در دستهٔ ${categoryName || 'کالا'}` : `${alt}, ${categoryName || 'product'} image`)
  return <span className="tw-grid tw-h-full tw-w-full tw-place-items-center tw-bg-kb-paper tw-p-5 tw-text-center" role="img" aria-label={label}>
    <span className="tw-flex tw-flex-col tw-items-center tw-gap-3">
      <span className="tw-grid tw-h-20 tw-w-20 tw-place-items-center tw-rounded-full tw-bg-white tw-text-kb-blue tw-shadow-kb"><CategoryGlyph categoryId={categoryId} /></span>
      <b className="tw-block tw-text-sm tw-leading-5 tw-text-kb-navy">{alt}</b>
      {!missing && categoryName && <small className="tw-text-[10px] tw-leading-4 tw-text-kb-muted">{categoryName}</small>}
    </span>
  </span>
}

export default function ProductImageFrame({ src, alt, categoryId, categoryName, sharedImage = false, fa = false, onImageError }) {
  const [failedSource, setFailedSource] = useState('')
  if (!src || failedSource === src) return <Fallback alt={alt} categoryId={categoryId} categoryName={categoryName} fa={fa} missing={!src || failedSource === src} />
  if (sharedImage) return <Fallback alt={alt} categoryId={categoryId} categoryName={categoryName} fa={fa} />
  return <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => { setFailedSource(src); onImageError?.(src) }} className="tw-h-full tw-w-full tw-object-cover" />
}

import SiteContainer from './SiteContainer.jsx'

function countryCode(market) {
  const en = String(market?.en ?? '').toLocaleLowerCase()
  const fa = String(market?.fa ?? '')
  if (en.includes('united arab') || fa.includes('امارات')) return 'ae'
  if (en.includes('türkiye') || en.includes('turk') || fa.includes('ترکیه')) return 'tr'
  if (en.includes('china') || fa.includes('چین')) return 'cn'
  if (en.includes('uzbek') || fa.includes('ازبکستان')) return 'uz'
  if (en.includes('pakistan') || fa.includes('پاکستان')) return 'pk'
  if (en.includes('india') || fa.includes('هند')) return 'in'
  return ''
}

function CountryFlag({ code }) {
  if (!code) return null
  const className = 'tw-h-14 tw-w-[88px] tw-shrink-0 tw-rounded-[4px] tw-border tw-border-white/40 tw-shadow-md sm:tw-h-16 sm:tw-w-[100px]'
  return <svg className={className} viewBox="0 0 28 18" aria-hidden="true" focusable="false">
    {code === 'ae' && <>
      <rect width="28" height="18" fill="#fff" />
      <rect x="7" width="21" height="6" fill="#00732f" />
      <rect x="7" y="12" width="21" height="6" fill="#111" />
      <rect width="7" height="18" fill="#ce1126" />
    </>}
    {code === 'tr' && <>
      <rect width="28" height="18" fill="#e30a17" />
      <circle cx="10" cy="9" r="5" fill="#fff" />
      <circle cx="12.4" cy="7.7" r="4.2" fill="#e30a17" />
      <path d="m20 4.4 1.25 3.05 3.25.18-2.5 2.08.9 3.15L20 11.1l-2.82 1.76.9-3.15-2.5-2.08 3.25-.18z" fill="#fff" />
    </>}
    {code === 'cn' && <>
      <rect width="28" height="18" fill="#de2910" />
      <path d="m5.4 2.1.9 2.5 2.65.05-2.1 1.55.78 2.55L5.4 7.2 3.2 8.75l.8-2.55L1.9 4.65l2.65-.05z" fill="#ffde00" />
      <path d="m11.7 2.2.38.92 1 .1-.75.63.22.98-.85-.52-.84.52.22-.98-.75-.63 1-.1zM14.4 4.35l.38.92 1 .1-.75.63.22.98-.85-.52-.84.52.22-.98-.75-.63 1-.1zM14.2 7.5l.38.92 1 .1-.75.63.22.98-.85-.52-.84.52.22-.98-.75-.63 1-.1zM11.2 9.1l.38.92 1 .1-.75.63.22.98-.85-.52-.84.52.22-.98-.75-.63 1-.1z" fill="#ffde00" />
    </>}
    {code === 'uz' && <>
      <rect width="28" height="5.7" fill="#1eb5e0" />
      <rect y="5.7" width="28" height="0.7" fill="#ce1126" />
      <rect y="6.4" width="28" height="5.2" fill="#fff" />
      <rect y="11.6" width="28" height="0.7" fill="#ce1126" />
      <rect y="12.3" width="28" height="5.7" fill="#1eb53a" />
      <circle cx="5.1" cy="3" r="2.2" fill="#fff" />
      <circle cx="5.8" cy="2.5" r="1.8" fill="#1eb5e0" />
      <g fill="#fff">
        <circle cx="10" cy="1.8" r="0.55" /><circle cx="12" cy="1.8" r="0.55" /><circle cx="14" cy="1.8" r="0.55" /><circle cx="16" cy="1.8" r="0.55" />
        <circle cx="10" cy="3.7" r="0.55" /><circle cx="12" cy="3.7" r="0.55" /><circle cx="14" cy="3.7" r="0.55" /><circle cx="16" cy="3.7" r="0.55" />
        <circle cx="10" cy="5.2" r="0.55" /><circle cx="12" cy="5.2" r="0.55" /><circle cx="14" cy="5.2" r="0.55" /><circle cx="16" cy="5.2" r="0.55" />
      </g>
    </>}
    {code === 'pk' && <>
      <rect width="28" height="18" fill="#01411c" />
      <rect width="6" height="18" fill="#fff" />
      <circle cx="16" cy="9" r="5" fill="#fff" />
      <circle cx="18.1" cy="7.7" r="4.1" fill="#01411c" />
      <path d="m21.8 4.2.95 2.1 2.25.16-1.72 1.42.6 2.15-2.08-1.2-1.9 1.3.58-2.2-1.73-1.4 2.23-.15z" fill="#fff" />
    </>}
    {code === 'in' && <>
      <rect width="28" height="6" fill="#ff9933" />
      <rect y="6" width="28" height="6" fill="#fff" />
      <rect y="12" width="28" height="6" fill="#138808" />
      <circle cx="14" cy="9" r="3.1" fill="none" stroke="#000080" strokeWidth="0.8" />
      <path d="M14 5.9v6.2M10.9 9h6.2m-5.3-2.2 4.4 4.4m0-4.4-4.4 4.4" stroke="#000080" strokeWidth="0.45" />
      <circle cx="14" cy="9" r="0.55" fill="#000080" />
    </>}
  </svg>
}

function StatIcon({ name }) {
  const shared = { width: 52, height: 52, viewBox: '0 0 48 48', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true' }
  if (name === 'users') return <svg {...shared}><circle cx="18" cy="16" r="6" /><path d="M6 39v-4a9 9 0 0 1 9-9h6a9 9 0 0 1 9 9v4" /><path d="M31 11a6 6 0 0 1 0 11m2 4a9 9 0 0 1 8 9v4" /></svg>
  if (name === 'warehouse') return <svg {...shared}><path d="m4 18 20-12 20 12v24H4z" /><path d="M11 42V23h26v19M19 42V29h10v13M10 18h28" /></svg>
  return <svg {...shared}><path d="M24 5 39 11v11c0 10-6 17-15 22C15 39 9 32 9 22V11z" /><path d="m17 24 5 5 10-11" /></svg>
}

export default function HomeSnapshot({ home, L, fa, lang }) {
  const markets = (home?.markets ?? []).filter((market) => Boolean(L(market)))
  const highlights = (home?.highlights ?? []).filter((item) => Boolean(L(item.value)) && Boolean(L(item.label))).slice(0, 3)
  if (!markets.length && !highlights.length) return null

  const bannerTitle = L(home?.bannerTitle, fa ? 'مورد اعتماد شرکت‌ها در سراسر جهان' : 'Trusted by businesses worldwide')
  const bannerImage = home?.bannerImage || '/images/trade-port.webp'

  return <>
    {highlights.length > 0 && <section className="tw-relative tw-isolate tw-overflow-hidden tw-bg-kb-navy tw-py-7 sm:tw-py-9 lg:tw-min-h-[22svh]" aria-labelledby="home-company-info-title">
      <div className="tw-pointer-events-none tw-absolute tw-inset-0 tw-bg-cover tw-bg-center" style={{ backgroundImage: `url("${bannerImage}")` }} aria-hidden="true" />
      <div className={`tw-pointer-events-none tw-absolute tw-inset-0 ${fa ? 'tw-bg-gradient-to-l' : 'tw-bg-gradient-to-r'} tw-from-kb-navy/90 tw-via-kb-navy/85 tw-to-kb-navy/80`} aria-hidden="true" />
      <SiteContainer className="tw-relative tw-z-10 tw-w-full">
        <div className="tw-grid tw-grid-cols-1 tw-items-center tw-gap-x-5 tw-gap-y-4 md:tw-grid-cols-3 lg:tw-grid-cols-[minmax(0,1.25fr)_repeat(3,minmax(0,1fr))] lg:tw-gap-x-4" dir={fa ? 'rtl' : 'ltr'}>
          <h2 id="home-company-info-title" className="tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-white sm:tw-text-3xl md:tw-col-span-3 lg:tw-col-span-1">{bannerTitle}</h2>
          {highlights.map((item) => <div className="tw-flex tw-min-h-16 tw-items-center tw-gap-4 tw-border-t tw-border-white/25 tw-pt-4 lg:tw-min-h-20 lg:tw-border-s-2 lg:tw-border-t-0 lg:tw-border-s-[#45D7F3]/75 lg:tw-pt-0 lg:tw-ps-5" key={item.id}>
            <span className="tw-shrink-0 tw-text-white"><StatIcon name={item.icon} /></span>
            <span className="tw-min-w-0"><strong className="tw-block tw-font-head tw-text-3xl tw-font-bold tw-leading-none tw-text-white sm:tw-text-4xl">{L(item.value)}</strong><span className="tw-mt-2 tw-block tw-text-sm tw-font-medium tw-leading-5 tw-text-white/90 sm:tw-text-base">{L(item.label)}</span></span>
          </div>)}
        </div>
      </SiteContainer>
    </section>}
    {markets.length > 0 && <section className="tw-relative tw-isolate tw-bg-kb-navy tw-py-6 sm:tw-py-8" aria-labelledby="home-markets-title">
      <SiteContainer className="tw-w-full">
        <div className="tw-home-market-viewport tw-mx-auto tw-w-full tw-max-w-5xl tw-overflow-hidden tw-py-2 tw-text-white" dir="ltr">
          <h2 id="home-markets-title" className="tw-text-center tw-font-head tw-text-xl tw-font-bold tw-text-white sm:tw-text-2xl" dir={fa ? 'rtl' : 'ltr'}>{fa ? 'کشورهایی که در آن‌ها کالا جابه‌جا می‌کنیم' : 'Countries where we move goods'}</h2>
          <div className="tw-home-market-marquee tw-mt-4 tw-flex tw-w-max tw-items-center" dir="ltr">
            {[0, 1].map((copyIndex) => <ul className="tw-flex tw-w-max tw-shrink-0 tw-list-none tw-items-center tw-gap-4 tw-pe-4" key={copyIndex} dir={fa ? 'rtl' : 'ltr'} aria-label={copyIndex === 0 ? (fa ? 'فهرست متحرک کشورها' : 'Moving list of countries') : undefined} aria-hidden={copyIndex > 0}>
              {markets.map((market, index) => <li className="tw-inline-flex tw-h-24 tw-w-36 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-kb-lg tw-border tw-border-white/25 tw-bg-white/10 tw-shadow-kb" key={`${copyIndex}-${index}-${L(market)}`}>
                <CountryFlag code={countryCode(market)} />
                <span className="tw-sr-only">{L(market)}</span>
              </li>)}
            </ul>)}
          </div>
        </div>
      </SiteContainer>
    </section>}
  </>
}

import { Link, NavLink, useLocation } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import { useLang, useContent } from '../lib/store.jsx'
import { CountUp } from '../lib/motion.jsx'

/* ---------------- icons ---------------- */
const I = {
  arrow: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>,
  chev: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m15 18-6-6 6-6" /></svg>,
  down: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m6 9 6 6 6-6" /></svg>,
  search: (p) => <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.34-4.34" /></svg>,
  pin: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0" /><circle cx="12" cy="10" r="3" /></svg>,
  phone: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2.4 2.4 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2.4 2.4 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92" /></svg>,
  mail: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect width="20" height="16" x="2" y="4" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></svg>,
  clock: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>,
  menu: (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><line x1="4" x2="20" y1="6" y2="6" /><line x1="4" x2="20" y1="12" y2="12" /><line x1="4" x2="20" y1="18" y2="18" /></svg>,
  x: (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>,
  doc: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /><path d="M14 2v4a2 2 0 0 0 2 2h4" /></svg>,
  box: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" /><path d="m3.3 7 8.7 5 8.7-5" /><path d="M12 22V12" /></svg>,
  globe: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="10" /><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" /><path d="M2 12h20" /></svg>,
  ship: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1" /><path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76" /><path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6" /><path d="M12 10v4" /><path d="M12 2v3" /></svg>,
  shield: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1.8 1.8 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /></svg>,
  users: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>,
  chart: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 3v16a2 2 0 0 0 2 2h16" /><path d="M7 13h4v6H7z" /><path d="M13 9h4v10h-4z" /></svg>,
  chat: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg>,
  edit: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" /></svg>,
  trash: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 6h18" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" /><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>,
  plus: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 12h14" /><path d="M12 5v14" /></svg>,
  up: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m18 15-6-6-6 6" /></svg>,
  logout: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" x2="9" y1="12" y2="12" /></svg>,
  grid: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect width="7" height="7" x="3" y="3" rx="1" /><rect width="7" height="7" x="14" y="3" rx="1" /><rect width="7" height="7" x="14" y="14" rx="1" /><rect width="7" height="7" x="3" y="14" rx="1" /></svg>,
  gear: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" /><circle cx="12" cy="12" r="3" /></svg>,
  inbox: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polyline points="22 12 16 12 14 15 10 15 8 12 2 12" /><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" /></svg>,
  play: (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M8 5.14v13.72a1 1 0 0 0 1.5.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86a1 1 0 0 0-1.5.86z" /></svg>,
  ext: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg>,
  copy: (p) => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect width="14" height="14" x="8" y="8" rx="2" /><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" /></svg>,
  check: (p) => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M20 6 9 17l-5-5" /></svg>,
  fb: (p) => <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.45 2.89h-2.33v6.99A10 10 0 0 0 22 12" /></svg>,
  ig: (p) => <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect width="20" height="20" x="2" y="2" rx="5" /><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37" /><line x1="17.5" x2="17.51" y1="6.5" y2="6.5" /></svg>,
  li: (p) => <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12M7.12 20.45H3.56V9h3.56zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.72C24 .77 23.2 0 22.22 0" /></svg>,
  yt: (p) => <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81M9.55 15.57V8.43L15.82 12z" /></svg>,
  tw: (p) => <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M18.24 2.25h3.31l-7.23 8.26 8.5 11.24h-6.66l-5.21-6.82-5.97 6.82H1.67l7.73-8.84L1.25 2.25h6.83l4.71 6.23zm-1.16 17.52h1.83L7.08 4.13H5.12z" /></svg>,
  wa: (p) => <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.08-.3-.15-1.26-.47-2.4-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.53.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.5 0 1.46 1.07 2.88 1.22 3.08.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.7.63.71.22 1.36.2 1.87.11.57-.08 1.76-.72 2-1.41.25-.7.25-1.29.18-1.42-.08-.12-.28-.2-.57-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88a9.83 9.83 0 0 1 9.88 9.88c0 5.45-4.44 9.89-9.88 9.89M20.47 3.5A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.9c0 2.1.55 4.14 1.59 5.94L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.68 1.45c6.55 0 11.89-5.34 11.89-11.9 0-3.18-1.24-6.16-3.46-8.4" /></svg>
}
export { I }

/* ---------------- social helpers ---------------- */
const SOCIALS = [
  ['facebook', 'fb', 'Facebook'], ['instagram', 'ig', 'Instagram'], ['linkedin', 'li', 'LinkedIn'],
  ['twitter', 'tw', 'X'], ['youtube', 'yt', 'YouTube']
]
export function SocialRow({ ct, light = false }) {
  const items = SOCIALS.filter(([k]) => (ct?.[k] ?? '').trim())
  if (!items.length) return null
  return (
    <div className="flex items-center gap-2">
      {items.map(([k, icon, name]) => (
        <a key={k} href={ct[k]} target="_blank" rel="noopener noreferrer" aria-label={name}
          className={`grid h-9 w-9 place-items-center rounded-full border transition-colors ${light ? 'border-white/15 text-mist-200 hover:border-brass hover:text-brass' : 'border-mist-300 text-[#5A6773] hover:border-brass hover:text-brass-dark'}`}>
          {I[icon]({})}
        </a>
      ))}
    </div>
  )
}

/* ---------------- brand ---------------- */
export function Brand({ light = false }) {
  const { L } = useLang()
  const { settings } = useContent()
  const c = settings.company ?? {}
  return (
    <Link to="/" className="flex items-center gap-3 no-underline" aria-label={L(c.name, 'Khan Boostan')}>
      <img src="/images/logo.png" alt="" className={`h-11 w-11 shrink-0 rounded-full object-cover ${light ? 'ring-2 ring-white/60' : 'ring-1 ring-black/5'}`} />
      <span className="leading-tight">
        <span className={`block font-head text-[15px] font-bold ${light ? 'text-white' : 'text-ink'}`}>{L(c.name, 'Khan Boostan')}</span>
        <span className={`block text-[11.5px] ${light ? 'text-mist-300' : 'text-[#64707C]'}`}>{L(c.tagline, 'Import & Export')}</span>
      </span>
    </Link>
  )
}

/* ---------------- header (utility bar + dropdown nav) ---------------- */
export function Header() {
  const { t, L, lang, setLang } = useLang()
  const { data, settings } = useContent()
  const ct = settings.contact ?? {}
  const sec = settings.sections ?? {}
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const loc = useLocation()
  const solid = scrolled || open || loc.pathname === '/'
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 8)
    window.addEventListener('scroll', f, { passive: true }); f()
    return () => window.removeEventListener('scroll', f)
  }, [])
  useEffect(() => setOpen(false), [loc.pathname, loc.hash])

  const nav = useMemo(() => {
    const has = (xs) => (xs?.length ?? 0) > 0
    const aboutItems = [
      ['/about', t('nav_intro')],
      ...(sec.showTeam !== false && has(data?.team) ? [['/about#team', t('nav_team')]] : []),
      ...(sec.showPartners !== false && (has(data?.partners) || has(data?.brands)) ? [['/partners', t('nav_partners')]] : []),
      ...(sec.showCareers !== false ? [['/careers', t('nav_careers')]] : [])
    ]
    const actItems = [
      ['/activities', t('nav_overview')],
      ['/activities#import', L(settings.pages?.import?.title, 'Import')],
      ['/activities#export', L(settings.pages?.export?.title, 'Export')],
      ...(sec.showProjects !== false && has(data?.projects) ? [['/activities#projects', t('nav_projects')]] : [])
    ]
    const newsItems = [
      ['/news', t('nav_news_events')],
      ...(sec.showGallery !== false && has(data?.gallery) ? [['/news#gallery', t('nav_gallery')]] : []),
      ...(sec.showGallery !== false && (data?.gallery ?? []).some((g) => g.video) ? [['/gallery#videos', t('nav_videos')]] : [])
    ]
    return [
      { to: '/', label: t('nav_home'), items: null, match: ['/'] },
      { to: '/about', label: t('nav_about'), items: null, match: ['/about', '/careers', '/partners'] },
      { to: '/activities', label: t('nav_activities'), items: null, match: ['/activities', '/import', '/export', '/process', '/projects'] },
      { to: '/products', label: t('nav_products'), items: null, match: ['/products'] },
      { to: '/news', label: t('nav_news'), items: null, match: ['/news', '/gallery'] },
      { to: '/contact', label: t('nav_contact'), items: null, match: ['/contact'] }
    ]
  }, [data, settings, t, L, lang])

  const isGroupActive = (g) => g.match.some((m) => loc.pathname === m || loc.pathname === m + '/')

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${solid ? 'border-b border-mist-200 bg-white/95 backdrop-blur-md' : 'border-b border-transparent bg-gradient-to-b from-ink/78 via-ink/36 to-transparent'}`}>
      {/* main bar */}
      <div>
        <div className="wrap flex min-h-[64px] items-center justify-between gap-4">
          <Brand light={!solid} />
          <nav className="hidden items-center gap-0.5 lg:flex" aria-label="main">
            {nav.map((g) => (
              <div key={g.to} className="group relative">
                <NavLink to={g.to}
                  className={({ isActive }) =>
                    `relative inline-flex min-h-[44px] items-center gap-1.5 whitespace-nowrap px-3 text-[13px] font-bold transition-colors ${isActive || isGroupActive(g) ? (solid ? 'text-ink' : 'text-white') : (solid ? 'text-[#5A6773] hover:text-ink' : 'text-mist-200 hover:text-white')}`}>
                  {({ isActive }) => (<>
                    {g.label}
                    {(isActive || isGroupActive(g)) && <span className="absolute inset-x-3.5 -bottom-[2px] h-[2px] rounded-full bg-brand" aria-hidden="true" />}
                    {g.items && <I.down className="h-3.5 w-3.5 opacity-60 transition-transform duration-200 group-hover:rotate-180" />}
                  </>)}
                </NavLink>
                {g.items && (
                  <div className="invisible absolute start-0 top-full z-50 pt-2 opacity-0 transition-all duration-150 group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                    <div className="w-60 rounded-xl border border-mist-200 bg-white p-2 shadow-[0_24px_50px_-24px_rgba(42,47,53,.4)]">
                      {g.items.map(([to, label]) => (
                        <Link key={to} to={to}
                          className={`block rounded-lg px-3 py-2.5 text-[13.5px] font-semibold no-underline transition-colors ${loc.pathname + loc.hash === to || loc.pathname === to ? 'bg-mist-100 text-ink' : 'text-[#5A6773] hover:bg-mist-50 hover:text-ink'}`}>
                          {label}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>
          <div className="flex items-center gap-2.5">
            <div className="hidden items-center gap-1 md:flex" role="group" aria-label="language">
              <button onClick={() => setLang('fa')} className={`hit44 min-h-[32px] px-2 text-[13px] font-bold transition-colors ${lang === 'fa' ? (solid ? 'text-brass-dark' : 'text-brass') : (solid ? 'text-[#64707C] hover:text-ink' : 'text-mist-200 hover:text-white')}`}>دری</button>
              <span className={`h-3 w-px ${solid ? 'bg-mist-300' : 'bg-white/30'}`} />
              <button onClick={() => setLang('en')} className={`hit44 min-h-[32px] px-2 text-[13px] font-bold transition-colors ${lang === 'en' ? (solid ? 'text-brand-dark' : 'text-[#9CCBEE]') : (solid ? 'text-[#64707C] hover:text-ink' : 'text-mist-200 hover:text-white')}`}>EN</button>
            </div>
            <Link to="/contact" className="btn-coral btn-sm hidden sm:inline-flex">{t('cooperate')}</Link>
            <button className={`rounded-[8px] border p-2 lg:hidden ${solid ? 'border-mist-300 text-ink' : 'border-white/30 text-white'}`} onClick={() => setOpen(!open)} aria-label="menu" aria-expanded={open}>
              {open ? <I.x /> : <I.menu />}
            </button>
          </div>
        </div>
        {open && (
          <nav className="wrap max-h-[70vh] overflow-y-auto border-t border-mist-200 bg-white pb-5 lg:hidden" aria-label="mobile">
            {nav.map((g) => (
              <div key={g.to} className="border-b border-mist-100 py-1.5 last:border-0">
                <NavLink to={g.to} className={({ isActive }) => `block min-h-[44px] py-2.5 text-[15px] font-bold ${isActive || isGroupActive(g) ? 'text-ink' : 'text-[#5A6773]'}`}>{g.label}</NavLink>
                {g.items && (
                  <div className="grid ps-4">
                    {g.items.filter(([to]) => to !== g.to).map(([to, label]) => (
                      <Link key={to} to={to} className="block min-h-[38px] py-1.5 text-[13.5px] text-[#6B7278] no-underline">{label}</Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="mt-3 flex items-center justify-between gap-3 pt-2">
              <SocialRow ct={ct} />
              <div className="flex items-center gap-1">
                <button onClick={() => setLang('fa')} className={`hit44 min-h-[32px] px-2 text-[13px] font-bold ${lang === 'fa' ? 'text-brand-dark' : 'text-[#64707C]'}`}>دری</button>
                <span className="h-3 w-px bg-mist-300" />
                <button onClick={() => setLang('en')} className={`hit44 min-h-[32px] px-2 text-[13px] font-bold ${lang === 'en' ? 'text-brand-dark' : 'text-[#64707C]'}`}>EN</button>
              </div>
              <Link to="/downloads" className="text-[13.5px] font-bold text-brass-dark">{t('nav_downloads')}</Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}

/* ---------------- page head (dark panel + photo + glass side card) ---------------- */
const ROUTE_IMAGES = [
  ['/about', '/images/about-office.webp'],
  ['/activities', '/images/trade-port.webp'],
  ['/import', '/images/trade-warehouse.webp'],
  ['/export', '/images/trade-cargo.webp'],
  ['/process', '/images/trade-highway.webp'],
  ['/products', '/images/gallery-loading.webp'],
  ['/news', '/images/news-exhibition.webp'],
  ['/gallery', '/images/gallery-office.webp'],
  ['/partners', '/images/trade-documents.webp'],
  ['/projects', '/images/project-construction.webp'],
  ['/downloads', '/images/trade-documents.webp'],
  ['/careers', '/images/gallery-office.webp'],
  ['/contact', '/images/about-office.webp'],
  ['/privacy', '/images/trade-detail.webp'],
  ['/terms', '/images/trade-detail.webp']
]

function FactLabel({ f }) { const { L } = useLang(); return <>{L(f.label)}</> }
function FactValue({ f }) { const { L } = useLang(); return <>{L(f.value)}</> }

export function PageHead({ crumb, title, desc, image, crumbGroup, children }) {
  const { t } = useLang()
  const { data } = useContent()
  const loc = useLocation()
  const facts = (data?.facts ?? []).slice(0, 3)
  const src = image
    ?? ROUTE_IMAGES.find(([p]) => loc.pathname === p || loc.pathname === p + '/')?.[1]
    ?? '/images/trade-detail.webp'
  return (
    <section className="band-dark relative flex min-h-[46vh] flex-col justify-end overflow-hidden">
      <img src={src} alt="" aria-hidden="true" fetchPriority="high"
        className="kenburns absolute inset-0 h-full w-full object-cover opacity-35" style={{ objectPosition: 'center 42%' }} />
      <span className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink/66 via-ink/42 to-ink/92" aria-hidden="true" />
      <div className="wrap relative z-[2] pb-12 pt-32 md:pb-16 md:pt-36">
        <nav className="mb-5 flex flex-wrap items-center gap-2 text-[12.5px]" aria-label="breadcrumb">
          <Link to="/" className="inline-flex min-h-[32px] items-center text-mist-300 hover:text-white">{t('home')}</Link>
          {crumbGroup && (<><I.chev className="rotate-180 opacity-50 rtl:rotate-0" /><span className="text-mist-300">{crumbGroup}</span></>)}
          {crumb && (<><I.chev className="rotate-180 opacity-50 rtl:rotate-0" /><span className="font-bold text-brass">{crumb}</span></>)}
        </nav>
        <h1 className="max-w-[22ch] text-white" style={{ fontSize: 'clamp(26px,3.2vw,42px)', lineHeight: 1.3, fontWeight: 800 }}>{title}</h1>
        {desc && <p className="mt-3 max-w-[62ch] text-[14px] leading-relaxed text-mist-200">{desc}</p>}
        {facts.length > 0 && (
          <div className="mt-7 flex flex-wrap gap-x-8 gap-y-3 border-t border-white/15 pt-5">
            {facts.map((f, i) => (
              <div key={i}>
                <div className="whitespace-nowrap text-[14px] font-bold text-white"><FactValue f={f} /></div>
                <div className="mt-0.5 text-[11px] font-semibold tracking-wide text-mist-300"><FactLabel f={f} /></div>
              </div>
            ))}
          </div>
        )}
        {children}
      </div>
    </section>
  )
}

export function Head({ eyebrow, title, accent, desc, action, light = false }) {
  return (
    <div className="rv mb-10 text-center md:mb-12">
      {eyebrow && <div className={`eyebrow mb-3 justify-center ${light ? '!text-brass' : 'text-brass-dark'}`}>{eyebrow}</div>}
      <h2 className={`mx-auto max-w-[34ch] ${light ? 'text-white' : 'text-ink'}`} style={{ fontSize: 'clamp(20px,2.2vw,28px)', lineHeight: 1.4 }}>
        {title}
        {accent && <span className={light ? 'text-brass' : 'text-brass-deep'}> {accent}</span>}
      </h2>
      {desc && <p className={`mx-auto mt-3 max-w-[62ch] text-[13.5px] leading-relaxed ${light ? 'text-mist-300' : 'text-[#5A6773]'}`}>{desc}</p>}
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  )
}

export function StatsStrip({ items }) {
  const { lang } = useLang()
  return (
    <div className="wrap relative">
      <div className="grid divide-y divide-mist-200 border-y border-mist-200 bg-white md:grid-cols-4 md:divide-y-0 md:divide-x md:rtl:divide-x-reverse">
        {items.map((s, i) => (
          <div key={i} className={`rv rv-d${i + 1} flex items-baseline gap-3 px-7 py-7`}>
            <CountUp value={s.value} lang={lang} className="font-head text-[32px] font-bold leading-none text-ink" />
            <span className="text-[12.5px] font-semibold text-[#64707C]">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export function ProcessSteps({ steps }) {
  return (
    <div className="relative grid gap-8 md:grid-cols-4 md:gap-6">
      <span className="step-line inset-x-[12%] hidden md:block !top-6 !h-px !bg-mist-300" aria-hidden="true" />
      {steps.map(([n, ttl, d], i) => (
        <div key={i} className={`rv rv-d${i + 1} relative flex gap-4 md:flex-col md:items-center md:text-center`}>
          <span className="relative z-[2] grid h-12 w-12 shrink-0 place-items-center rounded-[8px] border border-mist-300 bg-white font-head text-[15px] font-bold text-brass-dark shadow-[0_10px_24px_-18px_rgba(15,36,56,.5)]">{n}</span>
          <div>
            <h3 className="mb-1.5 text-[15px]">{ttl}</h3>
            <p className="text-[14px] leading-relaxed text-[#5A6773]">{d}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

export function FaqList({ items, image }) {
  const { L } = useLang()
  if (image) {
    return (
      <div className="grid items-start gap-8 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)] lg:gap-12">
        <div className="grid gap-3">
          {items.map((f, i) => (
            <details key={i} className={`faq-item faq-plus rv rv-d${(i % 3) + 1}`} open={i === 0}>
              <summary>{L(f.q)}<span className="faq-mark"><I.plus /></span></summary>
              <div className="faq-body">{L(f.a)}</div>
            </details>
          ))}
        </div>
        <div className="rv rv-r relative hidden overflow-hidden rounded-[14px] border border-mist-200 shadow-card lg:block">
          <img src={image} alt="" loading="lazy" className="kenburns aspect-[4/5] w-full object-cover" />
          <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/55 to-transparent" aria-hidden="true" />
        </div>
      </div>
    )
  }
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {items.map((f, i) => (
        <details key={i} className={`faq-item rv rv-d${(i % 2) + 1}`} open={i === 0}>
          <summary>{L(f.q)}<I.down className="shrink-0 text-brass-dark transition-transform" /></summary>
          <div className="faq-body">{L(f.a)}</div>
        </details>
      ))}
    </div>
  )
}

export function TestimonialBand({ items, badges }) {
  const { L } = useLang()
  const { t } = useLang()
  if (!items?.length) return null
  return (
    <section className="band-dark relative py-16 md:py-20">
      <div className="wrap relative z-[2]">
        <Head light eyebrow={t('testimonials_t')} title={L({ fa: 'گفتهٔ همکاران تجارتی ما', en: 'What our trade partners say' })} />
        <div className="grid gap-5 md:grid-cols-3">
          {items.slice(0, 3).map((q, i) => (
            <figure key={i} className={`rv rv-d${i + 1} glass flex flex-col gap-4 p-6 transition-transform duration-300 hover:-translate-y-1.5`}>
              <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor" className="text-brass"><path d="M10 8c-3 0-5 2.2-5 5.2 0 2.2 1.6 3.8 3.7 3.8 1.9 0 3.3-1.4 3.3-3.2 0-1.7-1.2-3-2.9-3-.3 0-.6 0-.8.1.4-1.5 1.7-2.6 3.2-2.9L10 8Zm9 0c-3 0-5 2.2-5 5.2 0 2.2 1.6 3.8 3.7 3.8 1.9 0 3.3-1.4 3.3-3.2 0-1.7-1.2-3-2.9-3-.3 0-.6 0-.8.1.4-1.5 1.7-2.6 3.2-2.9L19 8Z" /></svg>
              <blockquote className="flex-1 text-[14.5px] leading-relaxed text-mist-100">{L(q.quote)}</blockquote>
              <figcaption className="border-t border-white/10 pt-3 text-[13px]">
                <span className="block font-bold text-white">{L(q.name)}</span>
                <span className="text-mist-300">{L(q.role)} — {L(q.company)}</span>
              </figcaption>
            </figure>
          ))}
        </div>
        {badges?.length > 0 && (
          <div className="rv mt-10 border-t border-white/10 pt-8">
            <div className="mb-5 text-center text-[12.5px] font-bold uppercase tracking-[.18em] text-mist-300">
              {t('partners_t')}
            </div>
            <LogoBadgeRow items={badges} />
          </div>
        )}
      </div>
    </section>
  )
}

/* ---- reference-style signature pieces ---- */
/* overlapping photo/initial avatars + label (hero trust row) */
export function AvatarCluster({ members = [], title, sub }) {
  const { L } = useLang()
  const ms = members.slice(0, 4)
  if (!ms.length) return null
  return (
    <div className="rv mt-8 flex items-center gap-4">
      <div className="flex" dir="ltr">
        {ms.map((m, i) => (
          m.photo
            ? <img key={i} src={m.photo} alt="" loading="lazy" className={`h-11 w-11 rounded-full object-cover ring-2 ring-ink ${i > 0 ? '-ms-3' : ''}`} />
            : <span key={i} className={`grid h-11 w-11 place-items-center rounded-full bg-brass-pale font-head text-[15px] font-bold text-brass-dark ring-2 ring-ink ${i > 0 ? '-ms-3' : ''}`}>{L(m.name).trim().charAt(0)}</span>
        ))}
      </div>
      <span className="text-[13px] leading-tight text-mist-200">
        <b className="block text-[14px] text-white">{title}</b>
        {sub}
      </span>
    </div>
  )
}

/* rotating circular stamp over photos */
export function SpinBadge({ text, className = '', ring = false, icon = 'ship' }) {
  return (
    <span className={`pointer-events-none absolute grid h-[104px] w-[104px] place-items-center rounded-full bg-white shadow-card ${ring ? 'border-2 border-brass' : ''} ${className}`} aria-hidden="true">
      <svg viewBox="0 0 100 100" className="spin-slow absolute inset-0 h-full w-full text-brass-deep" style={{ direction: 'ltr' }}>
        <defs><path id="sb-c" d="M50,50 m-36,0 a36,36 0 1,1 72,0 a36,36 0 1,1 -72,0" /></defs>
        <text fontSize="10.2" fontWeight="700" letterSpacing="2.2" fill="currentColor">
          <textPath href="#sb-c">{text}</textPath>
        </text>
      </svg>
      <span className={`grid h-11 w-11 place-items-center rounded-full ${ring ? 'bg-white text-brass' : 'bg-brass text-white'}`}>
        {icon === 'arrow' ? <I.arrow className="h-5 w-5 -rotate-45" /> : <I.ship />}
      </span>
    </span>
  )
}

/* outline seal badges row (dark bands) */
export function LogoBadgeRow({ items = [] }) {
  const { L } = useLang()
  return (
    <div className="flex flex-wrap items-center justify-center gap-3 md:gap-4">
      {items.map((b, i) => (
        <span key={b.id ?? i}
          className="inline-flex max-w-[190px] items-center gap-2 rounded-full border border-white/25 px-4 py-2 text-[12.5px] font-bold text-mist-100 transition-colors hover:border-brass hover:text-brass">
          <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full border border-white/30 text-[9px]">{L(b.name).trim().charAt(0)}</span>
          <span className="truncate">{L(b.name)}</span>
        </span>
      ))}
    </div>
  )
}

/* ---------------- lightbox (photos + videos) ---------------- */
export function Lightbox({ items, i, setI, close }) {
  const { t, L } = useLang()
  useEffect(() => {
    const h = (e) => {
      if (e.key === 'Escape') close()
      if (e.key === 'ArrowLeft') setI((p) => (p + 1) % items.length)
      if (e.key === 'ArrowRight') setI((p) => (p - 1 + items.length) % items.length)
    }
    window.addEventListener('keydown', h)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', h); document.body.style.overflow = prev }
  }, [items.length, setI, close])
  const it = items[i]
  if (!it) return null
  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-ink/94 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" onClick={close}>
      <button className="absolute end-4 top-4 grid h-11 w-11 place-items-center rounded-full border border-white/20 text-white hover:border-brass hover:text-brass" onClick={close} aria-label={t('close')}><I.x /></button>
      {items.length > 1 && (
        <>
          <button className="absolute start-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full border border-white/20 text-white hover:border-brass hover:text-brass md:start-6"
            aria-label={t('prev')} onClick={(e) => { e.stopPropagation(); setI((p) => (p - 1 + items.length) % items.length) }}>
            <I.arrow className="rtl:rotate-0 rotate-180" />
          </button>
          <button className="absolute end-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full border border-white/20 text-white hover:border-brass hover:text-brass md:end-6"
            aria-label={t('next')} onClick={(e) => { e.stopPropagation(); setI((p) => (p + 1) % items.length) }}>
            <I.arrow className="rtl:rotate-180" />
          </button>
        </>
      )}
      <figure className="max-h-full w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
        {it.video
          ? <video src={it.video} poster={it.poster || it.image} controls autoPlay playsInline className="max-h-[76vh] w-full rounded-xl bg-black" />
          : <img src={it.image} alt={L(it.caption, '')} className="mx-auto max-h-[76vh] w-auto rounded-xl object-contain" />}
        {it.caption && <figcaption className="mt-3 text-center text-[14px] text-mist-200">{L(it.caption)}</figcaption>}
      </figure>
    </div>
  )
}

/* ---------------- cards ---------------- */
export function ProductCard({ p }) {
  const { t, L } = useLang()
  return (
    <Link to={`/products/${p.id}/`} className="card group flex h-full flex-col overflow-hidden no-underline">
      <div className="relative aspect-[4/3] overflow-hidden bg-mist-100">
        <img src={p.image} alt={L(p.name)} loading="lazy" decoding="async"
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        <span className="absolute start-3 top-3 flex gap-1.5">
          {p.featured && <span className="rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured_badge')}</span>}
          {p.demo && <span className="demo-badge !static">{t('demo')}</span>}
        </span>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-5">
        <span className="flex items-center justify-between gap-2 text-[12px] font-bold text-brass-dark">
          <CatName id={p.category} />
          {p.status && <StatusTag s={p.status} />}
        </span>
        <h3 className="text-[15px] leading-relaxed">{L(p.name)}</h3>
        <p className="line-clamp-2 text-[13.5px] text-[#5A6773]">{L(p.short)}</p>
        <span className="mt-auto inline-flex items-center gap-2 pt-2 text-[13.5px] font-bold text-ink transition-colors group-hover:text-brass-dark">
          {t('view_details')} <I.arrow className="transition-transform group-hover:-translate-x-1 rtl:rotate-180" />
        </span>
      </div>
    </Link>
  )
}
export function StatusTag({ s }) {
  const { t } = useLang()
  const map = {
    available: ['status_available', 'bg-[#E7F5EE] text-ok border-[#BFE4D1]'],
    on_request: ['status_on_request', 'bg-brass-pale text-brass-dark border-[#F1C9B8]'],
    inquiry: ['status_inquiry', 'bg-mist-100 text-[#5A6773] border-mist-300']
  }
  const [k, cls] = map[s] ?? map.inquiry
  return <span className={`rounded-full border px-2 py-0.5 text-[10.5px] font-bold ${cls}`}>{t(k)}</span>
}
function CatName({ id }) {
  const { data } = useContent(); const { L } = useLang()
  const c = (data?.categories ?? []).find((x) => x.id === id)
  return c ? L(c.name) : ''
}

const NEWS_CATS = { news: ['خبر', 'News'], note: ['یادداشت', 'Note'], announce: ['اطلاعیه', 'Announcement'], event: ['رویداد', 'Event'] }
export function NewsCard({ n }) {
  const { t, L, lang } = useLang()
  const cat = NEWS_CATS[n.category] ? NEWS_CATS[n.category][lang === 'fa' ? 0 : 1] : n.category
  return (
    <Link to={`/news/${n.id}/`} className="card group flex h-full flex-col overflow-hidden no-underline">
      <div className="relative aspect-[16/9] overflow-hidden bg-mist-100">
        <img src={n.image} alt={L(n.title)} loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        {n.featured && <span className="absolute start-3 top-3 rounded-full bg-brass px-2.5 py-0.5 text-[10.5px] font-bold text-white">{t('featured_badge')}</span>}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-5">
        <div className="flex items-center gap-3 text-[12px] text-[#64707C]">
          <time dateTime={n.date}>{n.date}</time>
          {cat && <span className="rounded-full bg-mist-100 px-2 py-0.5 text-[10.5px] font-bold text-[#5A6773]">{cat}</span>}
          {n.demo && <span className="tag !py-0.5 text-[10.5px]">{t('demo')}</span>}
        </div>
        <h3 className="text-[14.5px] leading-relaxed">{L(n.title)}</h3>
        <p className="line-clamp-2 text-[13.5px] text-[#5A6773]">{L(n.excerpt)}</p>
        <span className="mt-auto flex items-center justify-between gap-3 pt-3">
          <span className="text-[13px] font-bold text-ink transition-colors group-hover:text-brass-dark">{t('read_more')}</span>
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-brass-pale text-brass-dark transition-colors group-hover:bg-brass group-hover:text-white">
            <I.arrow className="rtl:rotate-180" />
          </span>
        </span>
      </div>
    </Link>
  )
}

/* partner relation kind label */
export function RelTag({ kind }) {
  const { t } = useLang()
  const map = { agency: 'rel_agency', partner: 'rel_partner', supplier: 'rel_supplier', client: 'rel_client', brand: 'rel_brand', affiliate: 'rel_affiliate' }
  if (!kind || !map[kind]) return null
  return <span className="rounded-full border border-mist-300 bg-mist-50 px-2.5 py-0.5 text-[11px] font-bold text-[#5A6773]">{t(map[kind])}</span>
}

/* monogram logo mark (partners & brands) */
const KIND_SHAPE = { agency: 0, supplier: 1, client: 2, brand: 3, partner: 4, affiliate: 5 }
export function LogoMark({ name = '', kind = 'partner', size = 40 }) {
  const ch = String(name).trim().charAt(0) || '•'
  const shapes = [
    <path d="M20 3 34 9v10c0 9-6 15-14 18C12 34 6 28 6 19V9Z" />,
    <path d="M20 4 34 12v16L20 36 6 28V12Z" />,
    <circle cx="20" cy="20" r="15" />,
    <rect x="10" y="10" width="20" height="20" rx="4" transform="rotate(45 20 20)" />,
    <rect x="7" y="7" width="26" height="26" rx="7" />,
    <path d="M14 6h12l8 8v12l-8 8H14l-8-8V14Z" />
  ]
  const idx = KIND_SHAPE[kind] ?? 4
  return (
    <span className="grid shrink-0 place-items-center" style={{ width: size, height: size }} aria-hidden="true">
      <svg viewBox="0 0 40 40" width={size} height={size}>
        <g fill={idx % 2 ? '#C4873B' : '#0C2E4E'}>{shapes[idx]}</g>
        <text x="20" y="25.5" textAnchor="middle" fontSize="15" fontWeight="800" fill="#fff">{ch}</text>
      </svg>
    </span>
  )
}

/* overlapping rounded photos + stat chip (reference collage) */
export function PhotoCollage({ main, second, chipValue, chipLabel, className = '' }) {
  return (
    <div className={`relative ${className}`}>
      <div className="overflow-hidden rounded-[10px] border border-mist-200">
        <img src={main} alt="" loading="lazy" className="aspect-[4/3] w-full object-cover" />
      </div>
      {second && (
        <div className="absolute -bottom-8 -start-3 w-[46%] overflow-hidden rounded-[10px] border border-mist-200 shadow-[0_18px_44px_-30px_rgba(15,36,56,.45)] md:-start-6">
          <img src={second} alt="" loading="lazy" className="aspect-[4/3] w-full object-cover" />
        </div>
      )}
      {chipValue && (
        <div className="absolute -bottom-6 end-4 rounded-[8px] bg-ink px-5 py-3 text-center">
          <div className="font-head text-[22px] font-bold leading-none text-white">{chipValue}</div>
          <div className="mt-1 text-[11px] font-bold tracking-wide text-mist-300">{chipLabel}</div>
        </div>
      )}
    </div>
  )
}

/* ---------------- footer ---------------- */
export function Footer() {
  const { t, L } = useLang()
  const { data, settings } = useContent()
  const c = settings.company ?? {}
  const ct = settings.contact ?? {}
  const sec = settings.sections ?? {}
  const y = new Date().getFullYear()
  const has = (xs) => (xs?.length ?? 0) > 0
  const trade = [
    ['/import', L(settings.pages?.import?.title, 'Import')],
    ['/export', L(settings.pages?.export?.title, 'Export')],
    ['/products', t('nav_products')],
    ...(sec.showProjects !== false && has(data?.projects) ? [['/projects', t('nav_projects')]] : []),
    ['/process', t('nav_process')]
  ]
  const pages = [
    ['/about', t('nav_about')],
    ...(sec.showPartners !== false && (has(data?.partners) || has(data?.brands)) ? [['/about#partners', t('nav_partners')]] : []),
    ['/news', t('nav_news')],
    ...(sec.showGallery !== false && has(data?.gallery) ? [['/gallery', t('nav_gallery')]] : []),
    ...(sec.showDownloads !== false ? [['/downloads', t('nav_downloads')]] : []),
    ...(sec.showCareers !== false ? [['/careers', t('nav_careers')]] : []),
    ['/contact', t('nav_contact')],
    ['/privacy', t('nav_privacy')],
    ['/terms', t('nav_terms')]
  ]
  return (
    <footer className="mt-auto bg-[#0B1D30] text-mist-200">
      <div className="wrap grid gap-10 border-b border-white/10 py-10 md:grid-cols-[1.5fr_.9fr_1.1fr_1.2fr]">
        <div>
          <Brand light />
          <p className="mt-4 max-w-[42ch] text-[14px] leading-relaxed text-[#9AA1A8]">{L(c.summary)}</p>
          <div className="mt-5"><SocialRow ct={ct} light /></div>
        </div>
        <div>
          <h3 className="mb-4 text-[14.5px] font-bold text-white">{t('activities_t')}</h3>
          <ul className="grid gap-1.5 text-[14px]">
            {trade.map(([to, label]) => (
              <li key={to}><Link className="inline-flex min-h-[34px] items-center hover:text-brass" to={to}>{label}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="mb-4 text-[14.5px] font-bold text-white">{t('pages')}</h3>
          <ul className="grid gap-1.5 text-[14px]">
            {pages.map(([to, label]) => (
              <li key={to}><Link className="inline-flex min-h-[34px] items-center hover:text-brass" to={to}>{label}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="mb-4 text-[14.5px] font-bold text-white">{t('contact_t')}</h3>
          <ul className="grid gap-3 text-[14px]">
            <li className="flex items-start gap-2.5"><I.pin className="mt-1.5 shrink-0 text-brass" /><span>{L(ct.address) || t('pending')}</span></li>
            <li className="flex items-start gap-2.5"><I.phone className="mt-1.5 shrink-0 text-brass" /><span dir="ltr">{ct.phone || t('pending')}</span></li>
            {ct.whatsapp && <li className="flex items-start gap-2.5"><I.wa className="mt-1.5 shrink-0 text-brass" /><a className="hover:text-brass" dir="ltr" href={`https://wa.me/${String(ct.whatsapp).replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer">{ct.whatsapp}</a></li>}
            <li className="flex items-start gap-2.5"><I.mail className="mt-1.5 shrink-0 text-brass" /><span>{ct.email || t('pending')}</span></li>
          </ul>
        </div>
      </div>
      <div className="wrap flex flex-wrap items-center justify-between gap-3 py-5 text-[13px] text-[#9AA1A8]">
        <span>{t('rights', y)}</span>
        <span className="flex items-center gap-4">
          <Link className="hover:text-white" to="/privacy">{t('nav_privacy')}</Link>
          <Link className="hover:text-white" to="/terms">{t('nav_terms')}</Link>
          <a className="hover:text-white" href="/admin/">{t('admin')}</a>
        </span>
      </div>
    </footer>
  )
}

/* ---------- editorial indexed section head (Swiss corporate grid) ---------- */
export function SecHead({ n, eyebrow, title, desc, action, light = false }) {
  return (
    <div className={`rv mb-8 border-b pb-4 md:mb-10 ${light ? 'border-white/15' : 'border-mist-200'}`}>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className={`mb-2 flex items-center gap-2.5 text-[11px] font-bold tracking-[.18em] ${light ? 'text-brass' : 'text-brass-dark'}`}>
            <span className={`font-head text-[13px] font-bold ${light ? 'text-[#8FC0E4]' : 'text-brand'}`}>{n}</span>
            <span>{eyebrow}</span>
          </div>
          <h2 className={light ? 'text-white' : 'text-ink'} style={{ fontSize: 'clamp(18px,2vw,24px)', lineHeight: 1.4 }}>{title}</h2>
        </div>
        {action}
      </div>
      {desc && <p className={`mt-2 max-w-[70ch] text-[13px] leading-relaxed ${light ? 'text-mist-300' : 'text-[#5A6773]'}`}>{desc}</p>}
    </div>
  )
}

/* ---------- mobile sticky contact bar (10/10 conversion on touch) ---------- */
export function ContactBar() {
  const { t, L } = useLang()
  const { settings } = useContent()
  const c = settings.contact ?? {}
  const phone = L(c.phone) || ''
  const wa = L(c.whatsapp) || phone
  const digits = (v) => String(v).replace(/[^0-9+]/g, '')
  return (
    <nav aria-label="quick contact" className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-3 border-t border-mist-200 bg-white/95 backdrop-blur md:hidden">
      {phone ? (
        <a href={`tel:${digits(phone)}`} className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[11px] font-bold text-ink no-underline active:bg-mist-100">
          <I.phone className="h-5 w-5 text-brand" />{t('call_us')}
        </a>
      ) : (
        <Link to="/contact" className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[11px] font-bold text-ink no-underline active:bg-mist-100">
          <I.phone className="h-5 w-5 text-brand" />{t('call_us')}
        </Link>
      )}
      {wa ? (
        <a href={`https://wa.me/${digits(wa).replace(/^\+/, '')}`} target="_blank" rel="noopener" className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 border-x border-mist-200 text-[11px] font-bold text-ink no-underline active:bg-mist-100">
          <I.chat className="h-5 w-5 text-ok" />{t('whatsapp_t')}
        </a>
      ) : (
        <Link to="/contact" className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 border-x border-mist-200 text-[11px] font-bold text-ink no-underline active:bg-mist-100">
          <I.chat className="h-5 w-5 text-ok" />{t('whatsapp_t')}
        </Link>
      )}
      <Link to="/contact" className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[11px] font-bold text-ink no-underline active:bg-mist-100">
        <I.edit className="h-5 w-5 text-brass" />{t('nav_contact')}
      </Link>
    </nav>
  )
}

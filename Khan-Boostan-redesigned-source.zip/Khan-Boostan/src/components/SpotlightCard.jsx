export default function SpotlightCard({ as: Element = 'div', className = '', children, onPointerMove, onPointerLeave, ...props }) {
  const handleMove = (event) => {
    if (event.pointerType === 'touch') { onPointerMove?.(event); return }
    const el = event.currentTarget
    const rect = el.getBoundingClientRect()
    const x = (event.clientX - rect.left) / Math.max(1, rect.width)
    const y = (event.clientY - rect.top) / Math.max(1, rect.height)
    el.style.setProperty('--spot-x', `${(x * rect.width).toFixed(1)}px`)
    el.style.setProperty('--spot-y', `${(y * rect.height).toFixed(1)}px`)
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      el.style.setProperty('--spot-tilt-x', `${((.5 - y) * 3.4).toFixed(2)}deg`)
      el.style.setProperty('--spot-tilt-y', `${((x - .5) * 4.2).toFixed(2)}deg`)
    }
    onPointerMove?.(event)
  }
  const handleLeave = (event) => {
    event.currentTarget.style.setProperty('--spot-x', '50%')
    event.currentTarget.style.setProperty('--spot-y', '50%')
    event.currentTarget.style.setProperty('--spot-tilt-x', '0deg')
    event.currentTarget.style.setProperty('--spot-tilt-y', '0deg')
    onPointerLeave?.(event)
  }

  return <Element {...props} className={`ref-spotlight ${className}`.trim()} onPointerMove={handleMove} onPointerLeave={handleLeave}>{children}</Element>
}

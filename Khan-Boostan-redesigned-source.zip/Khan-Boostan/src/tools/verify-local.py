#!/usr/bin/env python3
"""Read-only page/text/SEO/error comparison of the protected 8081 mirror and 8083 build.

The previews must already be running. Does not call the public site or edit files.
Optional route arguments restrict the matrix; default checks every public route.
"""
import difflib
import sys
from playwright.sync_api import sync_playwright

STATIC = ('/', '/about', '/activities', '/import', '/export', '/process',
          '/products', '/news', '/gallery', '/partners', '/projects', '/contact',
          '/downloads', '/careers', '/privacy', '/terms')
DETAIL = ('/products/sample-dried-fruit', '/news/demo-export-season',
          '/not-a-real-route', '/products/not-a-product', '/news/not-an-article')
ROUTES = tuple(sys.argv[1:]) or STATIC + DETAIL
META = ('title', 'description', 'og:title', 'og:description', 'og:image')


def inspect(browser, port, route, lang, width):
    page = browser.new_page(viewport={'width': width, 'height': 820 if width < 600 else 900})
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('console', lambda message: errors.append(message.text) if message.type == 'error' else None)
    try:
        page.goto(f'http://127.0.0.1:{port}{route}', wait_until='networkidle', timeout=30000)
        if lang == 'en':
            page.get_by_role('button', name='EN', exact=True).first.click()
        if route == '/':
            # The reference animates the market counter only when it enters view;
            # compare settled *visible* text, not two different animation frames.
            page.get_by_text('بازار فعال' if lang == 'fa' else 'Active markets', exact=True).first.scroll_into_view_if_needed()
            page.wait_for_timeout(1600)
        page.evaluate('window.scrollTo({top: document.body.scrollHeight, behavior: "instant"})')
        page.wait_for_timeout(1500)  # reveal animations
        meta = (page.title(),) + tuple(page.locator(
            f'meta[name="{key}"]' if key == 'description' else f'meta[property="{key}"]').first.get_attribute('content')
            if page.locator(f'meta[name="{key}"]' if key == 'description' else f'meta[property="{key}"]').count() else None
            for key in META[1:])
        return page.inner_text('body'), meta, errors
    finally:
        page.close()


def main():
    cases = 0
    failures = 0
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()
        try:
            for route in ROUTES:
                widths = (1440, 390) if route in STATIC else (1440,)
                for width in widths:
                    for lang in ('fa', 'en'):
                        cases += 1
                        try:
                            original = inspect(browser, 8081, route, lang, width)
                            review = inspect(browser, 8083, route, lang, width)
                            reasons = []
                            if original[0] != review[0]:
                                d = list(difflib.unified_diff(original[0].splitlines(), review[0].splitlines(), n=1))
                                reasons.append('body: ' + ' | '.join(d[3:9]))
                            if original[1] != review[1]:
                                reasons.append('metadata: ' + repr((original[1], review[1])))
                            if review[2]:
                                reasons.append('console/page: ' + repr(review[2][:2]))
                            if reasons:
                                failures += 1
                                print(f'DIFF  {route:<33} {lang}/{width}: {"; ".join(reasons)}', flush=True)
                        except Exception as error:
                            failures += 1
                            print(f'ERROR {route:<33} {lang}/{width}: {error}', flush=True)
                print(f'Checked {route} ({cases} cases; {failures} failures)', flush=True)
        finally:
            browser.close()
    print(f'RESULT {cases} bilingual viewport cases, {failures} failures (text + metadata + browser errors)', flush=True)
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())

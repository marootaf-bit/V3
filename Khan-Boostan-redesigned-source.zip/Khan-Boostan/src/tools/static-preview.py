#!/usr/bin/env python3
"""Serve the built React design preview as files only: no PHP, API or writes.

Run from any directory: python3 project/src/tools/static-preview.py
The browser gets the static index.html for client-side routes such as /admin/.
"""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit
import argparse

ROOT = Path(__file__).resolve().parents[2] / 'build-cpanel'


class StaticPreview(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def send_head(self):
        path = unquote(urlsplit(self.path).path)
        parts = Path(path).parts
        if path == '/api' or path.startswith('/api/') or any(part.startswith('.') for part in parts):
            self.send_error(404, 'No API or hidden files in the static preview')
            return None
        target = Path(self.translate_path(path))
        if target.is_file():
            return super().send_head()
        if target.is_dir() and path != '/':
            self.send_error(404, 'Directory listing disabled')
            return None
        if path != '/' and '.' in Path(path).name:
            self.send_error(404, 'Static asset not found')
            return None
        # Client-side route. A missing asset never receives HTML as a fallback.
        self.path = '/index.html'
        return super().send_head()

    def do_POST(self):
        self.send_error(405, 'Read-only static preview')

    do_PUT = do_POST
    do_PATCH = do_POST
    do_DELETE = do_POST

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()

    def log_message(self, format, *args):
        # Keep the live preview log readable: report errors, not every image.
        if len(args) > 1 and str(args[1]).startswith(('4', '5')):
            super().log_message(format, *args)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8083)
    args = parser.parse_args()
    if not (ROOT / 'index.html').is_file():
        parser.error(f'Build missing: {ROOT / "index.html"}')
    if (ROOT / 'api').exists() or any(ROOT.rglob('*.php')):
        parser.error('Server-side files found in the preview output; rebuild with build-static.py')
    with ThreadingHTTPServer(('0.0.0.0', args.port), StaticPreview) as server:
        print(f'Static React preview: http://0.0.0.0:{args.port}/ (files only)', flush=True)
        server.serve_forever()

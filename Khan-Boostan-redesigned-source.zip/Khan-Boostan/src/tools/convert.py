#!/usr/bin/env python3
"""تبدیل snapshot HTML صفحهٔ cPanel به JSX (بدون هدر/فوتر). کاربرد:
   python3 convert.py <snapshot.html> <out.jsx> [ComponentName]"""
import re, sys
html = open(sys.argv[1], encoding='utf-8').read()
body = html[html.index('<body'):]
hi = body.index('</header>') + 9
fi = body.index('<footer')
middle = body[hi:fi]
ATTR = {'stroke-width':'strokeWidth','stroke-linecap':'strokeLinecap','stroke-linejoin':'strokeLinejoin','fill-rule':'fillRule','clip-rule':'clipRule','clip-path':'clipPath','stop-color':'stopColor','stroke-miterlimit':'strokeMiterlimit','tabindex':'tabIndex','readonly':'readOnly','maxlength':'maxLength','autocomplete':'autoComplete','novalidate':'noValidate','crossorigin':'crossOrigin','srcset':'srcSet','fetchpriority':'fetchPriority','for':'htmlFor','class':'className'}
def cam(s): return re.sub(r'-([a-z])', lambda m: m.group(1).upper(), s)
def stylepair(k, v):
    k = k.strip(); v = v.strip().replace("'", '"')
    if k.startswith('--'): return f"'{k}':'{v}'"
    return f"{cam(k)}:'{v}'"
def conv(seg):
    seg = re.sub(r'<!--(.{0,400}?)-->', lambda m: '{/*' + m.group(1).replace('{', '(').replace('}', ')') + '*/}', seg, flags=re.S)
    for a, b in ATTR.items():
        seg = re.sub(r'(\s)' + a + r'=', r'\1' + b + '=', seg)
    def style(m):
        pairs = [p.split(':', 1) for p in m.group(1).split(';') if ':' in p]
        return ' style={{' + ','.join(stylepair(k, v) for k, v in pairs) + '}}'
    seg = re.sub(r' style="([^"]*)"', style, seg)
    seg = re.sub(r'<(img|input|br|hr|source|path|circle|rect|line|polyline|polygon|ellipse|stop)(\s[^>]*?)(?<!/)>', lambda m: f'<{m.group(1)}{m.group(2)}/>', seg)
    seg = re.sub(r'</(path|circle|rect|line|polyline|polygon|ellipse|stop|source)>', '', seg)
    def anchor(m):
        tag = m.group(0)
        hm = re.search(r'href="([^"]*)"', tag)
        if hm and hm.group(1).startswith('/'):
            return '<@LINK@' + tag[2:].replace('href=', 'to=', 1)
        return tag
    seg = re.sub(r'<a\b[^>]*>', anchor, seg)
    out = []; stack = []; pos = 0
    for m in re.finditer(r'<@LINK@[^>]*>|<a\b[^>]*>|</a>', seg):
        out.append(seg[pos:m.start()]); pos = m.end()
        tok = m.group(0)
        if tok.startswith('<@LINK@'):
            stack.append('link'); out.append('<Link' + tok[7:])
        elif tok.startswith('<a'):
            stack.append('a'); out.append(tok)
        else:
            kind = stack.pop() if stack else 'a'
            out.append('</Link>' if kind == 'link' else '</a>')
    out.append(seg[pos:])
    return ''.join(out)
name = sys.argv[3] if len(sys.argv) > 3 else 'Page'
jsx = conv(middle)
open(sys.argv[2], 'w').write(f"import {{ Link }} from 'react-router-dom'\n\nexport default function {name}() {{\n  return (\n<>{jsx}</>\n  )\n}}\n")
print('written', sys.argv[2], len(jsx))

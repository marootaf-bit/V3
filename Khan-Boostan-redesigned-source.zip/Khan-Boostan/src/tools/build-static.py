#!/usr/bin/env python3
"""Rebuild the FRONTEND-ONLY preview from React plus read-only static assets.

Never runs PHP, queries/writes SQLite, copies /api, or writes to deploy/.
The SQLite file is read only to verify its before/after checksum.
Install dependencies with `npm ci` first. The safe `npm run build` targets
an expendable dist/ instead; this script explicitly refreshes build-cpanel/.
"""
from pathlib import Path
import hashlib
import shutil
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[2]
DEPLOY = PROJECT / 'deploy'
OUTPUT = PROJECT / 'build-cpanel'
VITE = PROJECT / 'node_modules/.bin/vite'
ASSET_DIRS = ('docs', 'fonts', 'images', 'uploads', 'videos')
ASSET_FILES = ('favicon.svg', 'og.jpg')


def digest(path):
    return hashlib.sha256(path.read_bytes()).digest()


def protected_hashes():
    files = [p for p in DEPLOY.rglob('*') if p.is_file()]
    return {str(p.relative_to(DEPLOY)): digest(p) for p in files}


if __name__ == '__main__':
    if not VITE.is_file():
        sys.exit('Vite is missing. Run `npm ci` in project/ first.')
    before = protected_hashes()
    database = PROJECT / 'data/khanboostan.sqlite'
    db_before = digest(database)
    subprocess.run([str(VITE), 'build', '--config', 'vite.config.js', '--outDir', '../build-cpanel'], cwd=PROJECT, check=True)
    if not (OUTPUT / 'index.html').is_file():
        sys.exit('Vite did not produce build-cpanel/index.html')
    for name in ASSET_DIRS:
        if (OUTPUT / name).exists():
            sys.exit(f'Output not cleaned before static asset copy: {name}')
        shutil.copytree(DEPLOY / name, OUTPUT / name, ignore=shutil.ignore_patterns('.htaccess', '*.php'))
    for name in ASSET_FILES:
        shutil.copy2(DEPLOY / name, OUTPUT / name)
    if (OUTPUT / 'api').exists() or list(OUTPUT.rglob('*.php')) or (OUTPUT / 'snapshots').exists():
        sys.exit('Unexpected server-side code or obsolete snapshots in static output')
    if before != protected_hashes() or db_before != digest(database):
        sys.exit('Protected deploy/ or SQLite changed — stop and investigate')
    print(f'Static-only output ready: {OUTPUT} ({sum(p.is_file() for p in OUTPUT.rglob("*"))} files).')
    print('Protected deploy/ and SQLite hashes unchanged. No API/PHP copied.')

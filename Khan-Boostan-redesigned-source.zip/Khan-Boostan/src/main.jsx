import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import './cpanel.css'
import App from './App.jsx'
import { ContentProvider, LangProvider } from '../src/lib/store.jsx'
import { DictProvider } from './lib.jsx'

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <LangProvider>
        <ContentProvider>
          <DictProvider>
            <App />
          </DictProvider>
        </ContentProvider>
      </LangProvider>
    </BrowserRouter>
  </React.StrictMode>
)

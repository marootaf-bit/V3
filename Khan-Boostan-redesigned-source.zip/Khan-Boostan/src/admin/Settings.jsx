import { useEffect, useMemo, useState } from 'react'
import { api } from './api.js'
import { SETTINGS_FORMS, SETTINGS_LABELS, FIELD_LABELS } from './dict.js'
import { Card, Badge, useToast } from './Admin.jsx'
import { I } from '../components/ui.jsx'

const KEYS = ['company', 'contact', 'hero', 'seo', 'sections', 'pages', 'about', 'activities']
const clone = (v) => JSON.parse(JSON.stringify(v ?? null))
const isBi = (v) => v && typeof v === 'object' && !Array.isArray(v) && ('fa' in v || 'en' in v)
const lab = (lang, k) => FIELD_LABELS[k]?.[lang] ?? k

export default function SettingsPage({ a, lang }) {
  const toast = useToast()
  const [orig, setOrig] = useState(null)
  const [vals, setVals] = useState(null)
  const [tab, setTab] = useState('company')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')

  useEffect(() => {
    api.settings().then((r) => { setOrig(clone(r)); setVals(clone(r)) }).catch((e) => setErr(e.message))
  }, [])

  const dirty = useMemo(() => JSON.stringify(orig?.[tab] ?? null) !== JSON.stringify(vals?.[tab] ?? null), [orig, vals, tab])

  async function save() {
    setBusy(true)
    try {
      await api.saveSettings({ [tab]: vals[tab] })
      setOrig((o) => ({ ...o, [tab]: clone(vals[tab]) }))
      toast(a.saved)
    } catch (e) { toast(e.message || a.failed, 'err') } finally { setBusy(false) }
  }

  if (err) return <Card><p className="text-[14px] text-err">{err}</p></Card>
  if (!vals) return <Card><p className="text-[14px] text-[#64707C]">…</p></Card>

  const setTab_ = (k, v) => setVals((s) => ({ ...s, [k]: v }))

  return (
    <div className="grid gap-5">
      <Card title={a.generalSettings} desc={KEYS.length + (lang === 'fa' ? ' بخش قابل ویرایش' : ' editable sections')}>
        <div className="mb-5 flex flex-wrap gap-2">
          {KEYS.map((k) => (
            <button key={k} onClick={() => setTab(k)} className={`chip ${tab === k ? 'chip-on' : ''}`}>
              {SETTINGS_LABELS[k]?.[lang] ?? k}
              {JSON.stringify(orig?.[k] ?? null) !== JSON.stringify(vals?.[k] ?? null) && <span className="h-1.5 w-1.5 rounded-full bg-brass" />}
            </button>
          ))}
        </div>

        <Section a={a} lang={lang} k={tab} value={vals[tab]} onChange={(v) => setTab_(tab, v)} />

        <footer className="mt-6 flex flex-wrap items-center gap-3 border-t border-mist-200 pt-5">
          <button className="btn-coral" onClick={save} disabled={busy || !dirty}>
            {busy ? a.saving : a.save} {!busy && <I.arrow className="rtl:rotate-180" />}
          </button>
          <button className="btn-line" disabled={!dirty} onClick={() => setVals((s) => ({ ...s, [tab]: clone(orig[tab]) }))}>{a.cancel}</button>
          {dirty && <Badge tone="warn">{a.unsaved}</Badge>}
        </footer>
      </Card>
    </div>
  )
}

/* ------------------------------------------------------------------ section */
function Section({ a, lang, k, value, onChange }) {
  if (k === 'sections') {
    const flags = ['showDemo', 'showFacts', 'showNews', 'showProducts', 'showCareers', 'showTeam', 'showPartners', 'showProjects', 'showGallery', 'showTestimonials', 'showDownloads', 'showFaq']
    return (
      <div>
        <p className="mb-3 text-[13px] text-[#64707C]">{a.sectionsHint}</p>
        <div className="grid gap-3 sm:grid-cols-2">
          {flags.map((f) => (
            <Toggle key={f} a={a} label={a[f] ?? f} value={!!value?.[f]} onChange={(v) => onChange({ ...value, [f]: v })} />
          ))}
        </div>
      </div>
    )
  }

  const spec = SETTINGS_FORMS[k]
  if (spec) {
    const known = spec.map((s) => s.split(':')[0])
    const rest = Object.keys(value ?? {}).filter((x) => !known.includes(x))
    return (
      <div className="grid gap-4">
        <div className="grid gap-4 md:grid-cols-2">
          {spec.map((s) => {
            const [key, type] = s.split(':')
            return <SimpleField key={key} a={a} lang={lang} fieldKey={key} type={type}
              value={value?.[key]} onChange={(v) => onChange({ ...value, [key]: v })} />
          })}
        </div>
        {rest.length > 0 && (
          <details className="rounded-card border border-mist-200 bg-mist-50 p-4">
            <summary className="cursor-pointer text-[13px] font-bold text-ink">{a.editJson} ({rest.join(', ')})</summary>
            <JsonBox value={Object.fromEntries(rest.map((r) => [r, value[r]]))} onChange={(v) => onChange({ ...value, ...v })} a={a} />
          </details>
        )}
      </div>
    )
  }

  /* complex settings (pages / about / activities) → recursive builder */
  return <Rec a={a} lang={lang} value={value} onChange={onChange} depth={0} label={SETTINGS_LABELS[k]?.[lang] ?? k} />
}

function SimpleField({ a, lang, fieldKey, type, value, onChange }) {
  if (type === 'bi' || type === 'bitext') {
    const ta = type === 'bitext'
    return (
      <Box label={lab(lang, fieldKey)} hint={fieldKey}>
        <div className="grid gap-2.5">
          {['fa', 'en'].map((w) => (
            <label key={w} className="block">
              <span className="mb-1 block text-[11.5px] font-bold text-[#A7AEB5]">{w === 'fa' ? a.fa : a.en}</span>
              {ta
                ? <textarea className="field resize-y" rows={w === 'fa' ? 4 : 3} dir={w === 'en' ? 'ltr' : undefined}
                  value={(isBi(value) ? value[w] : '') ?? ''} onChange={(e) => onChange({ ...(isBi(value) ? value : { fa: '', en: '' }), [w]: e.target.value })} />
                : <input className="field" dir={w === 'en' ? 'ltr' : undefined} value={(isBi(value) ? value[w] : '') ?? ''}
                  onChange={(e) => onChange({ ...(isBi(value) ? value : { fa: '', en: '' }), [w]: e.target.value })} />}
            </label>
          ))}
        </div>
      </Box>
    )
  }
  if (type === 'image') {
    return (
      <Box label={lab(lang, fieldKey)} hint={fieldKey}>
        <div className="flex items-center gap-3">
          {value ? <img src={value} alt="" className="h-16 w-24 rounded-lg border border-mist-200 object-cover" />
            : <span className="grid h-16 w-24 place-items-center rounded-lg border border-dashed border-mist-300 bg-mist-50 text-[#C6CCD1]"><I.box /></span>}
          <input className="field" dir="ltr" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
        </div>
      </Box>
    )
  }
  return (
    <Box label={lab(lang, fieldKey)} hint={fieldKey}>
      <input className="field" dir={/^[+0-9A-Za-z@.\-/ ]+$/.test(String(value ?? '')) ? 'ltr' : undefined} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
    </Box>
  )
}

const Box = ({ label, hint, children }) => (
  <div className="rounded-card border border-mist-200 bg-white p-4">
    <div className="mb-2 flex items-baseline justify-between gap-3">
      <span className="text-[13px] font-bold text-ink">{label}</span>
      {hint && hint !== label && <code className="font-mono text-[10.5px] text-[#C6CCD1]" dir="ltr">{hint}</code>}
    </div>
    {children}
  </div>
)

function Toggle({ a, label, value, onChange }) {
  return (
    <button type="button" role="switch" aria-checked={value} onClick={() => onChange(!value)}
      className={`flex items-center justify-between gap-3 rounded-card border px-4 py-3 text-start text-[13.5px] font-bold transition-colors ${value ? 'border-[#BFE4D1] bg-[#E7F5EE] text-ok' : 'border-mist-200 bg-white text-[#5A6773]'}`}>
      {label}
      <span className={`h-5 w-9 shrink-0 rounded-full p-[3px] transition-colors ${value ? 'bg-ok' : 'bg-mist-300'}`}>
        <span className={`block h-3.5 w-3.5 rounded-full bg-white transition-transform ${value ? 'translate-x-4 rtl:-translate-x-4' : ''}`} />
      </span>
    </button>
  )
}

function JsonBox({ value, onChange, a }) {
  const [txt, setTxt] = useState(() => JSON.stringify(value ?? {}, null, 2))
  const [bad, setBad] = useState('')
  return (
    <div className="mt-3">
      <textarea className="field resize-y font-mono !text-[12.5px]" dir="ltr" rows="12" value={txt}
        onChange={(e) => { setTxt(e.target.value); try { onChange(JSON.parse(e.target.value)); setBad('') } catch { setBad(a.invalidJson) } }} />
      {bad && <p className="mt-2 text-[12.5px] font-bold text-err">{bad}</p>}
    </div>
  )
}

/* ---------------------------------------------------- recursive builder */
function Rec({ a, lang, value, onChange, depth = 0, label, hint }) {
  const L = (x) => (typeof x === 'string' ? x : '')

  if (isBi(value)) {
    return (
      <Box label={label ?? 'text'} hint={hint}>
        <div className="grid gap-2.5">
          {['fa', 'en'].map((w) => (
            <label key={w} className="block">
              <span className="mb-1 block text-[11.5px] font-bold text-[#A7AEB5]">{w === 'fa' ? a.fa : a.en}</span>
              {String(value[w] ?? '').length > 70 || String(value[w] ?? '').includes('\n')
                ? <textarea className="field resize-y" rows={4} dir={w === 'en' ? 'ltr' : undefined} value={value[w] ?? ''}
                  onChange={(e) => onChange({ ...value, [w]: e.target.value })} />
                : <input className="field" dir={w === 'en' ? 'ltr' : undefined} value={value[w] ?? ''}
                  onChange={(e) => onChange({ ...value, [w]: e.target.value })} />}
            </label>
          ))}
        </div>
      </Box>
    )
  }

  if (Array.isArray(value)) {
    const rowBlank = () => {
      const sample = value[0]
      if (sample === undefined) return ''
      if (typeof sample === 'string') return ''
      if (isBi(sample)) return { fa: '', en: '' }
      if (Array.isArray(sample)) return []
      if (sample && typeof sample === 'object') return Object.fromEntries(Object.entries(sample).map(([k, v]) => [k, clone(v)]))
      return null
    }
    return (
      <div className="rounded-card border border-mist-200 bg-mist-50 p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <span className="text-[13px] font-bold text-ink">{label ?? 'list'} <span className="text-[12px] font-normal text-[#64707C]">· {value.length} {a.items}</span></span>
          <button type="button" className="btn-line btn-sm" onClick={() => onChange([...value, rowBlank()])}><I.plus /> {a.addRow}</button>
        </div>
        <div className="grid gap-3">
          {value.map((row, i) => (
            <div key={i} className="rounded-xl border border-mist-200 bg-white p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[12px] font-bold text-[#64707C]">#{i + 1}</span>
                <button type="button" className="grid h-7 w-7 place-items-center rounded-lg border border-mist-300 text-[#5A6773] hover:border-err hover:text-err"
                  onClick={() => onChange(value.filter((_, k) => k !== i))} aria-label={a.removeRow}><I.trash /></button>
              </div>
              <Rec a={a} lang={lang} value={row} depth={depth + 1} onChange={(v) => onChange(value.map((r, k) => (k === i ? v : r)))} />
            </div>
          ))}
          {value.length === 0 && <p className="text-[12.5px] text-[#A7AEB5]">{a.empty}</p>}
        </div>
      </div>
    )
  }

  if (value && typeof value === 'object') {
    if (depth >= 3) return (
      <details className="rounded-card border border-mist-200 bg-white p-4">
        <summary className="cursor-pointer text-[13px] font-bold text-ink">{a.editJson}</summary>
        <JsonBox value={value} onChange={onChange} a={a} />
      </details>
    )
    return (
      <div className="grid gap-4">
        {Object.entries(value).map(([k, v]) => (
          <div key={k}>
            <Rec a={a} lang={lang} value={v} depth={depth + 1} label={lab(lang, k)} hint={k}
              onChange={(nv) => onChange({ ...value, [k]: nv })} />
          </div>
        ))}
        <button type="button" className="btn-line btn-sm justify-self-start"
          onClick={() => { const key = window.prompt('key'); if (key) onChange({ ...value, [key]: { fa: '', en: '' } }) }}>
          <I.plus /> {a.addRow}
        </button>
      </div>
    )
  }

  if (typeof value === 'boolean') return <Toggle a={a} label={label ?? 'flag'} value={value} onChange={onChange} />

  if (typeof value === 'number') {
    return <Box label={label ?? 'number'} hint={hint}>
      <input type="number" className="field" dir="ltr" value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </Box>
  }

  return (
    <Box label={label ?? 'text'} hint={hint}>
      {String(value ?? '').length > 70 || String(value ?? '').includes('\n')
        ? <textarea className="field resize-y" rows={4} value={L(value)} onChange={(e) => onChange(e.target.value)} />
        : <input className="field" dir={/^[+0-9A-Za-z@.\-/ ]+$/.test(L(value)) ? 'ltr' : undefined} value={L(value)} onChange={(e) => onChange(e.target.value)} />}
    </Box>
  )
}

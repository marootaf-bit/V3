import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from './api.js'
import { A, COLLECTIONS, COLLECTION_ORDER } from './dict.js'
import { Card, Badge } from './Admin.jsx'
import { I } from '../components/ui.jsx'

const num = (n, lang) => (lang === 'fa' ? String(n ?? 0).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]) : String(n ?? 0))
const asMap = (v) => (Array.isArray(v) || !v ? {} : v)

export default function Dashboard({ a, lang }) {
  const [s, setS] = useState(null)
  const [err, setErr] = useState('')

  const load = () => api.stats().then(setS).catch((e) => setErr(e.message))
  useEffect(() => { load() }, [])

  if (err) return <Card><p className="text-[14px] text-err">{err}</p></Card>
  if (!s) return <Card><p className="text-[14px] text-[#64707C]">{a.signingIn}</p></Card>

  const req = asMap(s.requests)
  const byKind = asMap(s.byKind)
  const daily = Object.entries(s.daily ?? {})
  const maxDay = Math.max(1, ...daily.map(([, n]) => n))
  const cols = s.collections ?? {}
  const totalItems = Object.values(cols).reduce((x, y) => x + (y?.t ?? 0), 0)
  const published = Object.values(cols).reduce((x, y) => x + (y?.p ?? 0), 0)
  const recent = s.recent ?? []

  const cards = [
    { label: a.requests, value: s.total ?? 0, tone: 'coral', icon: <I.inbox />, to: '/admin/requests' },
    { label: a.new, value: req.new ?? 0, tone: 'warn', icon: <I.mail />, to: '/admin/requests' },
    { label: a.totalItems, value: totalItems, tone: 'ink', icon: <I.box />, to: '/admin/c/products' },
    { label: a.uploadsCount, value: s.uploads ?? 0, tone: 'ok', icon: <I.doc />, to: '/admin/c/documents' }
  ]

  return (
    <div className="grid gap-5">
      {s.initialPasswordFile && (
        <div className="flex items-start gap-3 rounded-card border border-[#E4C9A4] bg-brass-pale p-4 text-[13.5px] text-brass-dark">
          <I.shield className="mt-0.5 shrink-0" /><span>{a.initialPass}</span>
        </div>
      )}

      {/* stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c, i) => (
          <Link key={i} to={c.to} className="card group flex items-center gap-4 p-5 no-underline">
            <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl ${
              c.tone === 'coral' ? 'bg-brass-pale text-brass-dark' :
              c.tone === 'warn' ? 'bg-[#FDF1E7] text-[#B8532F]' :
              c.tone === 'ok' ? 'bg-[#E7F5EE] text-ok' : 'bg-mist-100 text-ink'}`}>{c.icon}</span>
            <span className="min-w-0">
              <span className="block font-head text-[26px] font-bold leading-none text-ink">{num(c.value, lang)}</span>
              <span className="mt-1 block truncate text-[12.5px] text-[#64707C]">{c.label}</span>
            </span>
          </Link>
        ))}
      </div>

      <div className="grid gap-5 xl:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        {/* activity chart */}
        <Card title={a.last14} action={<span className="text-[12.5px] text-[#64707C]">{a.requests}: {num(s.total ?? 0, lang)}</span>}>
          <div className="relative flex h-[168px] items-end gap-1.5 rounded-xl bg-mist-50 px-2 pt-4" role="img" aria-label={a.last14}
            style={{ backgroundImage: 'linear-gradient(to top, rgba(198,204,209,.35) 1px, transparent 1px)', backgroundSize: '100% 33%' }}>
            {daily.map(([d, n]) => (
              <div key={d} className="group flex flex-1 flex-col items-center gap-2">
                <span className="text-[11px] font-bold text-ink opacity-0 transition-opacity group-hover:opacity-100">{num(n, lang)}</span>
                <span className="w-full rounded-t-md transition-colors group-hover:!bg-brass"
                  style={{ height: `${Math.max(4, (n / maxDay) * 112)}px`, background: n > 0 ? 'linear-gradient(180deg,#0168B4,#014C84)' : '#E1E7EB' }} />
                <span className="text-[10px] text-[#A7AEB5]">{d.slice(5)}</span>
              </div>
            ))}
          </div>
          {Object.keys(byKind).length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2 border-t border-mist-200 pt-4">
              <span className="text-[12.5px] text-[#64707C]">{a.byKind}:</span>
              {Object.entries(byKind).map(([k, n]) => <Badge key={k} tone="warn">{k} · {num(n, lang)}</Badge>)}
            </div>
          )}
        </Card>

        {/* requests by status */}
        <Card title={a.byStatus} action={<Link to="/admin/requests" className="btn-line btn-sm">{a.openEditor}</Link>}>
          {s.total ? (
            <ul className="grid gap-3">
              {['new', 'read', 'done'].map((k) => {
                const n = req[k] ?? 0
                const pct = s.total ? Math.round((n / s.total) * 100) : 0
                return (
                  <li key={k}>
                    <div className="mb-1.5 flex items-center justify-between text-[13.5px]">
                      <span className="font-semibold text-ink">{a[k]}</span>
                      <span className="text-[#64707C]">{num(n, lang)} · {num(pct, lang)}٪</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-mist-200">
                      <div className="h-full rounded-full" style={{ width: `${pct}%`, background: k === 'new' ? '#0168B4' : k === 'read' ? '#5A6773' : '#2E9E6B' }} />
                    </div>
                  </li>
                )
              })}
            </ul>
          ) : <p className="text-[13.5px] text-[#64707C]">{a.noRequests}</p>}

          <div className="mt-5 border-t border-mist-200 pt-4">
            <h3 className="mb-2 text-[13px] font-bold text-[#64707C]">{a.recent}</h3>
            {recent.length === 0
              ? <p className="text-[13px] text-[#A7AEB5]">—</p>
              : (
                <ul className="grid gap-2">
                  {recent.slice(0, 5).map((r) => (
                    <li key={r.id} className="flex items-center justify-between gap-3 rounded-xl border border-mist-200 px-3 py-2 text-[13px]">
                      <span className="min-w-0 truncate font-semibold text-ink">{r.name || r.phone}</span>
                      <span className="flex shrink-0 items-center gap-2">
                        <span className="text-[12px] text-[#64707C]">{r.kind}</span>
                        <Badge tone={r.status === 'new' ? 'warn' : r.status === 'done' ? 'ok' : 'neutral'}>{a[r.status] ?? r.status}</Badge>
                      </span>
                    </li>
                  ))}
                </ul>
              )}
          </div>
        </Card>
      </div>

      {/* content overview */}
      <Card title={a.statsOverview} desc={`${a.published}: ${num(published, lang)} / ${num(totalItems, lang)}`}
        action={<button className="btn-line btn-sm" onClick={load}>{a.reload}</button>}>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {COLLECTION_ORDER.map((c) => {
            const st = cols[c] ?? { t: 0, p: 0 }
            const meta = COLLECTIONS[c]
            return (
              <Link key={c} to={`/admin/c/${c}`} className="flex items-center justify-between gap-3 rounded-card border border-mist-200 bg-mist-50 px-4 py-3 no-underline transition-colors hover:border-ink hover:bg-white">
                <span className="min-w-0">
                  <span className="block truncate text-[13.5px] font-bold text-ink">{meta.label[lang]}</span>
                  <span className="block text-[12px] text-[#64707C]">{a.published} {num(st.p, lang)} · {a.draft} {num((st.t ?? 0) - (st.p ?? 0), lang)}</span>
                </span>
                <span className="font-head text-[19px] font-bold text-brass-dark">{num(st.t, lang)}</span>
              </Link>
            )
          })}
        </div>
      </Card>
    </div>
  )
}

export { A }

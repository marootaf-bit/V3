import { useCallback, useEffect, useMemo, useState } from 'react'
import { api } from './api.js'
import { Card, Badge, useToast } from './Admin.jsx'
import { I } from '../components/ui.jsx'

const FILTERS = ['all', 'new', 'read', 'done']
const fmt = (s) => (s ? String(s).replace('T', ' ').slice(0, 16) : '—')

export default function RequestsPage({ a, lang }) {
  const toast = useToast()
  const [rows, setRows] = useState(null)
  const [err, setErr] = useState('')
  const [filter, setFilter] = useState('all')
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(null)

  const load = useCallback(() => {
    setErr(''); api.requests(filter).then((r) => setRows(Array.isArray(r) ? r : [])).catch((e) => setErr(e.message))
  }, [filter])

  useEffect(() => { load() }, [load])
  useEffect(() => { if (open) api.requests(filter).then((r) => {
    const fresh = (Array.isArray(r) ? r : []).find((x) => String(x.id) === String(open.id))
    if (fresh) setOpen(fresh)
  }).catch(() => {}) }, [filter]) // eslint-disable-line react-hooks/exhaustive-deps

  const shown = useMemo(() => {
    if (!rows) return []
    const n = q.trim().toLowerCase()
    if (!n) return rows
    return rows.filter((r) => JSON.stringify(r).toLowerCase().includes(n))
  }, [rows, q])

  async function setStatus(r, status) {
    try {
      await api.setRequestStatus(r.id, status)
      toast(a.saved)
      setOpen((o) => (o && String(o.id) === String(r.id) ? { ...o, status } : o))
      load()
    } catch (e) { toast(e.message || a.failed, 'err') }
  }

  async function remove(r) {
    if (!window.confirm(a.confirmDelete)) return
    try { await api.removeRequest(r.id); toast(a.deleted); setOpen(null); load() } catch (e) { toast(e.message || a.failed, 'err') }
  }

  const counts = useMemo(() => {
    const c = { all: 0, new: 0, read: 0, done: 0 }
    for (const r of rows ?? []) { c.all++; if (c[r.status] !== undefined) c[r.status]++ }
    return c
  }, [rows])

  return (
    <div className="grid gap-5">
      <Card title={a.requests} desc={`${counts.all} ${a.items}`}
        action={<button className="btn-line btn-sm" onClick={load}>{a.reload}</button>}>
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div className="relative min-w-[210px] flex-1">
            <I.search className="pointer-events-none absolute top-1/2 -translate-y-1/2 text-[#A7AEB5] ltr:left-3.5 rtl:right-3.5" />
            <input className="field ltr:pl-10 ltr:pr-4 rtl:pr-10 rtl:pl-4" placeholder={a.search} value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="inline-flex flex-wrap rounded-full border border-mist-300 bg-white p-[3px]">
            {FILTERS.map((f) => (
              <button key={f} onClick={() => setFilter(f)}
                className={`min-h-[36px] rounded-full px-4 text-[13px] font-bold transition-colors ${filter === f ? 'bg-ink text-white' : 'text-[#5A6773] hover:text-ink'}`}>
                {a[f] ?? f} <span className="opacity-70">({counts[f] ?? 0})</span>
              </button>
            ))}
          </div>
        </div>

        {err && <p className="rounded-xl bg-[#FBEAEA] px-4 py-3 text-[13.5px] font-bold text-err">{err}</p>}
        {!rows && !err && <p className="py-6 text-[13.5px] text-[#64707C]">…</p>}
        {rows && shown.length === 0 && <p className="py-8 text-center text-[13.5px] text-[#64707C]">{a.noRequests}</p>}

        {shown.length > 0 && (
          <ul className="grid gap-2.5">
            {shown.map((r) => (
              <li key={r.id}>
                <button onClick={() => setOpen(r)}
                  className={`flex w-full flex-wrap items-center gap-3 rounded-card border bg-white p-3.5 text-start transition-all hover:shadow-card md:flex-nowrap ${r.status === 'new' ? 'border-[#F3CDBB]' : 'border-mist-200'}`}>
                  <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full ${r.status === 'new' ? 'bg-brass-pale text-brass-dark' : r.status === 'done' ? 'bg-[#E7F5EE] text-ok' : 'bg-mist-100 text-[#5A6773]'}`}>
                    {r.kind === 'product' ? <I.box /> : r.kind === 'cooperation' ? <I.users /> : <I.mail />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14.5px] font-bold text-ink">{r.name || '—'} <span className="text-[12.5px] font-normal text-[#64707C]" dir="ltr">{r.phone}</span></span>
                    <span className="mt-0.5 block truncate text-[12.5px] text-[#64707C]">{r.subject || r.message || ''}</span>
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    <Badge tone="neutral">{r.kind}</Badge>
                    <Badge tone={r.status === 'new' ? 'warn' : r.status === 'done' ? 'ok' : 'neutral'}>{a[r.status] ?? r.status}</Badge>
                    <span className="hidden text-[12px] text-[#A7AEB5] sm:inline" dir="ltr">{fmt(r.created_at)}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {open && (
        <Detail a={a} lang={lang} r={open} onClose={() => setOpen(null)} onStatus={setStatus} onDelete={remove} />
      )}
    </div>
  )
}

function Detail({ a, r, onClose, onStatus, onDelete }) {
  const meta = r.meta && typeof r.meta === 'object' ? r.meta : {}
  const lines = [
    [a.kind, r.kind], [a.caller, r.name], [a.phone, r.phone, 'ltr'], [a.email, r.email, 'ltr'],
    [a.subject, r.subject], [a.message, r.message, 'auto'], [a.date, fmt(r.created_at), 'ltr'], [a.lang, r.lang], [a.ip, r.ip, 'ltr']
  ]
  return (
    <div className="fixed inset-0 z-[80] flex justify-end" role="dialog" aria-modal="true" aria-label={a.requests}>
      <div className="absolute inset-0 bg-ink/45 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div className="relative flex h-full w-full max-w-[620px] flex-col bg-mist-100 shadow-panel ltr:ml-auto rtl:mr-auto">
        <header className="flex min-h-[64px] shrink-0 items-center gap-3 border-b border-mist-200 bg-white px-5">
          <h2 className="text-[16px]">#{r.id} · {r.kind}</h2>
          <Badge tone={r.status === 'new' ? 'warn' : r.status === 'done' ? 'ok' : 'neutral'}>{a[r.status] ?? r.status}</Badge>
          <button className="ms-auto grid h-9 w-9 place-items-center rounded-lg border border-mist-300 text-[#5A6773] hover:border-ink hover:text-ink" onClick={onClose} aria-label={a.close}><I.x /></button>
        </header>

        <div className="flex-1 overflow-y-auto p-5">
          <Card>
            <dl className="grid gap-0">
              {lines.filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v, dir], i) => (
                <div key={i} className="grid gap-1 border-b border-mist-200 py-3 last:border-0 sm:grid-cols-[130px_minmax(0,1fr)]">
                  <dt className="text-[12.5px] font-bold text-[#64707C]">{k}</dt>
                  <dd className="whitespace-pre-wrap text-[14px] text-ink" dir={dir ?? 'auto'}>
                    {k === a.phone && v ? <a className="font-bold text-brass-dark hover:underline" href={`tel:${v}`}>{v}</a>
                      : k === a.email && v ? <a className="font-bold text-brass-dark hover:underline" href={`mailto:${v}`}>{v}</a> : v}
                  </dd>
                </div>
              ))}
            </dl>
          </Card>

          {Object.keys(meta).length > 0 && (
            <Card title="meta" className="mt-5">
              <pre className="overflow-x-auto rounded-xl bg-mist-50 p-3 text-[12px] text-[#5A6773]" dir="ltr">{JSON.stringify(meta, null, 2)}</pre>
            </Card>
          )}
        </div>

        <footer className="flex shrink-0 flex-wrap items-center gap-2 border-t border-mist-200 bg-white px-5 py-4">
          {r.status !== 'read' && <button className="btn-line btn-sm" onClick={() => onStatus(r, 'read')}>{a.markRead}</button>}
          {r.status !== 'done' && <button className="btn-ink btn-sm" onClick={() => onStatus(r, 'done')}>{a.markDone}</button>}
          {r.status !== 'new' && <button className="btn-line btn-sm" onClick={() => onStatus(r, 'new')}>{a.markNew}</button>}
          <button className="btn-danger btn-sm ms-auto" onClick={() => onDelete(r)}><I.trash /> {a.del}</button>
        </footer>
      </div>
    </div>
  )
}

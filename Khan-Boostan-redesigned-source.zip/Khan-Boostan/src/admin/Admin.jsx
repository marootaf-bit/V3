import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { NavLink, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { useLang } from '../lib/store.jsx'
import { I } from '../components/ui.jsx'
import { api, ApiError } from './api.js'
import { A, COLLECTIONS, COLLECTION_ORDER } from './dict.js'
import Dashboard from './Dashboard.jsx'
import CollectionPage from './Collection.jsx'
import RequestsPage from './Requests.jsx'
import SettingsPage from './Settings.jsx'

/* ------------------------------------------------------------------ toast */
const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)

/* ------------------------------------------------------------------ root */
export default function AdminRoot() {
  const { lang, setLang } = useLang()
  const a = A[lang] ?? A.fa
  const [me, setMe] = useState(null)
  const [checking, setChecking] = useState(true)
  const [toast, setToast] = useState(null)

  useEffect(() => {
    let alive = true
    api.me().then((r) => {
      const u = r?.user
      if (alive) setMe(u && (u.email || u.id) ? u : null)
    }).catch(() => { if (alive) setMe(null) }).finally(() => { if (alive) setChecking(false) })
    return () => { alive = false }
  }, [])

  const notify = useCallback((msg, kind = 'ok') => {
    setToast({ msg, kind })
    setTimeout(() => setToast(null), 3400)
  }, [])

  async function signOut() {
    try { await api.logout() } catch { /* ignore */ }
    setMe(null)
  }

  if (checking) return <Splash label={a.signingIn} />
  if (!me) return <Login a={a} lang={lang} setLang={setLang} onAuth={setMe} notify={notify} />

  return (
    <ToastCtx.Provider value={notify}>
      <Shell a={a} lang={lang} setLang={setLang} me={me} signOut={signOut}>
        <Routes>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard a={a} lang={lang} />} />
          <Route path="c/:name" element={<CollectionPage a={a} lang={lang} />} />
          <Route path="requests" element={<RequestsPage a={a} lang={lang} />} />
          <Route path="settings" element={<SettingsPage a={a} lang={lang} />} />
          <Route path="account" element={<AccountPage a={a} me={me} notify={notify} />} />
          <Route path="*" element={<NotFoundAdmin a={a} />} />
        </Routes>
      </Shell>
      {toast && (
        <div role="status" className="fixed bottom-6 z-[90] ltr:right-6 rtl:left-6">
          <div className={`flex items-center gap-3 rounded-full px-5 py-3 text-[14px] font-bold text-white shadow-panel ${toast.kind === 'err' ? 'bg-err' : 'bg-ok'}`}>
            {toast.kind === 'err'
              ? <I.x className="h-4 w-4" />
              : <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg>}
            {toast.msg}
          </div>
        </div>
      )}
    </ToastCtx.Provider>
  )
}

function Splash({ label }) {
  return (
    <div className="grid min-h-screen place-items-center bg-mist-100 text-[#64707C]">
      <div className="flex items-center gap-3 text-[14px]">
        <span className="h-5 w-5 animate-spin rounded-full border-2 border-brass border-t-transparent" />{label}
      </div>
    </div>
  )
}

function NotFoundAdmin({ a }) {
  return <Card><p className="text-[15px] text-[#5A6773]">{a.empty}</p></Card>
}

/* ------------------------------------------------------------------ login */
function Login({ a, lang, setLang, onAuth, notify }) {
  const [v, setV] = useState({ email: '', password: '' })
  const [busy, setBusy] = useState(false)
  const faErr = (m='') => /Too many/i.test(m) ? 'تعداد تلاش‌ها زیاد است؛ ۱۵ دقیقه دیگر دوباره تلاش کنید.' : /Invalid email or password/i.test(m) ? 'ایمیل یا رمز عبور اشتباه است.' : /network|fetch/i.test(m) ? 'خطا در اتصال؛ دوباره تلاش کنید.' : (m || 'خطای نامشخص؛ دوباره تلاش کنید.')
const [err, setErr] = useState('')

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setErr(faErr('')); try {
      const r = await api.login(v.email.trim(), v.password)
      onAuth(r?.user ?? r)
    } catch (e2) {
      setErr(faErr(e2 instanceof ApiError && e2.status === 429 ? a.tooMany : a.badLogin))} finally { setBusy(false) }
  }

  return (
    <div className="band-dark grid min-h-screen place-items-center px-5 py-12">
      <div className="relative w-full max-w-[430px]">
        <div className="glass p-7 md:p-9">
          <div className="mb-7 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src="/images/logo.png" alt="" className="h-11 w-11 rounded-full object-cover ring-1 ring-white/30" />
              <span className="leading-tight">
                <b className="block text-[15px] text-white">{a.appName}</b>
                <span className="block text-[12px] text-mist-300">khanboostan.grandtire.af</span>
              </span>
            </div>
            <button onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')} className="rounded-full border border-white/25 px-3 py-1 text-[12px] font-bold text-mist-200 hover:bg-white/10">
              {lang === 'fa' ? 'EN' : 'دری'}
            </button>
          </div>

          <h1 className="mb-1 text-[22px] text-white">{a.loginTitle}</h1>
          <p className="mb-6 text-[13.5px] text-mist-300">{a.loginHint}</p>

          <form onSubmit={submit} className="grid gap-4">
            <div>
              <label className="label !text-mist-200" htmlFor="l-email">{a.email}</label>
              <input id="l-email" type="email" dir="ltr" required autoComplete="username" value={v.email}
                onChange={(e) => setV({ ...v, email: e.target.value })}
                className="field !border-white/20 !bg-white/10 !text-white placeholder:!text-mist-300" placeholder="name@example.com" />
            </div>
            <div>
              <label className="label !text-mist-200" htmlFor="l-pass">{a.password}</label>
              <input id="l-pass" type="password" required autoComplete="current-password" value={v.password}
                onChange={(e) => setV({ ...v, password: e.target.value })}
                className="field !border-white/20 !bg-white/10 !text-white" placeholder="••••••••" />
            </div>
            {err && <p role="alert" className="text-[13px] font-bold text-[#FFB4A2]">{err}</p>}
            <button type="submit" disabled={busy} className="btn-coral mt-1 w-full">
              {busy ? a.signingIn : a.signIn} {!busy && <I.arrow className="rtl:rotate-180" />}
            </button>
          </form>
        </div>
        <a href="/" className="mt-5 block text-center text-[13px] text-mist-300 hover:text-white">{a.viewSite} ←</a>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ shell */
const GROUPS = [
  { key: 'content', items: COLLECTION_ORDER.filter((c) => COLLECTIONS[c].group === 'content') },
  { key: 'trade', items: COLLECTION_ORDER.filter((c) => COLLECTIONS[c].group === 'trade') }
]

function Shell({ a, lang, setLang, me, signOut, children }) {
  const [nav, setNav] = useState(false)
  const loc = useLocation()
  const nav_ = useNavigate()
  useEffect(() => { setNav(false) }, [loc.pathname])

  const linkCls = ({ isActive }) =>
    `flex min-h-[40px] items-center gap-2.5 rounded-xl px-3 text-[13.5px] font-semibold transition-colors ${isActive ? 'bg-white/12 text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,.08)]' : 'text-mist-300 hover:bg-white/[.07] hover:text-white'}`

  return (
    <div className="min-h-screen bg-mist-100 lg:grid lg:grid-cols-[264px_minmax(0,1fr)]">
      {/* sidebar */}
      <aside className={`band-dark fixed inset-y-0 z-[70] w-[264px] overflow-y-auto p-4 transition-transform ${nav ? 'translate-x-0' : 'max-lg:ltr:-translate-x-full max-lg:rtl:translate-x-full'}`}>
        <div className="mb-6 flex items-center gap-3 px-2">
          <img src="/images/logo.png" alt="" className="h-10 w-10 rounded-full object-cover ring-1 ring-white/30" />
          <span className="leading-tight">
            <b className="block text-[14px] text-white">خان بوستان</b>
            <span className="block text-[11.5px] text-mist-300">{a.appName}</span>
          </span>
          <button className="ms-auto text-mist-300 lg:hidden" onClick={() => setNav(false)} aria-label={a.close}><I.x /></button>
        </div>

        <nav className="grid gap-1">
          <NavLink to="/admin/dashboard" className={linkCls}><I.grid /> {a.dashboard}</NavLink>
          <NavLink to="/admin/requests" className={linkCls}><I.inbox /> {a.requests}</NavLink>
        </nav>

        {GROUPS.map((g) => (
          <div key={g.key} className="mt-6">
            <div className="mb-2 px-3 text-[11px] font-bold uppercase tracking-wider text-mist-300/70">{a[g.key]}</div>
            <nav className="grid gap-1">
              {g.items.map((c) => (
                <NavLink key={c} to={`/admin/c/${c}`} className={linkCls}>
                  <span className="h-1.5 w-1.5 rounded-full bg-brass/70" />
                  {COLLECTIONS[c].label[lang]}
                </NavLink>
              ))}
            </nav>
          </div>
        ))}

        <div className="mt-6">
          <div className="mb-2 px-3 text-[11px] font-bold uppercase tracking-wider text-mist-300/70">{a.system}</div>
          <nav className="grid gap-1">
            <NavLink to="/admin/settings" className={linkCls}><I.gear /> {a.settings}</NavLink>
            <NavLink to="/admin/account" className={linkCls}><I.users /> {a.account}</NavLink>
          </nav>
        </div>

        <div className="mt-8 grid gap-2 border-t border-white/10 pt-5">
          <a href="/" target="_blank" rel="noreferrer" className="flex min-h-[40px] items-center gap-2.5 rounded-xl px-3 text-[13.5px] font-semibold text-mist-300 hover:bg-white/[.07] hover:text-white">
            <I.globe /> {a.viewSite}
          </a>
          <button onClick={signOut} className="flex min-h-[40px] items-center gap-2.5 rounded-xl px-3 text-[13.5px] font-semibold text-mist-300 hover:bg-white/[.07] hover:text-white">
            <I.logout /> {a.signOut}
          </button>
        </div>
      </aside>

      {nav && <div className="fixed inset-0 z-[65] bg-ink/45 backdrop-blur-sm lg:hidden" onClick={() => setNav(false)} aria-hidden="true" />}

      {/* main */}
      <div className="min-w-0 lg:col-start-2">
        <header className="sticky top-0 z-[60] flex min-h-[64px] items-center gap-3 border-b border-mist-200 bg-white/92 px-4 backdrop-blur-md md:px-7">
          <button className="rounded-lg border border-mist-300 p-2 text-ink lg:hidden" onClick={() => setNav(true)} aria-label="menu"><I.menu /></button>
          <PageTitle a={a} lang={lang} />
          <div className="ms-auto flex items-center gap-2">
            <button onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')}
              className="rounded-full border border-mist-300 px-3 py-1.5 text-[12.5px] font-bold text-[#5A6773] hover:border-ink hover:text-ink">
              {lang === 'fa' ? 'EN' : 'دری'}
            </button>
            <a href="/" target="_blank" rel="noreferrer" className="hidden rounded-full border border-mist-300 px-3.5 py-1.5 text-[12.5px] font-bold text-[#5A6773] hover:border-ink hover:text-ink sm:inline-block">{a.viewSite}</a>
            <button onClick={() => nav_('/admin/account')}
              className="flex items-center gap-2 rounded-full border border-mist-300 py-1 pe-3 ps-1 text-[12.5px] font-bold text-ink hover:border-ink">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-ink text-[12px] text-white">{(me?.name || me?.email || 'A').slice(0, 1).toUpperCase()}</span>
              <span className="hidden max-w-[160px] truncate md:inline">{me?.name || me?.email}</span>
            </button>
          </div>
        </header>
        <main className="p-4 md:p-7">{children}</main>
      </div>
    </div>
  )
}

function PageTitle({ a, lang }) {
  const loc = useLocation()
  const p = loc.pathname.replace(/^\/admin\/?/, '')
  if (p.startsWith('c/')) {
    const c = p.slice(2)
    return <h1 className="text-[17px]">{COLLECTIONS[c]?.label?.[lang] ?? c}</h1>
  }
  const map = { dashboard: a.dashboard, requests: a.requests, settings: a.settings, account: a.account }
  return <h1 className="text-[17px]">{map[p] ?? a.dashboard}</h1>
}

/* ------------------------------------------------------------------ account */
function AccountPage({ a, me, notify }) {
  const [v, setV] = useState({ current: '', next: '', again: '', email: me?.email ?? '' })
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    if (v.next !== v.again) { notify(a.passMismatch, 'err'); return }
    setBusy(true)
    try {
      await api.password({ current: v.current, new: v.next, email: v.email || undefined })
      notify(a.passChanged)
      setV({ current: '', next: '', again: '', email: v.email })
    } catch (e2) { notify(e2.message || a.failed, 'err') } finally { setBusy(false) }
  }

  return (
    <div className="grid max-w-[720px] gap-6">
      <Card>
        <Row label={a.email} value={me?.email} />
        <Row label={a.account} value={me?.name || '—'} />
      </Card>
      <Card title={a.changePass}>
        <form onSubmit={submit} className="grid gap-4">
          <div>
            <label className="label" htmlFor="p-cur">{a.currentPass}</label>
            <input id="p-cur" type="password" required autoComplete="current-password" className="field" dir="ltr"
              value={v.current} onChange={(e) => setV({ ...v, current: e.target.value })} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="p-new">{a.newPass}</label>
              <input id="p-new" type="password" required minLength={10} autoComplete="new-password" className="field" dir="ltr"
                value={v.next} onChange={(e) => setV({ ...v, next: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="p-again">{a.repeatPass}</label>
              <input id="p-again" type="password" required minLength={10} autoComplete="new-password" className="field" dir="ltr"
                value={v.again} onChange={(e) => setV({ ...v, again: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="label" htmlFor="p-mail">{a.notifyEmail}</label>
            <input id="p-mail" type="email" className="field" dir="ltr" value={v.email} onChange={(e) => setV({ ...v, email: e.target.value })} />
          </div>
          <div><button className="btn-coral" disabled={busy}>{busy ? a.saving : a.save}</button></div>
        </form>
      </Card>
    </div>
  )
}

/* ------------------------------------------------------------------ shared bits (exported) */
export function Card({ title, desc, action, children, className = '' }) {
  return (
    <section className={`rounded-card border border-mist-200 bg-white p-5 shadow-card md:p-6 ${className}`}>
      {(title || action) && (
        <header className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            {title && <h2 className="text-[16px]">{title}</h2>}
            {desc && <p className="mt-0.5 text-[13px] text-[#64707C]">{desc}</p>}
          </div>
          {action}
        </header>
      )}
      {children}
    </section>
  )
}

export function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-mist-200 py-2.5 text-[14px] last:border-0">
      <span className="text-[#64707C]">{label}</span>
      <span className="font-semibold text-ink" dir="auto">{value ?? '—'}</span>
    </div>
  )
}

export function Badge({ tone = 'neutral', children }) {
  const tones = {
    neutral: 'bg-mist-100 text-[#5A6773] border-mist-300',
    ok: 'bg-[#E7F5EE] text-ok border-[#BFE4D1]',
    warn: 'bg-brass-pale text-brass-dark border-[#E4C9A4]',
    err: 'bg-[#FBEAEA] text-err border-[#F0C9C9]'
  }
  return <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11.5px] font-bold ${tones[tone]}`}>{children}</span>
}

export function Btn({ tone = 'line', sm, children, ...rest }) {
  const map = { line: 'btn-line', ink: 'btn-ink', coral: 'btn-coral', danger: 'btn-danger' }
  return <button className={`${map[tone]} ${sm ? 'btn-sm' : ''}`} {...rest}>{children}</button>
}

export { useLocation }

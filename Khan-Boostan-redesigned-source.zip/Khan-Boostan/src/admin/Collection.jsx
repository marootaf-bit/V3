import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from './api.js'
import { COLLECTIONS } from './dict.js'
import { Card, Badge, useToast } from './Admin.jsx'
import { I } from '../components/ui.jsx'

const L2 = (v, lang) => (v && typeof v === 'object' ? (v[lang] || v.fa || v.en || '') : (v ?? ''))
const isBi = (v) => v && typeof v === 'object' && !Array.isArray(v) && ('fa' in v || 'en' in v)
const shortDate = (s) => (s ? String(s).slice(0, 10) : '—')

export default function CollectionPage({ a, lang }) {
  const { name } = useParams()
  const meta = COLLECTIONS[name]
  const toast = useToast()
  const [rows, setRows] = useState(null)
  const [err, setErr] = useState('')
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('all')
  const [editing, setEditing] = useState(null)   // {id?, data, _status, _new}
  const [dyn, setDyn] = useState({})             // dynamic select options (collection → rows)
  const [busy, setBusy] = useState(false)

  const load = useCallback(() => {
    setErr(''); setRows(null)
    api.list(name).then(setRows).catch((e) => setErr(e.message))
  }, [name])

  useEffect(() => { load(); setQ(''); setStatus('all'); setEditing(null) }, [name, load])

  /* fetch collections used by dynamic selects */
  useEffect(() => {
    const froms = [...new Set((meta?.fields ?? []).filter((f) => f.from).map((f) => f.from))]
    froms.forEach((c) => { if (!dyn[c]) api.list(c).then((r) => setDyn((d) => ({ ...d, [c]: r }))).catch(() => setDyn((d) => ({ ...d, [c]: [] }))) })
  }, [name]) // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = useMemo(() => {
    if (!rows) return []
    const needle = q.trim().toLowerCase()
    return rows.filter((r) => {
      if (status !== 'all' && r._status !== status) return false
      if (!needle) return true
      return JSON.stringify(r).toLowerCase().includes(needle)
    })
  }, [rows, q, status])

  async function save(payload) {
    setBusy(true)
    try {
      if (payload._new) {
        const r = await api.create(name, { data: payload.data, status: payload._status, id: payload.id || undefined })
        toast(a.saved)
        setEditing(null); load()
        return r
      }
      await api.update(name, payload.id, { data: payload.data, status: payload._status })
      toast(a.saved); setEditing(null); load()
    } catch (e) { toast(e.message || a.failed, 'err') } finally { setBusy(false) }
  }

  async function remove(row) {
    if (!window.confirm(a.confirmDelete)) return
    try { await api.remove(name, row.id); toast(a.deleted); load() } catch (e) { toast(e.message || a.failed, 'err') }
  }

  async function move(i, dir) {
    const next = [...filtered]
    const j = i + dir
    if (j < 0 || j >= next.length) return
    ;[next[i], next[j]] = [next[j], next[i]]
    const ids = next.map((r) => r.id)
    setRows((prev) => {
      const map = new Map(prev.map((r) => [r.id, r]))
      return ids.map((id, k) => ({ ...map.get(id), _sort: k })).concat(prev.filter((r) => !ids.includes(r.id)))
    })
    try { await api.reorder(name, ids) } catch (e) { toast(e.message || a.failed, 'err'); load() }
  }

  async function toggleStatus(row) {
    const next = row._status === 'published' ? 'draft' : 'published'
    try { await api.update(name, row.id, { status: next }); load() } catch (e) { toast(e.message || a.failed, 'err') }
  }

  if (!meta) return <Card><p className="text-[14px] text-err">404</p></Card>

  const blank = () => Object.fromEntries(meta.fields.map((f) => [f.k, f.t === 'bool' ? false : f.t === 'images' || f.t === 'repeat' ? [] : isBiDefault(f) ? { fa: '', en: '' } : '']))
  const isBiDefault = (f) => ['bi', 'bitext'].includes(f.t)

  return (
    <div className="grid gap-5">
      <Card
        title={meta.label[lang]}
        desc={`${rows ? `${rows.length} ${a.items}` : '…'} · ${a.reorderHint}`}
        action={
          <div className="flex flex-wrap items-center gap-2">
            <button className="btn-line btn-sm" onClick={load}>{a.reload}</button>
            <button className="btn-coral btn-sm" onClick={() => setEditing({ _new: true, id: '', data: blank(), _status: 'published' })}>
              <I.plus /> {a.newItem}
            </button>
          </div>
        }>
        {/* toolbar */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div className="relative min-w-[210px] flex-1">
            <I.search className="pointer-events-none absolute top-1/2 -translate-y-1/2 text-[#A7AEB5] ltr:left-3.5 rtl:right-3.5" />
            <input className="field ltr:pl-10 ltr:pr-4 rtl:pr-10 rtl:pl-4" placeholder={a.search} value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="inline-flex rounded-full border border-mist-300 bg-white p-[3px]">
            {['all', 'published', 'draft'].map((s) => (
              <button key={s} onClick={() => setStatus(s)}
                className={`min-h-[36px] rounded-full px-4 text-[13px] font-bold transition-colors ${status === s ? 'bg-ink text-white' : 'text-[#5A6773] hover:text-ink'}`}>
                {s === 'all' ? a.all : s === 'published' ? a.published : a.draft}
              </button>
            ))}
          </div>
        </div>

        {err && <p className="rounded-xl bg-[#FBEAEA] px-4 py-3 text-[13.5px] font-bold text-err">{err}</p>}
        {!rows && !err && <p className="py-6 text-[13.5px] text-[#64707C]">{a.signingIn}</p>}

        {rows && filtered.length === 0 && <p className="py-8 text-center text-[13.5px] text-[#64707C]">{a.empty}</p>}

        {filtered.length > 0 && (
          <ul className="grid gap-2.5">
            {filtered.map((r, i) => {
              const title = L2(r[meta.titleKey], lang) || r.id
              const img = meta.imageKey ? r[meta.imageKey] : null
              return (
                <li key={r.id} className="group flex flex-wrap items-center gap-3 rounded-card border border-mist-200 bg-white p-3 transition-all hover:border-rule-strong hover:shadow-card md:flex-nowrap">
                  <span className="flex shrink-0 flex-col gap-1">
                    <button className="grid h-6 w-6 place-items-center rounded-md border border-mist-300 text-[#64707C] hover:border-ink hover:text-ink disabled:opacity-30"
                      disabled={i === 0} onClick={() => move(i, -1)} aria-label={a.order}><I.up /></button>
                    <button className="grid h-6 w-6 place-items-center rounded-md border border-mist-300 text-[#64707C] hover:border-ink hover:text-ink disabled:opacity-30"
                      disabled={i === filtered.length - 1} onClick={() => move(i, 1)} aria-label={a.order}><I.down /></button>
                  </span>

                  {img
                    ? <span className="h-12 w-16 shrink-0 overflow-hidden rounded-lg border border-mist-200 bg-mist-100"><img src={img} alt="" loading="lazy" className="h-full w-full object-cover" /></span>
                    : <span className="grid h-12 w-16 shrink-0 place-items-center rounded-lg border border-mist-200 bg-mist-100 text-[#C6CCD1]"><I.box /></span>}

                  <span className="min-w-0 flex-1">
                    <button className="block max-w-full truncate text-start text-[14.5px] font-bold text-ink hover:text-brass-dark"
                      onClick={() => setEditing({ id: r.id, data: r, _status: r._status })}>{title}</button>
                    <span className="mt-0.5 flex flex-wrap items-center gap-2 text-[12px] text-[#64707C]">
                      <code className="rounded bg-mist-100 px-1.5 py-0.5 text-[11px]" dir="ltr">{r.id}</code>
                      <span>{a.updated}: {shortDate(r._updated)}</span>
                    </span>
                  </span>

                  <span className="flex shrink-0 flex-wrap items-center gap-1.5">
                    {r.demo && <Badge tone="warn">{a.demoItem}</Badge>}
                    {r.featured && <Badge tone="neutral">{a.featured}</Badge>}
                    <button onClick={() => toggleStatus(r)} title={a.status}>
                      <Badge tone={r._status === 'published' ? 'ok' : 'neutral'}>{r._status === 'published' ? a.published : a.draft}</Badge>
                    </button>
                    <button className="grid h-8 w-8 place-items-center rounded-lg border border-mist-300 text-[#5A6773] hover:border-ink hover:text-ink"
                      onClick={() => setEditing({ id: r.id, data: r, _status: r._status })} aria-label={a.edit}><I.edit /></button>
                    <button className="grid h-8 w-8 place-items-center rounded-lg border border-mist-300 text-[#5A6773] hover:border-err hover:text-err"
                      onClick={() => remove(r)} aria-label={a.del}><I.trash /></button>
                  </span>
                </li>
              )
            })}
          </ul>
        )}
      </Card>

      {editing && (
        <Editor a={a} lang={lang} meta={meta} dyn={dyn} item={editing} busy={busy}
          onClose={() => setEditing(null)} onSave={save} />
      )}
    </div>
  )
}

/* ------------------------------------------------------------------ editor */
function Editor({ a, lang, meta, dyn, item, busy, onClose, onSave }) {
  const [id, setId] = useState(item.id ?? '')
  const [st, setSt] = useState(item._status ?? 'published')
  const [data, setData] = useState(() => {
    const d = {}
    for (const f of meta.fields) d[f.k] = item.data?.[f.k] ?? (f.t === 'bool' ? false : f.t === 'images' || f.t === 'repeat' ? [] : ['bi', 'bitext'].includes(f.t) ? { fa: '', en: '' } : '')
    return d
  })
  const [extraOpen, setExtraOpen] = useState(false)
  const [extra, setExtra] = useState(() => {
    const known = new Set(meta.fields.map((f) => f.k).concat(['id', '_status', '_sort', '_updated']))
    const rest = Object.fromEntries(Object.entries(item.data ?? {}).filter(([k]) => !known.has(k)))
    return JSON.stringify(rest, null, 2)
  })
  const [extraErr, setExtraErr] = useState('')
  const dirty = useRef(false)

  const set = (k, v) => { dirty.current = true; setData((d) => ({ ...d, [k]: v })) }

  function close() {
    if (dirty.current && !window.confirm(a.unsaved + ' — ' + a.close + '?')) return
    onClose()
  }

  function submit(e) {
    e.preventDefault()
    let rest = {}
    try { rest = extra.trim() ? JSON.parse(extra) : {} ; setExtraErr('') } catch { setExtraErr(a.invalidJson); return }
    onSave({ _new: !!item._new, id: id.trim(), _status: st, data: { ...data, ...rest } })
  }

  useEffect(() => {
    const h = (e) => { if (e.key === 'Escape') close() }
    window.addEventListener('keydown', h)
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', h); document.body.style.overflow = '' }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="fixed inset-0 z-[80] flex justify-end" role="dialog" aria-modal="true" aria-label={a.edit}>
      <div className="absolute inset-0 bg-ink/45 backdrop-blur-sm" onClick={close} aria-hidden="true" />
      <form onSubmit={submit} className="relative flex h-full w-full max-w-[760px] flex-col bg-mist-100 shadow-panel ltr:ml-auto rtl:mr-auto">
        <header className="flex min-h-[64px] shrink-0 items-center gap-3 border-b border-mist-200 bg-white px-5">
          <h2 className="text-[16px]">{item._new ? a.newItem : a.edit}</h2>
          <span className="text-[12.5px] text-[#64707C]">{meta.label[lang]}</span>
          <div className="ms-auto flex items-center gap-2">
            <div className="inline-flex rounded-full border border-mist-300 p-[3px]">
              {['published', 'draft'].map((s) => (
                <button type="button" key={s} onClick={() => { dirty.current = true; setSt(s) }}
                  className={`min-h-[32px] rounded-full px-3.5 text-[12.5px] font-bold ${st === s ? (s === 'published' ? 'bg-ok text-white' : 'bg-ink text-white') : 'text-[#5A6773]'}`}>
                  {s === 'published' ? a.published : a.draft}
                </button>
              ))}
            </div>
            <button type="button" className="grid h-9 w-9 place-items-center rounded-lg border border-mist-300 text-[#5A6773] hover:border-ink hover:text-ink" onClick={close} aria-label={a.close}><I.x /></button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-5">
          <div className="grid gap-5">
            {item._new && (
              <div className="rounded-card border border-mist-200 bg-white p-4">
                <label className="label" htmlFor="e-id">ID / slug ({a.none})</label>
                <input id="e-id" className="field" dir="ltr" value={id} onChange={(e) => { dirty.current = true; setId(e.target.value) }} placeholder="auto" />
              </div>
            )}

            {meta.fields.map((f) => (
              <Field key={f.k} a={a} lang={lang} f={f} value={data[f.k]} dyn={dyn}
                onChange={(v) => set(f.k, v)} />
            ))}

            <details className="rounded-card border border-mist-200 bg-white p-4" open={extraOpen} onToggle={(e) => setExtraOpen(e.target.open)}>
              <summary className="cursor-pointer text-[13.5px] font-bold text-ink">{a.editJson}</summary>
              <textarea className="field mt-3 font-mono !text-[12.5px]" dir="ltr" rows="10" value={extra} onChange={(e) => { dirty.current = true; setExtra(e.target.value) }} />
              {extraErr && <p className="mt-2 text-[12.5px] font-bold text-err">{extraErr}</p>}
            </details>
          </div>
        </div>

        <footer className="flex shrink-0 items-center gap-3 border-t border-mist-200 bg-white px-5 py-4">
          <button type="submit" className="btn-coral" disabled={busy}>{busy ? a.saving : a.save}</button>
          <button type="button" className="btn-line" onClick={close}>{a.cancel}</button>
        </footer>
      </form>
    </div>
  )
}

/* ------------------------------------------------------------------ fields */
function Field({ a, lang, f, value, onChange, dyn }) {
  const wrap = (children) => (
    <div className="group rounded-card border border-mist-200 bg-white p-4">
      <div className="mb-2.5 flex items-center justify-between gap-3">
        <span className="text-[13.5px] font-bold text-ink">{f.label[lang]}{f.req && <span className="text-brass"> *</span>}</span>
        <span className="font-mono text-[10.5px] text-[#C6CCD1] opacity-0 transition-opacity group-hover:opacity-100" dir="ltr">{f.k}:{f.t}</span>
      </div>
      {children}
    </div>
  )

  switch (f.t) {
    case 'bi':
      return wrap(
        <div className="grid gap-3 sm:grid-cols-2">
          <BiInput value={value} onChange={onChange} which="fa" a={a} />
          <BiInput value={value} onChange={onChange} which="en" a={a} dir="ltr" />
        </div>
      )
    case 'bitext':
      return wrap(
        <div className="grid gap-3">
          <BiInput value={value} onChange={onChange} which="fa" a={a} textarea rows={4} />
          <BiInput value={value} onChange={onChange} which="en" a={a} textarea rows={3} dir="ltr" />
        </div>
      )
    case 'text':
      return wrap(<input className="field" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />)
    case 'textarea':
      return wrap(<textarea className="field resize-y" rows="4" value={value ?? ''} onChange={(e) => onChange(e.target.value)} />)
    case 'date':
      return wrap(<input type="date" className="field" dir="ltr" value={String(value ?? '').slice(0, 10)} onChange={(e) => onChange(e.target.value)} />)
    case 'bool':
      return wrap(
        <button type="button" role="switch" aria-checked={!!value} onClick={() => onChange(!value)}
          className={`inline-flex items-center gap-2.5 rounded-full border px-3 py-1.5 text-[13px] font-bold transition-colors ${value ? 'border-ok bg-[#E7F5EE] text-ok' : 'border-mist-300 bg-mist-50 text-[#64707C]'}`}>
          <span className={`h-4 w-7 rounded-full p-[2px] transition-colors ${value ? 'bg-ok' : 'bg-mist-300'}`}>
            <span className={`block h-3 w-3 rounded-full bg-white transition-transform ${value ? 'translate-x-3 rtl:-translate-x-3' : ''}`} />
          </span>
          {value ? a.yes : a.no}
        </button>
      )
    case 'select': {
      const opts = f.opts ?? (dyn[f.from] ?? []).map((r) => ({ v: r.id, l: r[f.labelKey] ?? r.id }))
      return wrap(
        <select className="field" value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
          <option value="">{a.none}</option>
          {opts.map((o, i) => <option key={i} value={o.v ?? o}>{L2(o.l ?? o, lang)}</option>)}
        </select>
      )
    }
    case 'image':
      return wrap(<ImagePicker a={a} value={value} onChange={onChange} />)
    case 'file':
      return wrap(<ImagePicker a={a} kind="file" value={value} onChange={onChange} />)
    case 'images':
      return wrap(<ImagesPicker a={a} lang={lang} value={Array.isArray(value) ? value : []} onChange={onChange} />)
    case 'repeat':
      return wrap(<Repeater a={a} lang={lang} spec={f} value={Array.isArray(value) ? value : []} onChange={onChange} dyn={dyn} />)
    case 'json':
      return wrap(<textarea className="field resize-y font-mono !text-[12.5px]" dir="ltr" rows="6"
        value={typeof value === 'string' ? value : JSON.stringify(value ?? {}, null, 2)}
        onChange={(e) => { try { onChange(JSON.parse(e.target.value)) } catch { /* keep typing */ } }} />)
    default:
      return wrap(<input className="field" value={String(value ?? '')} onChange={(e) => onChange(e.target.value)} />)
  }
}

function BiInput({ value, onChange, which, a, textarea, rows = 3, dir }) {
  const v = isBi(value) ? (value[which] ?? '') : (which === 'fa' ? (value ?? '') : '')
  const set = (x) => onChange(isBi(value) || value === '' || value == null ? { ...(isBi(value) ? value : { fa: '', en: '' }), [which]: x } : { fa: value, en: x })
  const label = which === 'fa' ? a.fa : a.en
  return (
    <label className="block">
      <span className="mb-1 block text-[11.5px] font-bold text-[#A7AEB5]">{label}</span>
      {textarea
        ? <textarea className="field resize-y" rows={rows} dir={dir} value={v} onChange={(e) => set(e.target.value)} />
        : <input className="field" dir={dir} value={v} onChange={(e) => set(e.target.value)} />}
    </label>
  )
}

function ImagePicker({ a, value, onChange, kind }) {
  const [busy, setBusy] = useState(false)
  const ref = useRef(null)
  const isFile = kind === 'file'

  async function pick(e) {
    const f = e.target.files?.[0]
    if (!f) return
    setBusy(true)
    try {
      const r = await api.upload(f, isFile ? 'file' : undefined)
      onChange(r.url)
    } catch (err) { window.alert(err.message || a.failed) } finally { setBusy(false); if (ref.current) ref.current.value = '' }
  }

  return (
    <div className="flex flex-wrap items-center gap-4">
      {value
        ? (isFile
          ? <a href={value} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl border border-mist-300 px-3 py-2 text-[12.5px] font-bold text-ink hover:border-ink" dir="ltr"><I.doc /> {String(value).split('/').pop()}</a>
          : <img src={value} alt="" className="h-20 w-28 rounded-xl border border-mist-200 object-cover" />)
        : <span className="grid h-20 w-28 place-items-center rounded-xl border border-dashed border-mist-300 bg-mist-50 text-[#C6CCD1]">{isFile ? <I.doc /> : <I.box />}</span>}
      <div className="min-w-[200px] flex-1">
        <input className="field mb-2" dir="ltr" placeholder={a.url} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" className="btn-line btn-sm" onClick={() => ref.current?.click()} disabled={busy}>
            {busy ? a.uploading : a.upload}
          </button>
          {value && <button type="button" className="btn-line btn-sm" onClick={() => onChange('')}>{a.removeRow}</button>}
          <span className="text-[11.5px] text-[#A7AEB5]">{isFile ? a.fileHint : a.imageHint}</span>
        </div>
        <input ref={ref} type="file" className="hidden" accept={isFile ? 'application/pdf' : 'image/*'} onChange={pick} />
      </div>
    </div>
  )
}

function ImagesPicker({ a, value, onChange }) {
  const [busy, setBusy] = useState(false)
  const ref = useRef(null)
  const list = value.filter((v) => typeof v === 'string')

  async function pick(e) {
    const files = [...(e.target.files ?? [])]
    if (!files.length) return
    setBusy(true)
    try {
      const urls = []
      for (const f of files) urls.push((await api.upload(f)).url)
      onChange([...list, ...urls])
    } catch (err) { window.alert(err.message || a.failed) } finally { setBusy(false); if (ref.current) ref.current.value = '' }
  }

  return (
    <div>
      <ul className="mb-3 grid grid-cols-3 gap-2.5 sm:grid-cols-4">
        {list.map((u, i) => (
          <li key={i} className="group relative aspect-[4/3] overflow-hidden rounded-xl border border-mist-200">
            <img src={u} alt="" loading="lazy" className="h-full w-full object-cover" />
            <button type="button" onClick={() => onChange(list.filter((_, k) => k !== i))}
              className="absolute top-1.5 grid h-7 w-7 place-items-center rounded-full bg-ink/80 text-white opacity-0 transition-opacity group-hover:opacity-100 ltr:right-1.5 rtl:left-1.5"
              aria-label={a.removeRow}><I.x className="h-3.5 w-3.5" /></button>
          </li>
        ))}
      </ul>
      <div className="flex flex-wrap items-center gap-2">
        <button type="button" className="btn-line btn-sm" onClick={() => ref.current?.click()} disabled={busy}>{busy ? a.uploading : a.upload}</button>
        <input className="field max-w-[280px]" dir="ltr" placeholder={a.url}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); const v = e.target.value.trim(); if (v) { onChange([...list, v]); e.target.value = '' } } }} />
        <span className="text-[11.5px] text-[#A7AEB5]">{a.imageHint}</span>
      </div>
      <input ref={ref} type="file" multiple className="hidden" accept="image/*" onChange={pick} />
    </div>
  )
}

function Repeater({ a, lang, spec, value, onChange, dyn }) {
  const blankRow = () => Object.fromEntries(spec.fields.map((f) => [f.k, ['bi', 'bitext'].includes(f.t) ? { fa: '', en: '' } : f.t === 'bool' ? false : '']))
  return (
    <div className="grid gap-3">
      {value.map((row, i) => (
        <div key={i} className="rounded-xl border border-mist-200 bg-mist-50 p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[12px] font-bold text-[#64707C]">#{i + 1}</span>
            <button type="button" className="grid h-7 w-7 place-items-center rounded-lg border border-mist-300 bg-white text-[#5A6773] hover:border-err hover:text-err"
              onClick={() => onChange(value.filter((_, k) => k !== i))} aria-label={a.removeRow}><I.trash /></button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {spec.fields.map((sf) => (
              <Field key={sf.k} a={a} lang={lang} f={sf} dyn={dyn} value={row?.[sf.k]}
                onChange={(v) => onChange(value.map((r, k) => (k === i ? { ...r, [sf.k]: v } : r)))} />
            ))}
          </div>
        </div>
      ))}
      <button type="button" className="btn-line btn-sm justify-self-start" onClick={() => onChange([...value, blankRow()])}><I.plus /> {a.addRow}</button>
    </div>
  )
}

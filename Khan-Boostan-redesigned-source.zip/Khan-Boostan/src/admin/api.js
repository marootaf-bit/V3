/* Khan Boostan admin API client (session cookie based) */
const BASE = '/api'
const JSON_H = { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }

export class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status }
}

async function call(path, { method = 'GET', body, form } = {}) {
  const init = { method, credentials: 'same-origin' }
  if (form) { init.body = form; init.headers = { 'X-Requested-With': 'fetch' } }
  else if (body !== undefined) { init.body = JSON.stringify(body); init.headers = JSON_H }
  else if (method !== 'GET') init.headers = JSON_H
  const r = await fetch(`${BASE}/${path}`, init)
  let data = null
  try { data = await r.json() } catch { /* empty */ }
  if (!r.ok) throw new ApiError(r.status, data?.error || `HTTP ${r.status}`)
  return data
}

export const api = {
  /* auth */
  login: (email, password) => call('admin/login', { method: 'POST', body: { email, password } }),
  logout: () => call('admin/logout', { method: 'POST' }),
  me: () => call('admin/me'),
  password: (payload) => call('admin/password', { method: 'POST', body: payload }),

  /* dashboard */
  stats: () => call('admin/stats'),

  /* collections */
  list: (c) => call(`admin/collections/${c}`),
  create: (c, payload) => call(`admin/collections/${c}`, { method: 'POST', body: payload }),
  update: (c, id, payload) => call(`admin/collections/${c}/${encodeURIComponent(id)}`, { method: 'PUT', body: payload }),
  remove: (c, id) => call(`admin/collections/${c}/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  reorder: (c, ids) => call(`admin/collections/${c}/reorder`, { method: 'POST', body: { ids } }),

  /* requests */
  requests: (status) => call(`admin/requests${status && status !== 'all' ? `?status=${status}` : ''}`),
  setRequestStatus: (id, status) => call(`admin/requests/${id}`, { method: 'PATCH', body: { status } }),
  removeRequest: (id) => call(`admin/requests/${id}`, { method: 'DELETE' }),

  /* settings */
  settings: () => call('admin/settings'),
  saveSettings: (payload) => call('admin/settings', { method: 'PUT', body: payload }),

  /* uploads */
  upload: async (file, kind) => {
    const fd = new FormData()
    fd.append('file', file)
    return call(`admin/upload${kind ? `?kind=${kind}` : ''}`, { method: 'POST', form: fd })
  }
}

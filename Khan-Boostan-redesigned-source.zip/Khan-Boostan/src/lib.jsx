import { useLang } from '../src/lib/store.jsx'
import { useContext, createContext, useMemo } from 'react'
import dict from './dict.json'

const DictCtx = createContext(null)

export function DictProvider({ children }) {
  const { lang } = useLang()
  const value = useMemo(() => ({ dict, lang }), [lang])
  return <DictCtx.Provider value={value}>{children}</DictCtx.Provider>
}

export function usePublicDict() {
  const ctx = useContext(DictCtx)
  if (!ctx) return { lang: 'fa', t: (key) => key, L: (value, fallback = '') => publicText(typeof value === 'string' ? value : (value?.fa ?? value?.en ?? fallback)) }
  const { dict, lang } = ctx
  const t = (key, fallback) => dict?.[lang]?.[key] ?? dict?.fa?.[key] ?? fallback ?? key
  const L = (value, fallback = '') => {
    const localize = (candidate) => typeof candidate === 'string' ? publicText(candidate) : candidate
    if (value == null) return localize(fallback)
    if (typeof value === 'string') return localize(value)
    return localize(value?.[lang] ?? value?.fa ?? value?.en ?? fallback)
  }
  return { lang, t, L }
}

// Keep the full editable CMS dataset available to public pages. Public copy helpers below
// remove editorial labels from rendered text; they do not delete or reject source records.
export const publicRecords = (items = []) => Array.isArray(items) ? items.filter(Boolean) : []
export const publicVerifiedRecords = publicRecords
export const publicCatalogueProducts = publicRecords
export const publicFaqs = publicRecords
export const publicNews = publicRecords
export function useDict() { return usePublicDict() }

const INTERNAL_PHRASE = /(?:\bpreview\b|\bplaceholder\b|\bpending confirmation\b|\bconfirm before publication\b|\b(?:not a real|not verified|not confirmed|unverified)\b|\b(?:sample|illustrative|demo)\s+(?:data|entry|item|record|content|news item|vacancy|case study|case|market list|catalogue entry|profile sample|quote|faq|need|action|result)\b|\b(?:created only to test|written to evaluate|replace with (?:the )?(?:real|verified)|will be added after|add .* after (?:company )?confirmation|only after (?:company )?confirmation|must be confirmed before publication)\b|پیش‌نمایش|نسخهٔ? آزمایشی|محتوای نمونه|نمونهٔ? نمایشی|رکورد نمایشی|نیازمند تأیید|در انتظار تأیید|پس از تأیید|تا تأیید|پیش از نشر|پیش از انتشار|جایگزین شود|درج شود|درج خواهد شد|بعد از تأیید|تأیید رسمی|\b(?:add|insert|upload|replace|enter)\b.{0,100}\b(?:after|once)\s+(?:company\s+)?(?:approval|confirmation|review)\b|\b(?:will be (?:removed|hidden|replaced|added|uploaded|listed|published)|to be (?:replaced|added|uploaded|listed|published))\b|\b(?:sample|illustrative) agreement\b|\b(?:to evaluate|to test|for testing)\s+(?:the )?(?:site|page|design|layout|structure|typography)\b|\b(?:real|verified|final)\s+(?:text|content|details|data)\b.{0,100}\b(?:will|must|should)\s+(?:replace|be replaced|be added|be uploaded)\b|\b(?:scope|details|information|role|biography|profile|address|office hours)\b.{0,80}\bafter\s+(?:company\s+)?(?:confirmation|approval)\b|\b(?:will be|is to be)\s+(?:added|listed|published|replaced)\s+after\s+(?:company\s+)?(?:confirmation|approval)\b|نسخهٔ? نهایی.{0,100}(?:جایگزین|درج|اضافه)|پس از دریافت.{0,100}(?:نمونه|حذف|پنهان)|برای آزمایش ساختار (?:سایت|صفحه)|(?:جایگزین می‌شود|جایگزین خواهد شد|حذف یا پنهان می‌شود|پس از تصویب)|پاراگراف سوم برای بررسی تایپوگرافی|فاصلهٔ خطوط، عرض متن و خوانایی در موبایل|\bservices such as .{0,160}\bonly when (?:the )?company actually provides them\b|\b(?:for|to) evaluating\b.{0,100}\b(?:site|page|design|layout|structure)\b|\b(?:to test|for testing)\s+(?:line wrapping|wrapping|long text|card alignment|responsive layout|the cards? layout)\b|\b(?:this )?(?:entry|item|record)\s+(?:only\s+)?tests?\b|\b(?:detail headings?|card alignment|desktop|mobile)\b|\b(?:each|every|real) product page\b.{0,160}\b(?:shows|displays|includes)\b.{0,160}\b(?:in this layout|in this page|in this design)\b|\b(?:to|for)\s+(?:show|demonstrate)\b.{0,100}\b(?:page|site|layout|structure|mobile|desktop|category)\b|\bfor (?:the )?(?:food|agricultural|construction|machinery|household|textile) category\b|\bverify\b.{0,100}\bbefore publication\b|\b(?:specifications?|details|content)\b.{0,100}\b(?:illustrative|sample)\s+only\b|\b(?:the )?real (?:licen[cs]e|image|file)\b.{0,100}\b(?:added|uploaded|inserted|placed)\b|\breplace (?:the )?(?:name|relationship|country|business area|details|text|image|record)\b.{0,100}\b(?:confirmed|verified|permission)\b|\b(?:confirm|verify|upload|insert|add)\b.{0,100}\b(?:before|after|once)\s+(?:company\s+)?(?:approval|confirmation|review|publication)\b|محصول واقعی شرکت نیست|به محصول واقعی اشاره ندارد|مشخصات زیر نمونه است|برای ارزیابی طراحی سایت|در صفحهٔ? هر محصول واقعی.{0,160}(?:نمایش داده می‌شود|به همین شکل)|فایل واقعی.{0,100}(?:بارگذاری|درج|اضافه|قرار می‌گیرد)|برای آزمایش سایت|برای آزمایش صفحهٔ? فرصت‌های شغلی|برای آزمایش متن‌های بلند|برای آزمایش شکستن خط|برای آزمایش چیدمان|برای نمایش ساختار (?:صفحه|سایت)|برای نمایش دستهٔ? محصولات|نمونهٔ? بست)/iu

const CLAUSE_BOUNDARY = /(\s*[,،;؛:—–-]\s*|\s+(?:and|but|or|yet|while|although|however|whereas|و|اما|ولی|بلکه|یا)\s+)/giu

function cleanSentence(sentence) {
  const text = sentence.trim()
  if (!text) return text

  const ending = text.match(/[.!?؟۔]+$/u)?.[0] ?? ''
  const body = ending ? text.slice(0, -ending.length) : text
  const marker = body.match(INTERNAL_PHRASE)
  if (!marker) return text
  if (marker.index === 0 && marker[0].length >= body.trim().length * 0.7) return ''
  const parts = body.split(CLAUSE_BOUNDARY)
  let result = ''
  let joiner = ''
  let removedSinceLastKept = false
  let firstKept = true

  for (let index = 0; index < parts.length; index += 2) {
    const clause = (parts[index] ?? '').trim()
    const separator = parts[index + 1] ?? ' '
    if (!clause) continue
    if (INTERNAL_PHRASE.test(clause)) {
      removedSinceLastKept = true
      joiner = separator
      continue
    }
    if (result) {
      const connector = /(?:\band\b|\bbut\b|\bor\b|\byet\b|\bwhile\b|\balthough\b|\bhowever\b|\bwhereas\b|\sو\s|\sاما\s|\sولی\s|\sبلکه\s|\sیا\s)/iu.test(joiner)
      result += removedSinceLastKept ? (connector ? joiner.trim() + ' ' : ' ') : (joiner || ' ')
    }
    result += firstKept && removedSinceLastKept ? clause.replace(/^([a-z])/u, (letter) => letter.toUpperCase()) : clause
    firstKept = false
    removedSinceLastKept = false
    joiner = separator
  }

  return result ? `${result}${ending}` : ''
}

function cleanParagraph(paragraph) {
  return paragraph.split(/(?<=[.!?؟۔])\s+/u).map(cleanSentence).filter(Boolean).join(' ')
}

export function cleanDemoText(value) {
  if (Array.isArray(value)) return value.map(cleanDemoText).filter(Boolean)
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, cleanDemoText(item)]))
  if (typeof value !== 'string') return value
  return value.split(/\n{2,}/).map((paragraph) => cleanParagraph(paragraph.trim())).filter(Boolean).join('\n\n')
}

function stripEditorialLabels(value) {
  if (typeof value !== 'string') return value
  return value
    .replace(/\b(?:this|that) is\s+(?:a\s+)?(?:sample|demo|illustrative)\s+(?:item|entry|record|content)(?:\s+(?:only|copy|text|content))?\b[.!?؟۔]*/giu, '')
    .replace(/\s*[([{]\s*(?:sample|demo|illustrative|preview|placeholder|نمونه(?:ی|ٔ)?(?:\s+(?:نمایشی|آزمایشی))?)\s*[)\]}]/giu, ' ')
    .replace(/\b(?:sample|illustrative|demo)\s+(?:item|entry|record|data|content|news item|vacancy|case study|case|market list|catalogue entry|profile sample|quote|faq|need|action|result|agreement|job|product|project|news|title|video|image|document|origin)\b(?:\s+(?:only|copy|text|content))?\s*[:：]?\s*/giu, '')
    .replace(/\b(?:illustrative|demo)\s+(?:company[- ]profile|profile|certificate|record)\s+sample\b\s*[:：;؛—–-]?\s*/giu, '')
    .replace(/(?:نمونهٔ? نمایشی|نمونهٔ? آزمایشی|محتوای نمونه|رکورد نمایشی|مورد نمایشی|نسخهٔ? آزمایشی|نسخهٔ? نمونه|جایگاه نمونه|نیاز نمونه|اقدام نمونه|نتیجهٔ? نمونه|توافق نمونه|نمونهٔ? بست|بست نمونه|خبر نمونه|ویدیوی نمونه|تصویر نمونه)\s*[:：؛—–-]?\s*/gu, '')
    .replace(/(برند|مشتری|شرکت|تأمین‌کننده|شریک|نمایندگی|عضو تیم|عضو|بست|محصول|کالا|خبر|پروژه|ویدیو|تصویر)\s+نمونه(?:ی|ٔ)?(?=\s+\d)/gu, '$1')
    .replace(/(?:^|\s)(?:نمونه|نمونهٔ|نمونهی)(?=\s+\d)/gu, ' ')
    .replace(/(?:^|\s)(?:sample|demo|illustrative)(?=\s+[0-9٠-٩])/giu, ' ')
    .replace(/\b(?:illustrative|demo)\b[^.;\n]{0,60}\bsample\b\s*(?=[;:：—–-])/giu, '')
    .replace(/(^|\n)[ \t]*[—–-][ \t]*/gu, '$1')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/[ \t]+([,.;:!?؟،؛])/gu, '$1')
}

export function publicText(value) {
  if (typeof value !== 'string') return cleanDemoText(value)
  return cleanDemoText(stripEditorialLabels(value))
    .split(/\n{2,}/)
    .map((paragraph) => paragraph.trim())
    .filter((paragraph) => paragraph && !/^[\s.,;:!?؟۔،؛—–-]+$/u.test(paragraph))
    .join('\n\n')
}

export function publicItemName(value) {
  if (value == null) return ''
  const withoutSampleLabel = String(value)
    .replace(/\s*[([{]\s*(?:demo|sample|illustrative|preview|placeholder|نمونه(?:ی|ٔ)?(?:\s+(?:نمایشی|آزمایشی))?)\s*[)\]}]/giu, ' ')
    .replace(/(?:^|\s)(?:demo|sample|illustrative|preview|placeholder|نمونه(?:ی|ٔ)?(?:\s+(?:نمایشی|آزمایشی))?)(?=\s|$)/giu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  return String(publicText(withoutSampleLabel) ?? '').replace(/\s+/g, ' ').trim()
}

export function publicItemSummary(item, L, lang) {
  for (const raw of [item?.short, item?.summary, item?.description]) {
    if (raw == null) continue
    const text = String(publicText(L(raw, '')) ?? '').trim()
    if (text) return text
  }
  return ''
}

export function publicItemDescription(item, L, lang) {
  for (const raw of [item?.description, item?.body, item?.summary, item?.short]) {
    if (raw == null) continue
    const text = String(publicText(L(raw, '')) ?? '').trim()
    if (text) return text
  }
  return ''
}

export function publicSlug(value) {
  return String(value ?? '').toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '')
}

export function publicBrandLabel(item, L) {
  const value = item?.name ?? item?.label ?? ''
  return publicItemName(L(value, ''))
}

export function relationshipKind(item) {
  const kind = String(item?.kind ?? item?.relationType ?? '').toLowerCase()
  return ['agency', 'partner', 'supplier', 'client', 'brand', 'affiliate'].includes(kind) ? kind : ''
}

export function publicTeamName(member, L) {
  return publicItemName(L(member?.name, ''))
}

export function publicJobSummary(job, L) {
  return String(publicText(L(job?.summary ?? job?.description, '')) ?? '').trim()
}

export function publicJobBody(job, L) {
  return String(publicText(L(job?.body ?? job?.description, '')) ?? '').trim()
}

export function publicDocumentDescription(document, L) {
  return String(publicText(L(document?.description ?? '', '')) ?? '').trim()
}

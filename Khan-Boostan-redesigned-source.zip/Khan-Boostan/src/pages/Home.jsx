import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicNews, publicRecords } from '../lib.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import HomeHero from '../components/public/HomeHero.jsx'
import HomePathways from '../components/public/HomePathways.jsx'
import HomeSnapshot from '../components/public/HomeSnapshot.jsx'
import HomeIntro from '../components/public/HomeIntro.jsx'
import HomeCategories from '../components/public/HomeCategories.jsx'
import HomePrinciples from '../components/public/HomePrinciples.jsx'
import HomeProcess from '../components/public/HomeProcess.jsx'
import HomeProjects from '../components/public/HomeProjects.jsx'
import HomeRelationships from '../components/public/HomeRelationships.jsx'
import HomeNews from '../components/public/HomeNews.jsx'
import HomeGallery from '../components/public/HomeGallery.jsx'
import HomeProfile from '../components/public/HomeProfile.jsx'
import HomeContact from '../components/public/HomeContact.jsx'

const STEPS = {
  fa: [
    ['۰۱', 'درخواست و شناخت نیاز', 'گفتگو با مشتری یا شرکت، تعیین مشخصات و مقدار', '/images/news-meeting.webp'],
    ['۰۲', 'بررسی و تأمین', 'انتخاب تأمین‌کننده بر اساس اصول مشخص، اعلام شفاف قیمت و شرایط', '/images/trade-warehouse.webp'],
    ['۰۳', 'هماهنگی و آماده‌سازی', 'کنترل کیفیت و بسته‌بندی، تکمیل اسناد', '/images/trade-detail.webp'],
    ['۰۴', 'انتقال و تحویل', 'پیگیری تا تحویل، اطلاع‌رسانی روشن', '/images/trade-highway.webp'],
  ],
  en: [
    ['01', 'Request & scoping', 'Talk with the client, agree specifications and quantity', '/images/news-meeting.webp'],
    ['02', 'Review & sourcing', 'Choose suppliers on clear principles, transparent pricing', '/images/trade-warehouse.webp'],
    ['03', 'Coordination & prep', 'Quality control, packing and documents', '/images/trade-detail.webp'],
    ['04', 'Shipping & delivery', 'Follow-up until delivery, clear updates', '/images/trade-highway.webp'],
  ],
}

function timestampOf(value) {
  const timestamp = Date.parse(value ?? '')
  return Number.isFinite(timestamp) ? timestamp : null
}

export default function Home() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  if (!data) return <PublicLoading />

  const fa = lang !== 'en'
  const company = settings.company ?? {}
  const hero = settings.hero ?? {}
  const sections = settings.sections ?? {}
  const home = settings.home ?? {}
  const products = [...(data.products ?? []).filter((item) => Boolean(L(item.name)))].sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || bySort(a, b))
  const categories = (data.categories ?? []).filter((item) => Boolean(L(item.name)))
  const categoryName = (id) => L(categories.find((item) => item.id === id)?.name)
  const partnerRecords = publicRecords(data.partners ?? [])
  const homePartnerIds = ['demo-partner-1', 'demo-supplier-1', 'demo-supplier-2', 'demo-client-1', 'demo-partner-x0', 'demo-partner-x1', 'demo-supplier-x2', 'demo-supplier-x3', 'demo-client-x6', 'demo-client-2']
  const partners = homePartnerIds.map((id) => partnerRecords.find((item) => item.id === id)).filter(Boolean)
  const allNews = [...publicNews(data.news ?? [])].filter((item) => Boolean(L(item.title))).sort((a, b) => {
    const dateA = timestampOf(a.date)
    const dateB = timestampOf(b.date)
    if (dateA === null && dateB !== null) return 1
    if (dateB === null && dateA !== null) return -1
    if (dateA !== null && dateB !== null && dateA !== dateB) return dateB - dateA
    return bySort(a, b)
  })
  const featuredStory = allNews.find((item) => item.featured) ?? allNews[0]
  const recentStories = allNews.filter((item) => item.id !== featuredStory?.id).slice(0, 2)
  const projects = [...publicRecords(data.projects ?? [])].filter((item) => Boolean(L(item.title))).sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || bySort(a, b))
  const featuredCases = projects.filter((item) => item.featured).slice(0, 3)
  const galleryItems = [...publicRecords(data.gallery ?? [])].filter((item) => Boolean(item.image || item.poster)).sort(bySort)
  const profile = sections.showDownloads !== false ? publicRecords(data.documents ?? []).find((doc) => doc.kind === 'profile' && doc.file && Boolean(L(doc.title))) : null
  const steps = STEPS[fa ? 'fa' : 'en']
  const heroImage = hero.image || '/images/hero-trade.webp'
  const heroTitleSource = L(hero.title, L(company.name))
  const heroTitle = fa
    ? heroTitleSource.replace(/^خان بوستان[؛,:،]\s*/, '').trim()
    : heroTitleSource.replace(/^Khan Boostan:\s*/i, '').replace(/\band\s+international\s+trade\b/i, '& international trade').replace(/\bimport,\s*export\b/i, 'Import, Export').replace(/\binternational\s+trade\b/i, 'International Trade').replace(/^([a-z])/, (letter) => letter.toUpperCase()).trim()
  const pathways = [
    { key: 'import', type: 'import', to: '/import', title: L(settings.pages?.import?.title, fa ? 'واردات کالا' : 'Import goods'), copy: L(settings.pages?.import?.intro, fa ? 'تأمین کالا از بازارهای خارجی برای تاجران، شرکت‌ها و پروژه‌ها در افغانستان.' : 'Sourcing goods from foreign markets for traders, companies and projects in Afghanistan.'), image: '/images/trade-warehouse.webp' },
    { key: 'export', type: 'export', to: '/export', title: L(settings.pages?.export?.title, fa ? 'صادرات محصولات' : 'Export products'), copy: L(settings.pages?.export?.intro, fa ? 'رساندن محصولات افغانستان به بازارهای منطقه و جهان.' : 'Bringing Afghan products to regional and international markets.'), image: '/images/trade-cargo.webp' },
    { key: 'sourcing', type: 'sourcing', to: '/activities', title: fa ? 'تأمین و تجارت بین‌المللی' : 'Sourcing & international trade', copy: L(settings.activities?.sourcing, fa ? 'در صورت درخواست مشتری، کالای مشخصی را از بازارهای مختلف شناسایی، قیمت‌گیری و تأمین می‌کنیم.' : 'At a customer’s request, we identify, price and source specific goods from different markets.'), image: '/images/trade-port.webp' },
  ]
  const snapshot = sections.showFacts === false ? { ...home, markets: [], highlights: [] } : home
  const introSummary = fa
    ? 'خان بوستان یک شرکت تجارتی است که در دو حوزهٔ اصلی فعالیت می‌کند: واردات کالا به افغانستان و صادرات محصولات داخلی به بازارهای خارجی.'
    : 'Khan Boostan is a trading company active in two main areas: importing goods into Afghanistan and exporting domestic products to foreign markets.'
  return <main id="main" className="tw-home-page tw-flex-1">
    <HomeHero image={heroImage} title={heroTitle} summary={L(hero.text, L(company.summary))} fa={fa} />
    <HomePathways pathways={pathways} fa={fa} t={t} intro={t('trade_intro_d')} />
    <HomeSnapshot home={snapshot} L={L} fa={fa} lang={lang} heroImage={heroImage} />
    <HomeIntro summary={introSummary} approach={L(company.approach)} fa={fa} />
    {sections.showProducts !== false && <HomeCategories categories={categories} products={products} categoryName={categoryName} L={L} fa={fa} lang={lang} />}
    <HomePrinciples principles={company.principles ?? []} L={L} fa={fa} />
    <HomeProcess steps={steps} fa={fa} />
    {sections.showProjects !== false && <HomeProjects projects={featuredCases} L={L} fa={fa} lang={lang} t={t} />}
    {sections.showPartners !== false && <HomeRelationships partners={partners} fa={fa} lang={lang} t={t} L={L} />}
    <HomeProfile profile={profile} L={L} lang={lang} fa={fa} t={t} />
    {sections.showNews !== false && <HomeNews featuredStory={featuredStory} recentStories={recentStories} cases={[]} lang={lang} fa={fa} L={L} t={t} />}
    {sections.showGallery !== false && <HomeGallery items={galleryItems} fa={fa} lang={lang} L={L} t={t} />}
    <HomeContact contact={settings.contact ?? {}} lang={lang} t={t} L={L} />
  </main>
}

import { Link } from 'react-router-dom'
import { usePublicDict } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'

const text = (value, lang) => typeof value === 'string' ? value : value?.[lang === 'en' ? 'en' : 'fa'] ?? ''
const formatNumber = (value, lang) => {
  const digits = String(value).padStart(2, '0')
  return lang === 'en' ? digits : digits.replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)])
}

const GUIDE = {
  title: { fa: 'راهنمای آمادگی تجارت', en: 'Trade readiness guide' },
  intro: {
    fa: 'راهنمایی کاربردی برای آماده‌سازی درخواست‌های واردات، صادرات و تأمین کالا؛ با تأکید بر معلومات روشن، بررسی موردی و توافق کتبی.',
    en: 'A practical guide to preparing import, export and sourcing enquiries, with an emphasis on clear information, case-by-case review and written agreement.',
  },
  contentsTitle: { fa: 'بخش‌های راهنما', en: 'Guide sections' },
  groupNavLabel: { fa: 'رفتن به گروه موضوعی', en: 'Jump to a topic group' },
  topicsLabel: { fa: 'فهرست موضوع‌های این بخش', en: 'Topics in this group' },
  topicCount: { fa: '۵ موضوع', en: '5 topics' },
  groups: [
    {
      id: 'trade-guide-management',
      title: { fa: 'مدیریت، کیفیت و اعتماد', en: 'Management, quality & trust' },
      intro: {
        fa: 'این بخش به روشن‌سازی مسئولیت‌ها و اطلاعات لازم برای مدیریت یک درخواست تجارتی کمک می‌کند.',
        en: 'These topics help clarify responsibilities and the information needed to manage a trade enquiry.',
      },
      items: [
        {
          id: 'trade-guide-01',
          title: { fa: 'مراحل رسیدگی به درخواست', en: 'Enquiry handling stages' },
          lead: {
            fa: 'برای جلوگیری از برداشت متفاوت، درخواست را از شناخت نیاز تا توافق نهایی به گام‌های روشن تقسیم کنید.',
            en: 'To reduce misunderstandings, divide an enquiry into clear steps, from understanding the need through to final agreement.',
          },
          points: {
            fa: ['کالا، مشخصات، مقدار و مقصد را ثبت کنید.', 'امکان تهیه و شرایط را برای همان درخواست بررسی کنید.', 'پیشنهاد، مسئولیت‌ها و هر تغییر را پیش از اقدام کتبی سازید.'],
            en: ['Record the goods, specifications, quantity and destination.', 'Review availability and terms for that specific enquiry.', 'Put the offer, responsibilities and any changes in writing before proceeding.'],
          },
          href: '/process',
          action: { fa: 'دیدن روند همکاری', en: 'View cooperation process' },
        },
        {
          id: 'trade-guide-02',
          title: { fa: 'شاخص‌های کیفیت خدمات', en: 'Service quality indicators' },
          lead: {
            fa: 'شاخص‌ها زمانی برای مشتری مفیدند که تعریف، دورهٔ محاسبه و منبع دادهٔ آن‌ها روشن باشد.',
            en: 'Service indicators are useful only when their definitions, reporting period and data source are clear.',
          },
          points: {
            fa: ['زمان پاسخ به درخواست و زمان آماده‌شدن پیشنهاد را جدا بسنجید.', 'تکمیل سفارش و حل مشکل را با معیار تعریف‌شده گزارش کنید.', 'تاریخ، روش محاسبه و محدودهٔ هر شاخص را کنار عدد بنویسید.'],
            en: ['Measure enquiry response and quotation preparation separately.', 'Report order completion and issue resolution against defined criteria.', 'Show the date, calculation method and scope beside each figure.'],
          },
        },
        {
          id: 'trade-guide-03',
          title: { fa: 'کیفیت و بازرسی کالا', en: 'Product quality & inspection' },
          lead: {
            fa: 'پیش از معامله دربارهٔ معیار پذیرش کالا و مدارکی که برای بررسی کیفیت لازم است توافق کنید.',
            en: 'Before a transaction, agree on product acceptance criteria and the evidence needed to assess quality.',
          },
          points: {
            fa: ['در صورت نیاز، مشخصات، درجه یا نمونهٔ مرجع را تعریف کنید.', 'مشخص سازید بازرسی را چه کسی و در کدام مرحله انجام می‌دهد.', 'مسئولیت هزینه، گزارش و رسیدگی به تفاوت‌ها را کتبی کنید.'],
            en: ['Define specifications, grade or a reference sample when relevant.', 'Agree who arranges inspection and at which stage.', 'Record responsibility for costs, reports and handling discrepancies.'],
          },
        },
        {
          id: 'trade-guide-04',
          title: { fa: 'مدیریت خطر و خرید مسئولانه', en: 'Risk management & responsible sourcing' },
          lead: {
            fa: 'پیش از تعهد، طرف معامله، منشأ کالا، محدودیت‌های بازار و خطرهای حمل و پرداخت را بررسی کنید.',
            en: 'Before making a commitment, review the counterparty, product origin, market restrictions and payment and transport risks.',
          },
          points: {
            fa: ['هویت و اختیار طرف معامله را از راه مناسب بررسی کنید.', 'محدودیت‌های قانونی، تحریم‌ها و تضاد منافع را جدی بگیرید.', 'در صورت امکان، منشأ کالا و معیارهای کار و محیط‌زیست را مستند سازید.'],
            en: ['Use appropriate checks to confirm the counterparty’s identity and authority.', 'Consider legal restrictions, sanctions and conflicts of interest.', 'Where possible, document product origin and relevant labour or environmental standards.'],
          },
        },
        {
          id: 'trade-guide-05',
          title: { fa: 'رسیدگی به شکایت و اختلاف', en: 'Handling complaints & discrepancies' },
          lead: {
            fa: 'گزارش دقیق و به‌موقع، بررسی مشکل را ساده‌تر می‌سازد؛ قرارداد و اسناد معامله مبنای رسیدگی‌اند.',
            en: 'A precise, timely report makes an issue easier to review; the transaction agreement and records are the starting point.',
          },
          points: {
            fa: ['شمارهٔ سفارش یا موضوع، تاریخ و شرح کوتاه مشکل را آماده کنید.', 'در صورت نیاز، تصویر یا سند پشتیبان و اقدام درخواستی را ذکر کنید.', 'مکاتبه و پاسخ‌ها را برای پیگیری نزد خود نگه دارید.'],
            en: ['Include the order or enquiry reference, date and a concise description.', 'Where relevant, attach supporting evidence and state the resolution requested.', 'Keep correspondence and responses for follow-up.'],
          },
          href: '/contact',
          action: { fa: 'رفتن به تماس', en: 'Open contact page' },
        },
      ],
    },
    {
      id: 'trade-guide-marketing',
      title: { fa: 'بازاریابی و درخواست مشتری', en: 'Marketing & customer enquiries' },
      intro: {
        fa: 'محتوای بازاریابی مؤثر باید به نیاز مخاطب پاسخ بدهد و ادعاهایش با شواهد قابل بررسی همراه باشد.',
        en: 'Useful marketing content answers a visitor’s needs and supports its claims with verifiable evidence.',
      },
      items: [
        {
          id: 'trade-guide-06',
          title: { fa: 'شناخت نوع درخواست‌کننده', en: 'Understand the enquiry type' },
          lead: {
            fa: 'اطلاعات را بر اساس نیاز بازدیدکننده و نوع درخواست مرتب کنید.',
            en: 'Organize information around visitor needs and enquiry types.',
          },
          points: {
            fa: ['خریدار وارداتی معمولاً مشخصات و مقصد را می‌خواهد.', 'صادرکننده باید دربارهٔ محصول، مقدار و بازار هدف معلومات بدهد.', 'درخواست پروژه‌ای ممکن است به مقدار، معیار فنی و زمان‌بندی نیاز داشته باشد.'],
            en: ['An import buyer usually needs to specify the goods and destination.', 'An exporter should describe the product, quantity and target market.', 'A project enquiry may need quantities, technical criteria and timing.'],
          },
        },
        {
          id: 'trade-guide-07',
          title: { fa: 'راهنمای انتخاب مسیر تجارتی', en: 'Choose a trade pathway' },
          lead: {
            fa: 'بازدیدکننده را از همان آغاز به مسیر مرتبط هدایت کنید تا درخواستش روشن‌تر ثبت شود.',
            en: 'Help visitors find the relevant pathway early so their enquiry is clearer.',
          },
          points: {
            fa: ['برای تهیهٔ کالا از بازار بیرونی، صفحهٔ واردات را ببینید.', 'برای رساندن محصول داخلی به بازار بیرونی، صفحهٔ صادرات را ببینید.', 'برای کالای مشخص، نوع درخواست و منبع‌یابی را در متن پیام شرح دهید.'],
            en: ['For goods sourced from an overseas market, start with the import page.', 'For domestic products intended for an overseas market, start with export.', 'For a specific sourcing request, describe the product and sourcing need in your message.'],
          },
          href: '/activities',
          action: { fa: 'دیدن فعالیت‌ها', en: 'View trade activities' },
        },
        {
          id: 'trade-guide-08',
          title: { fa: 'درخواست قیمت روشن (RFQ)', en: 'Prepare a clear request for quotation' },
          lead: {
            fa: 'درخواست کامل، رفت‌وبرگشت پرسش‌ها را کم می‌کند و بررسی نیاز را آسان‌تر می‌سازد.',
            en: 'A complete request reduces avoidable follow-up and helps clarify the requirement.',
          },
          points: {
            fa: ['نام کالا، مشخصات، کیفیت و بسته‌بندی موردنظر را بنویسید.', 'مقدار، کشور یا شهر مبدأ و مقصد و تاریخ موردنیاز را مشخص کنید.', 'مدارک، معیارها یا شرایط ویژه را در پیام ذکر نمایید.'],
            en: ['Name the goods and state specifications, grade and preferred packaging.', 'Include quantity, origin and destination, and required date.', 'Mention any required documents, standards or special terms.'],
          },
          href: '/contact?kind=product',
          action: { fa: 'آغاز درخواست کالا', en: 'Start a product enquiry' },
        },
        {
          id: 'trade-guide-09',
          title: { fa: 'اطلاعیه‌های بازار و خبرنامه', en: 'Market updates & newsletter' },
          lead: {
            fa: 'برای هر مطلب بازار، محدودهٔ جغرافیایی، تاریخ بررسی و منبع را آشکار سازید.',
            en: 'For every market update, show the geography covered, review date and source.',
          },
          points: {
            fa: ['دادهٔ تاریخ‌دار و منبع قابل بررسی را از نظر تجارتی تفسیر کنید.', 'میان واقعیت، تحلیل و دیدگاه تفاوت بگذارید.', 'عضویت خبرنامه فقط با رضایت روشن و روش لغو عضویت فعال شود.'],
            en: ['Use dated, traceable sources and explain their trade relevance.', 'Distinguish facts from analysis and opinion.', 'Enable newsletter sign-up only with clear consent and an unsubscribe method.'],
          },
          href: '/news',
          action: { fa: 'دیدن خبرها و رسانه‌ها', en: 'View news & media' },
        },
        {
          id: 'trade-guide-10',
          title: { fa: 'مطالعهٔ موردی مستند', en: 'Documented case studies' },
          lead: {
            fa: 'یک مطالعهٔ موردی خوب، نقش شرکت و نتیجهٔ مستند را از ادعاهای عمومی جدا می‌سازد.',
            en: 'A useful case study separates the company’s role and documented result from broad claims.',
          },
          points: {
            fa: ['چالش، نقش، راه‌حل و نتیجه را با اجازهٔ طرف‌های مربوط بیان کنید.', 'از تاریخ، مقدار یا نتیجهٔ قابل تأیید استفاده کنید.', 'نام و اسناد حساس را بدون اجازه منتشر نکنید.'],
            en: ['Describe the challenge, role, approach and result with relevant parties’ permission.', 'Use dates, quantities and outcomes that can be verified.', 'Do not publish sensitive names or documents without permission.'],
          },
          href: '/projects',
          action: { fa: 'دیدن پرونده‌های تجارتی', en: 'View trade cases' },
        },
      ],
    },
    {
      id: 'trade-guide-trade',
      title: { fa: 'آمادگی واردات، صادرات و اسناد', en: 'Import, export & documentation readiness' },
      intro: {
        fa: 'چک‌لیست‌ها نقطهٔ آغاز گفتگو هستند؛ مدارک و مقررات نهایی به کالا، مبدأ، مقصد و قرارداد وابسته‌اند.',
        en: 'These checklists are a starting point; final documents and rules depend on the product, origin, destination and contract.',
      },
      items: [
        {
          id: 'trade-guide-11',
          title: { fa: 'چک‌لیست پیش از واردات', en: 'Import preparation checklist' },
          lead: {
            fa: 'پیش از درخواست قیمت، مشخصات موردنیاز کالا و مقصد را تا حد امکان روشن کنید.',
            en: 'Before requesting a quotation, clarify the product requirements and destination as far as possible.',
          },
          points: {
            fa: ['نام دقیق، درجه، ترکیب یا مشخصات فنی کالا را آماده کنید.', 'مقدار، بسته‌بندی، مقصد و زمان تقریبی موردنیاز را بنویسید.', 'شرط‌های ورود یا معیارهای خاص بازار مقصد را جداگانه بررسی کنید.'],
            en: ['Prepare the exact product name, grade, composition or technical specification.', 'State quantity, packaging, destination and approximate required date.', 'Check any entry conditions or market-specific standards separately.'],
          },
          href: '/import',
          action: { fa: 'دیدن صفحهٔ واردات', en: 'View import information' },
        },
        {
          id: 'trade-guide-12',
          title: { fa: 'چک‌لیست آمادگی صادرات', en: 'Export readiness checklist' },
          lead: {
            fa: 'برای سنجش آمادگی اولیه، اطلاعات محصول، ظرفیت و بازار هدف را کنار هم بیاورید.',
            en: 'For an initial readiness review, bring product, supply and target-market information together.',
          },
          points: {
            fa: ['مبدأ و توضیح محصول و اسناد منشأ موجود را مشخص کنید.', 'مقدار قابل عرضه، فصل‌مندی، درجه و نوع بسته‌بندی را بنویسید.', 'معیارها، برچسب و مدارک لازم در بازار هدف را بررسی کنید.'],
            en: ['State origin, product description and any available origin records.', 'Describe available volume, seasonality, grade and packaging.', 'Check standards, labels and documents required in the target market.'],
          },
          href: '/export',
          action: { fa: 'دیدن صفحهٔ صادرات', en: 'View export information' },
        },
        {
          id: 'trade-guide-13',
          title: { fa: 'راهنمای اسناد تجارتی', en: 'Trade document guide' },
          lead: {
            fa: 'پیش از ارسال کالا، فهرست اسناد موردنیاز را با طرف معامله و کارگزار مربوط تطبیق کنید.',
            en: 'Before shipping, confirm the required documents with the counterparty and relevant broker.',
          },
          points: {
            fa: ['پیش‌فاکتور و فاکتور تجارتی، فهرست بسته‌بندی و اسناد حمل را بشناسید.', 'گواهی مبدأ، مجوز یا گواهی محصول را فقط در صورت نیاز همان مسیر بررسی کنید.', 'نام، مقدار، ارزش و شرح کالا را میان اسناد هماهنگ نگه دارید.'],
            en: ['Understand the roles of a pro forma/commercial invoice, packing list and transport documents.', 'Check origin, permit or product certificates only as required for the specific route.', 'Keep product descriptions, quantities and values consistent across records.'],
          },
          href: '/downloads',
          action: { fa: 'رفتن به مرکز دانلودها', en: 'Open download centre' },
        },
        {
          id: 'trade-guide-14',
          title: { fa: 'اصطلاحات تحویل و Incoterms', en: 'Delivery terms & Incoterms' },
          lead: {
            fa: 'شرط تحویل بر تقسیم مسئولیت، هزینه و خطر میان فروشنده و خریدار اثر می‌گذارد.',
            en: 'A delivery term affects how responsibilities, costs and risk are divided between seller and buyer.',
          },
          points: {
            fa: ['نام شرط، مکان یا بندر دقیق و نسخهٔ مورد توافق را در قرارداد بنویسید.', 'مسئولیت حمل، بیمه، ترخیص و انتقال خطر را برای همان شرط بررسی کنید.', 'پیش از امضا، عبارت قرارداد را با کارشناس تجارت یا حقوق تطبیق دهید.'],
            en: ['State the exact term, named place or port and agreed edition in the contract.', 'Check who handles transport, insurance, clearance and transfer of risk under that term.', 'Have contract wording reviewed by an appropriate trade or legal professional.'],
          },
        },
        {
          id: 'trade-guide-15',
          title: { fa: 'گمرک و مقررات بازار مقصد', en: 'Customs & destination-market rules' },
          lead: {
            fa: 'الزام‌های ورود و خروج را برای همان کالا و مسیر از منبع رسمی و به‌روز بررسی کنید.',
            en: 'Check import and export requirements for the specific product and route using current official sources.',
          },
          points: {
            fa: ['طبقه‌بندی کالا، محصول محدودشده، مجوز و معیارهای فنی را بررسی کنید.', 'عوارض و مالیات را از منبع رسمی همان کشور یا کارگزار مجاز بپرسید.', 'تاریخ بررسی و منبع هر معلومات را یادداشت کنید.'],
            en: ['Check product classification, restricted goods, permits and technical standards.', 'Confirm duties and taxes with the relevant official source or authorized broker.', 'Record the review date and source for each requirement.'],
          },
        },
      ],
    },
    {
      id: 'trade-guide-supply',
      title: { fa: 'محصول، عرضه‌کننده و زنجیرهٔ تأمین', en: 'Products, suppliers & supply chain' },
      intro: {
        fa: 'جزئیات محصول و زنجیرهٔ تأمین باید قابل بررسی و به‌روز باشد؛ موارد نامعلوم را بهتر است نامعلوم نشان بدهیم.',
        en: 'Product and supply-chain details should be traceable and current; unknown fields should remain clearly marked as unknown.',
      },
      items: [
        {
          id: 'trade-guide-16',
          title: { fa: 'جدول مشخصات و مقایسهٔ محصولات', en: 'Product specification & comparison table' },
          lead: {
            fa: 'مقایسهٔ ساختاریافته به خریدار کمک می‌کند گزینه‌ها را بر اساس معیارهای یکسان بررسی کند.',
            en: 'A structured comparison helps buyers review options against consistent criteria.',
          },
          points: {
            fa: ['مشخصات فنی، درجه، بسته‌بندی و واحد اندازه‌گیری را ثبت کنید.', 'مبدأ، مقدار قابل عرضه یا حداقل سفارش را فقط با سند درج نمایید.', 'تاریخ آخرین تأیید و وضعیت موجودی را در صورت دسترسی نشان دهید.'],
            en: ['Record specifications, grade, packaging and unit of measure.', 'Publish origin, available quantity or minimum order only when documented.', 'Show last verification date and availability status when known.'],
          },
          href: '/products',
          action: { fa: 'دیدن کاتالوگ محصولات', en: 'View product catalogue' },
        },
        {
          id: 'trade-guide-17',
          title: { fa: 'ارزیابی و معرفی عرضه‌کننده', en: 'Supplier introduction & qualification' },
          lead: {
            fa: 'پیش از آغاز همکاری، اطلاعات شرکت عرضه‌کننده و توانایی تأمین را به شکل منظم بررسی کنید.',
            en: 'Before cooperation, review the supplier’s identity and supply capability in a structured way.',
          },
          points: {
            fa: ['نام قانونی، کشور مبدأ و راه تماس کاری را آماده کنید.', 'مشخصات، ظرفیت، بسته‌بندی و اسناد محصول را ارائه نمایید.', 'گواهی‌ها یا معرفی‌نامه‌ها را فقط در صورت اعتبار و اجازه شریک سازید.'],
            en: ['Provide the legal name, country of origin and business contact details.', 'Share product specifications, capacity, packaging and relevant records.', 'Share certificates or references only when valid and authorized.'],
          },
          href: '/contact?kind=cooperation',
          action: { fa: 'تماس دربارهٔ همکاری', en: 'Enquire about cooperation' },
        },
        {
          id: 'trade-guide-18',
          title: { fa: 'بسته‌بندی، برچسب و معیار کیفیت', en: 'Packaging, labels & quality requirements' },
          lead: {
            fa: 'بسته‌بندی و برچسب باید با نوع کالا، مسیر حمل و بازار مقصد سازگار باشد.',
            en: 'Packaging and labels should suit the product, transport route and destination market.',
          },
          points: {
            fa: ['مواد بسته‌بندی، وزن خالص و ناخالص و تعداد واحد را مشخص کنید.', 'زبان، اطلاعات محصول، شمارهٔ دسته و تاریخ را مطابق بازار مقصد بررسی کنید.', 'برای مواد غذایی یا کالاهای حساس، معیارهای ویژه را از مرجع رسمی بپرسید.'],
            en: ['Specify packaging material, net/gross weight and units per package.', 'Check language, product details, batch number and dates for the destination market.', 'For food or sensitive goods, confirm special rules with the relevant authority.'],
          },
        },
        {
          id: 'trade-guide-19',
          title: { fa: 'برنامه‌ریزی حمل و تحویل', en: 'Transport & delivery planning' },
          lead: {
            fa: 'پیش از تعهد، عوامل مسیر، روش حمل، هزینه و مسئولیت‌ها را با طرف‌های مربوط بررسی کنید.',
            en: 'Before committing, review route, transport mode, costs and responsibilities with the relevant parties.',
          },
          points: {
            fa: ['مبدأ، مقصد، نوع کالا، وزن و حجم تقریبی را مشخص کنید.', 'حمل، بیمه، انبارداری و ترخیص را بر اساس شرط تحویل بررسی کنید.', 'مراحل پیگیری و کسی را که اطلاع‌رسانی می‌کند از پیش توافق نمایید.'],
            en: ['State origin, destination, product type, approximate weight and volume.', 'Review transport, insurance, storage and clearance under the agreed delivery term.', 'Agree on tracking milestones and who will provide updates.'],
          },
        },
        {
          id: 'trade-guide-20',
          title: { fa: 'پرداخت و تمویل تجارت', en: 'Payment & trade finance' },
          lead: {
            fa: 'شرایط پرداخت را پیش از سفارش روشن سازید تا هزینه، ارز و مسئولیت هر طرف معلوم باشد.',
            en: 'Clarify payment terms before ordering so costs, currency and each party’s responsibilities are understood.',
          },
          points: {
            fa: ['ارز، روش پرداخت، زمان‌بندی و هزینه‌های بانکی را بررسی کنید.', 'نقش بانک‌ها و شرایط ابزارهای مالی را با بانک یا مشاور مجاز بسنجید.', 'روش پرداخت و مسئولیت هر طرف را در قرارداد مکتوب سازید.'],
            en: ['Review currency, payment method, timing and banking charges.', 'Discuss banks and finance instruments with a bank or qualified adviser.', 'Record each party’s payment responsibilities in the agreement.'],
          },
          href: '/contact?kind=product',
          action: { fa: 'پرسش دربارهٔ شرایط معامله', en: 'Ask about transaction terms' },
        },
      ],
    },
  ],
}

export default function TradeGuide() {
  const { lang } = usePublicDict()
  const fa = lang !== 'en'
  const currentLang = fa ? 'fa' : 'en'

  return <main id="main" className="tw-flex-1">
    <Hero
      image="/images/trade-detail.webp"
      crumbs={[["/activities", fa ? 'فعالیت‌های تجارتی' : 'Trade activities'], [null, text(GUIDE.title, currentLang)]]}
      title={text(GUIDE.title, currentLang)}
      sub={text(GUIDE.intro, currentLang)}
      compact
    />

    <section className="tw-bg-kb-paper tw-py-7 sm:tw-py-10" aria-label={fa ? 'فهرست موضوع‌های راهنما' : 'Guide contents'}>
      <SiteContainer className="tw-max-w-6xl">
        <nav className="tw-mt-5" aria-label={text(GUIDE.groupNavLabel, currentLang)}>
          <h2 className="tw-mb-3 tw-text-xs tw-font-bold tw-text-kb-muted">{text(GUIDE.contentsTitle, currentLang)}</h2>
          <ul className="tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-4">
            {GUIDE.groups.map((group) => <li key={group.id}>
              <a href={`#${group.id}`} className="tw-flex tw-h-full tw-min-h-20 tw-items-center tw-justify-between tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 tw-text-start tw-transition-colors hover:tw-border-kb-blue/50 hover:tw-bg-kb-paper motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">
                <span className="tw-font-bold tw-text-kb-navy">{text(group.title, currentLang)}</span>
                <span className="tw-shrink-0 tw-rounded-full tw-bg-kb-paper tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-muted">{text(GUIDE.topicCount, currentLang)}</span>
              </a>
            </li>)}
          </ul>
        </nav>
      </SiteContainer>
    </section>

    {GUIDE.groups.map((group, groupIndex) => <section id={group.id} key={group.id} className={`tw-scroll-mt-24 tw-py-9 sm:tw-py-12 ${groupIndex % 2 ? 'tw-bg-white' : 'tw-bg-kb-paper'}`} aria-labelledby={`${group.id}-title`}>
      <SiteContainer className="tw-max-w-6xl">
        <div className="tw-max-w-3xl">
          <span className="tw-text-[10px] tw-font-bold tw-tracking-[.12em] tw-text-kb-blue">{formatNumber(groupIndex + 1, currentLang)} · {text(GUIDE.topicCount, currentLang)}</span>
          <h2 id={`${group.id}-title`} className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{text(group.title, currentLang)}</h2>
          <p className="tw-mt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{text(group.intro, currentLang)}</p>
        </div>
        <nav className="tw-mt-5 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4" aria-label={`${text(GUIDE.topicsLabel, currentLang)}: ${text(group.title, currentLang)}`}>
          <ul className="tw-flex tw-flex-wrap tw-gap-2">
            {group.items.map((item, index) => <li key={item.id}><a href={`#${item.id}`} className="tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-rounded-full tw-border tw-border-kb-line tw-bg-kb-paper tw-px-3 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><span className="tw-text-kb-blue">{formatNumber(groupIndex * 5 + index + 1, currentLang)}</span><span>{text(item.title, currentLang)}</span></a></li>)}
          </ul>
        </nav>
        <div className="tw-mt-4 tw-grid tw-gap-3 lg:tw-grid-cols-2">
          {group.items.map((item, index) => <article id={item.id} key={item.id} className="tw-scroll-mt-28 tw-flex tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-p-6" aria-labelledby={`${item.id}-title`}>
            <div className="tw-flex tw-items-start tw-gap-3">
              <span className="tw-flex tw-h-9 tw-w-9 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-bg-kb-paper tw-text-xs tw-font-bold tw-text-kb-blue">{formatNumber(groupIndex * 5 + index + 1, currentLang)}</span>
              <h3 id={`${item.id}-title`} className="tw-pt-1 tw-font-head tw-text-lg tw-font-bold tw-leading-6 tw-text-kb-navy">{text(item.title, currentLang)}</h3>
            </div>
            <p className="tw-mt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{text(item.lead, currentLang)}</p>
            <ul className="tw-mt-3 tw-grid tw-gap-2">
              {item.points[currentLang].map((point) => <li key={point} className="tw-flex tw-items-start tw-gap-2 tw-text-sm tw-leading-6 tw-text-kb-body"><span className="tw-mt-2 tw-h-1.5 tw-w-1.5 tw-shrink-0 tw-rounded-full tw-bg-kb-gold" aria-hidden="true" /><span>{point}</span></li>)}
            </ul>
            {item.href && <Link to={item.href} className="tw-mt-4 tw-inline-flex tw-min-h-10 tw-w-fit tw-items-center tw-gap-2 tw-rounded-kb tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><span>{text(item.action, currentLang)}</span><ArrowIcon size={15} /></Link>}
          </article>)}
        </div>
      </SiteContainer>
    </section>)}
  </main>
}

import { useEffect, useMemo, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords, publicBrandLabel, relationshipKind } from '../lib.jsx'
import CompanyHero from '../components/CompanyHero.jsx'
import CompanyLoading from '../components/CompanyLoading.jsx'
import RelationSection from '../components/public/RelationSection.jsx'
import BrandSection from '../components/public/BrandSection.jsx'
import PartnersApproach from '../components/public/PartnersApproach.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import JsonLd from '../components/public/JsonLd.jsx'

const COPY = {
  fa: {
    agency: 'نمایندگی رسمی', partner: 'شریک تجارتی', supplier: 'تأمین‌کننده', client: 'مشتری',
    affiliate: 'شرکت وابسته', brand: 'برند عرضه‌شده', brands: 'برندهای عرضه‌شده',
    brandsNote: 'در این بخش با برندها و حوزه‌های عرضه آشنا شوید.', field: 'حوزهٔ فعالیت', website: 'وب‌سایت',
    contact: 'پیشنهاد همکاری دارید؟', contactNote: 'معرفی شرکت، زمینهٔ فعالیت و پیشنهاد خود را برای ما بفرستید.',
    searchLabel: 'جست‌وجوی رابطه‌ها', searchPlaceholder: 'نام، کشور یا حوزهٔ فعالیت',
    typeFilter: 'نوع رابطه', allTypes: 'همهٔ نوع‌ها', sortLabel: 'مرتب‌سازی', sortName: 'نام: الف تا ی', sortCountry: 'کشور: الف تا ی',
    clearFilters: 'پاک‌کردن فیلترها', noMatches: 'رابطه‌ای با این جست‌وجو پیدا نشد.',
    brandCategoryLabel: 'دسته‌بندی برند', allCategories: 'همهٔ دسته‌ها', brandNoMatches: 'در این دسته برندی ثبت نشده است.',
    opensNewTab: 'در برگهٔ تازه باز می‌شود', sourceLabel: 'منبع', permissionLabel: 'اطلاعات نشر', verifiedOn: 'تاریخ',
    detail: 'جزئیات رابطه', askAbout: 'پرسش دربارهٔ همکاری',
  },
  en: {
    agency: 'Official agency', partner: 'Trade partner', supplier: 'Supplier', client: 'Client',
    affiliate: 'Affiliated company', brand: 'Brand offered', brands: 'Brands offered',
    brandsNote: 'Explore the brands and supply areas featured here.', field: 'Business area', website: 'Website',
    contact: 'Want to propose cooperation?', contactNote: 'Send us your company profile, field of activity and proposal.',
    searchLabel: 'Search relationships', searchPlaceholder: 'Name, country or business area',
    typeFilter: 'Relationship type', allTypes: 'All types', sortLabel: 'Sort by', sortName: 'Name: A to Z', sortCountry: 'Country: A to Z',
    clearFilters: 'Clear filters', noMatches: 'No relationships match this search.',
    brandCategoryLabel: 'Brand category', allCategories: 'All categories', brandNoMatches: 'No brands are listed in this category.',
    opensNewTab: 'Opens in a new tab', sourceLabel: 'Source', permissionLabel: 'Publication details', verifiedOn: 'Date',
    detail: 'Relationship details', askAbout: 'Ask about cooperation',
  },
}

const SECTION_META = {
  agency: ['agency', 'agencies'], partner: ['partner', 'trade-partners'], supplier: ['supplier', 'suppliers'],
  client: ['client', 'clients'], brand: ['brand', 'brand-relations'], affiliate: ['affiliate', 'affiliates'],
}
const ORDER = ['agency', 'partner', 'supplier', 'client', 'brand', 'affiliate']
const SAFE_RELATION_KINDS = new Set(ORDER)

function getPublicOrigin() {
  return typeof window === 'undefined' ? '' : window.location.origin
}

export default function Partners() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const { hash } = useLocation()
  const fa = lang !== 'en'
  const c = COPY[fa ? 'fa' : 'en']
  const [search, setSearch] = useState('')
  const [kindFilter, setKindFilter] = useState('all')
  const [sort, setSort] = useState('name')
  const [brandCategory, setBrandCategory] = useState('all')
  const categories = publicRecords(data?.categories ?? [])
  const entries = publicRecords(data?.partners ?? []).filter((item) => Boolean(L(item.name)))
  const allBrands = [...publicRecords(data?.brands ?? [])].filter((item) => Boolean(publicBrandLabel(item, L, lang, categories))).sort(bySort)
  const shown = settings?.sections?.showPartners !== false
  const locale = fa ? 'fa' : 'en'

  const filteredEntries = useMemo(() => {
    const query = search.trim().toLocaleLowerCase(locale)
    return entries.filter((entry) => {
      const kind = relationshipKind(entry)
      if (kindFilter !== 'all' && kind !== kindFilter) return false
      if (!query) return true
      return [L(entry.name), L(entry.country), L(entry.field)].some((value) => String(value ?? '').toLocaleLowerCase(locale).includes(query))
    }).sort((a, b) => {
      const primaryA = sort === 'country' ? L(a.country) : L(a.name)
      const primaryB = sort === 'country' ? L(b.country) : L(b.name)
      return String(primaryA ?? '').localeCompare(String(primaryB ?? ''), locale) || bySort(a, b)
    })
  }, [entries, search, kindFilter, sort, L, locale])

  const grouped = ORDER.map((kind) => ({
    kind,
    id: SECTION_META[kind][1],
    title: c[SECTION_META[kind][0]],
    items: filteredEntries.filter((entry) => relationshipKind(entry) === kind),
  })).filter((section) => section.items.length)
  const brandCategories = categories.filter((category) => allBrands.some((item) => item.category === category.id))
  const filteredBrands = allBrands.filter((item) => brandCategory === 'all' || item.category === brandCategory)
  const hasRelationshipFilters = Boolean(search.trim() || kindFilter !== 'all' || sort !== 'name')
  const origin = getPublicOrigin()
  const pageUrl = origin ? `${origin}/partners` : ''
  const orgName = L(settings.company?.legal) || L(settings.company?.name)
  const schema = pageUrl && orgName ? {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'Organization', '@id': `${origin}/#organization`, name: orgName, url: origin, logo: `${origin}/brand/khan-boostan-official.png` },
      { '@type': 'CollectionPage', '@id': `${pageUrl}#webpage`, url: pageUrl, name: t('nav_partners'), description: t('partners_d'), about: { '@id': `${origin}/#organization` } },
      { '@type': 'BreadcrumbList', '@id': `${pageUrl}#breadcrumb`, itemListElement: [
        { '@type': 'ListItem', position: 1, name: t('home'), item: origin },
        { '@type': 'ListItem', position: 2, name: t('nav_about'), item: `${origin}/about` },
        { '@type': 'ListItem', position: 3, name: t('nav_partners'), item: pageUrl },
      ] },
    ],
  } : null

  useEffect(() => {
    if (!hash || !shown) return
    const id = hash.slice(1)
    const frame = requestAnimationFrame(() => {
      const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'
      document.getElementById(id)?.scrollIntoView({ behavior, block: 'start' })
    })
    return () => cancelAnimationFrame(frame)
  }, [hash, shown, data])

  if (!data) return <CompanyLoading lang={lang} />
  return <main id="main" className="tw-flex-1">
    {schema && <JsonLd value={schema} />}
    <CompanyHero image="/images/trade-documents.webp" imageSet="/images/trade-documents-sm.webp 640w, /images/trade-documents-md.webp 1024w, /images/trade-documents.webp 1600w" width={1600} height={1067} title={t('nav_partners')} summary={t('partners_d')} crumbs={[{ label: t('nav_about'), to: '/about' }, { label: t('nav_partners') }]} compact />
    {shown ? <>
      <PartnersApproach text={L(settings.company?.approach)} fa={fa} />
      {(grouped.length > 0 || allBrands.length > 0) && <section className="tw-border-y tw-border-kb-line tw-bg-white tw-py-4" aria-label={fa ? 'فهرست روابط تجارتی' : 'Trade relationship index'}><SiteContainer className="tw-flex tw-items-center tw-gap-3"><span className="tw-flex tw-shrink-0 tw-flex-col tw-text-[11px] tw-font-bold tw-text-kb-muted"><span>{fa ? 'پرش به:' : 'Jump to:'}</span><small className="tw-text-[9px] tw-font-normal tw-text-kb-muted sm:tw-hidden">{fa ? 'افقی بکشید' : 'Swipe'}</small></span><nav className="tw-min-w-0 tw-flex-1 tw-overflow-x-auto tw-py-1" tabIndex={0} aria-label={fa ? 'گروه‌های روابط و برندها' : 'Relationship groups and brands'}><ul className="tw-flex tw-w-max tw-gap-2">{grouped.map((section) => <li key={section.id}><Link to={`/partners#${section.id}`} className="tw-inline-flex tw-min-h-9 tw-items-center tw-whitespace-nowrap tw-rounded-full tw-border tw-border-kb-line tw-bg-kb-paper tw-px-3 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{section.title}</Link></li>)}{allBrands.length > 0 && <li><Link to="/partners#brands" className="tw-inline-flex tw-min-h-9 tw-items-center tw-whitespace-nowrap tw-rounded-full tw-border tw-border-kb-line tw-bg-kb-paper tw-px-3 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{c.brands}</Link></li>}</ul></nav></SiteContainer></section>}
      {(entries.length > 0 || allBrands.length > 0) && <section className="tw-bg-kb-paper tw-py-5" aria-label={fa ? 'جست‌وجو و فیلتر روابط تجارتی' : 'Search and filter trade relationships'}><SiteContainer>
        <div className="tw-grid tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-grid-cols-2 lg:tw-grid-cols-[minmax(0,1.3fr)_minmax(180px,.7fr)_minmax(180px,.7fr)_auto] lg:tw-items-end">
          <div><label htmlFor="partner-search" className="tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body">{c.searchLabel}</label><input id="partner-search" type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder={c.searchPlaceholder} className="tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink placeholder:tw-text-kb-muted focus:tw-border-kb-blue focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-blue/20" /></div>
          <div><label htmlFor="partner-kind-filter" className="tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body">{c.typeFilter}</label><select id="partner-kind-filter" value={kindFilter} onChange={(event) => setKindFilter(event.target.value)} className="tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink focus:tw-border-kb-blue focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-blue/20"><option value="all">{c.allTypes}</option>{ORDER.filter((kind) => SAFE_RELATION_KINDS.has(kind)).map((kind) => <option value={kind} key={kind}>{c[SECTION_META[kind][0]]}</option>)}</select></div>
          <div><label htmlFor="partner-sort" className="tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body">{c.sortLabel}</label><select id="partner-sort" value={sort} onChange={(event) => setSort(event.target.value)} className="tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink focus:tw-border-kb-blue focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-blue/20"><option value="name">{c.sortName}</option><option value="country">{c.sortCountry}</option></select></div>
          <button type="button" onClick={() => { setSearch(''); setKindFilter('all'); setSort('name'); setBrandCategory('all') }} className="tw-inline-flex tw-min-h-11 tw-items-center tw-justify-center tw-rounded-kb tw-border tw-border-kb-blue tw-px-4 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-bg-kb-blue hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{c.clearFilters}</button>
        </div>
      </SiteContainer></section>}
      {hasRelationshipFilters && filteredEntries.length === 0 && <section className="tw-bg-white tw-py-6" role="status"><SiteContainer><p className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 tw-text-sm tw-text-kb-body">{c.noMatches}</p></SiteContainer></section>}
      {grouped.map((section) => <RelationSection key={section.kind} section={section} L={L} lang={lang} c={c} />)}
      {allBrands.length > 0 && <BrandSection brands={filteredBrands} allBrands={allBrands} categories={brandCategories} lang={lang} c={c} L={L} selectedCategory={brandCategory} onCategoryChange={setBrandCategory} />}
      <section className="tw-bg-kb-paper tw-py-9 sm:tw-py-12" aria-labelledby="partners-proposal-title"><SiteContainer className="tw-flex tw-flex-col tw-gap-5 md:tw-flex-row md:tw-items-center md:tw-justify-between"><div><h2 id="partners-proposal-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy">{c.contact}</h2><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{c.contactNote}</p></div><Link className="tw-inline-flex tw-min-h-11 tw-shrink-0 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-blue tw-px-5 tw-text-sm tw-font-bold tw-text-white hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to="/contact?kind=cooperation">{t('suggest_coop')}<ArrowIcon /></Link></SiteContainer></section>
    </> : <section className="tw-bg-kb-paper tw-py-10"><SiteContainer><p className="tw-text-sm tw-text-kb-body">{fa ? 'برای معلومات دربارهٔ همکاری، از صفحهٔ تماس استفاده کنید.' : 'Contact the team for information about cooperation.'}</p><Link className="tw-mt-3 tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to="/contact">{t('nav_contact')}<ArrowIcon /></Link></SiteContainer></section>}
  </main>
}

import { Link } from 'react-router-dom'
import { usePublicDict } from '../lib.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'

const LINKS = [['/', 'home'], ['/about', 'nav_about'], ['/activities', 'nav_activities'], ['/products', 'nav_products'], ['/news', 'nav_news'], ['/contact', 'nav_contact']]

export default function NotFound() {
  const { t } = usePublicDict()
  return <main id="main" className="tw-grid tw-min-h-[60vh] tw-flex-1 tw-place-items-center tw-px-4 tw-py-12 tw-text-center sm:tw-px-6"><div className="tw-max-w-2xl"><div className="tw-mb-3 tw-font-head tw-text-6xl tw-font-bold tw-text-kb-gold sm:tw-text-7xl">404</div><h1 className="tw-mb-3 tw-font-head tw-text-3xl tw-font-bold tw-text-kb-navy">{t('notfound_t')}</h1><p className="tw-mb-7 tw-text-sm tw-leading-6 tw-text-kb-muted">{t('notfound_d')}</p><div className="tw-mb-6"><PrimaryLink to="/">{t('back_home')}</PrimaryLink></div><div className="tw-flex tw-flex-wrap tw-justify-center tw-gap-2">{LINKS.map(([url, label]) => <Link to={url} className="tw-inline-flex tw-min-h-9 tw-items-center tw-rounded-full tw-border tw-border-kb-line tw-bg-white tw-px-4 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" key={url}>{t(label)}</Link>)}</div></div></main>
}

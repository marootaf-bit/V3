import { usePublicDict } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'

const COPY = {
  privacy: {
    fa: [
      ['چه معلوماتی وارد می‌شود', 'فورم ممکن است نام، شمارهٔ تماس، ایمیل اختیاری، موضوع و متن پیام را در بر بگیرد؛ نام شرکت نیز در بعضی نسخه‌ها اختیاری است. با ثبت فورم، وب‌سایت پیش‌نویس را در برنامهٔ ایمیل دستگاه شما باز می‌کند و پیام را خودش ارسال یا در پایگاه داده ذخیره نمی‌کند.'],
      ['کاربرد معلومات', 'اگر خودتان پیش‌نویس را از برنامهٔ ایمیل بفرستید، گیرندهٔ درج‌شده در پیام آن را برای پاسخ به درخواست شما دریافت می‌کند. ارسال به انتخاب شماست؛ پیش از ارسال، آدرس گیرنده و متن پیام را بررسی کنید.'],
      ['نگهداری و دسترسی', 'پیام از راه برنامه یا سرویس ایمیل شما فرستاده می‌شود. نگهداری و دسترسی پس از ارسال تابع همان سرویس و گیرنده است.'],
      ['حذف معلومات', 'برای پیگیری یا درخواست حذف ایمیلی که خودتان فرستاده‌اید، با گیرنده از راه تماس درج‌شده در سایت ارتباط بگیرید.'],
    ],
    en: [
      ['Information entered', 'The form may include your name, phone number, optional email, subject and message; some versions also ask for an optional company name. Submitting it opens a draft in your email app. This website does not send the message or store it in a database.'],
      ['How it is used', 'If you send the draft from your email app, the recipient shown in the message receives it to respond to your request. Sending is your choice; check the recipient address and message before sending.'],
      ['Storage & access', 'The message is sent through your email app or service. Any storage or access after sending depends on that service and the recipient.'],
      ['Deletion', 'To follow up or request deletion of an email you sent, contact the recipient through the contact channel listed on this site.'],
    ],
  },
  terms: {
    fa: [
      ['محتوای سایت', 'محتوای این سایت برای معرفی فعالیت‌های شرکت است و پیشنهاد قیمت یا قرارداد محسوب نمی‌شود.'],
      ['درخواست‌ها', 'ثبت درخواست به معنای پذیرش تعهد از سوی شرکت نیست؛ شرایط هر معامله جداگانه توافق می‌شود.'],
      ['کوکی‌ها', 'این سایت تنها از کوکی ضروری برای عملکرد خود (مانند ورود مدیران) استفاده می‌کند؛ کوکی ردیابی یا تبلیغاتی به کار نمی‌رود.'],
      ['مالکیت', 'نام و نشان خان بوستان متعلق به شرکت است؛ استفاده بدون اجازه مجاز نیست.'],
    ],
    en: [
      ['Site content', 'Content on this site introduces company activities and is not a price offer or a contract.'],
      ['Requests', 'Submitting a request creates no obligation; terms of each deal are agreed separately.'],
      ['Cookies', 'This site uses only essential cookies for its own operation (such as admin sign-in); no tracking or advertising cookies are used.'],
      ['Ownership', 'The Khan Boostan name and mark belong to the company; unauthorised use is not permitted.'],
    ],
  },
}

export default function Legal({ kind }) {
  const { t, lang } = usePublicDict()
  const key = kind === 'terms' ? 'nav_terms' : 'nav_privacy'
  const blocks = COPY[kind === 'terms' ? 'terms' : 'privacy'][lang === 'en' ? 'en' : 'fa']
  const sectionIds = blocks.map((_, index) => `legal-${kind}-${index + 1}`)
  return <main id="main" className="tw-flex-1"><Hero image="/images/trade-detail.webp" crumbs={[[null, t(key)]]} title={t(key)} compact /><section className="tw-bg-kb-paper tw-py-7 sm:tw-py-10"><SiteContainer className="tw-max-w-4xl">
    <nav className="tw-mb-4 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4" aria-label={lang === 'fa' ? 'فهرست بخش‌های سند' : 'Document sections'}><ul className="tw-flex tw-flex-wrap tw-gap-2">{blocks.map(([heading], index) => <li key={sectionIds[index]}><a className="tw-inline-flex tw-min-h-9 tw-items-center tw-rounded-full tw-border tw-border-kb-line tw-bg-kb-paper tw-px-3 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" href={`#${sectionIds[index]}`}>{heading}</a></li>)}</ul></nav>
    <div className="tw-grid tw-gap-3">{blocks.map(([heading, paragraph], index) => <article id={sectionIds[index]} className="tw-scroll-mt-28 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-p-7" key={heading}><h2 className="tw-mb-2 tw-text-lg tw-font-bold tw-text-kb-navy">{heading}</h2><p className="tw-max-w-[74ch] tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{paragraph}</p></article>)}</div>
  </SiteContainer></section></main>
}

import { Link, useParams } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords, relationshipKind } from '../lib.jsx'
import CompanyHero from '../components/CompanyHero.jsx'
import CompanyLoading from '../components/CompanyLoading.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import JsonLd from '../components/public/JsonLd.jsx'
import NotFound from './NotFound.jsx'

const LABELS = {
  fa: { agency: 'نمایندگی رسمی', partner: 'شریک تجارتی', supplier: 'تأمین‌کننده', client: 'مشتری', brand: 'برند عرضه‌شده', affiliate: 'شرکت وابسته', field: 'حوزهٔ فعالیت', country: 'کشور', since: 'از', source: 'منبع', permission: 'اطلاعات نشر', verified: 'تاریخ', ask: 'پرسش دربارهٔ همکاری' },
  en: { agency: 'Official agency', partner: 'Trade partner', supplier: 'Supplier', client: 'Client', brand: 'Brand offered', affiliate: 'Affiliated company', field: 'Business area', country: 'Country', since: 'Since', source: 'Source', permission: 'Publication details', verified: 'Date', ask: 'Ask about cooperation' },
}

function validIsoDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return ''
  const date = new Date(`${value}T12:00:00Z`)
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? value : ''
}

function safeWebsite(value) {
  try {
    const url = new URL(value)
    return ['http:', 'https:'].includes(url.protocol) ? url.href : ''
  } catch { return '' }
}

export default function PartnerDetail() {
  const { slug } = useParams()
  const { data, settings } = useContent()
  const { L, lang, t } = usePublicDict()
  const fa = lang !== 'en'
  const labels = LABELS[fa ? 'fa' : 'en']
  if (!data) return <CompanyLoading lang={lang} />
  const entry = publicRecords(data.partners ?? []).find((item) => String(item.id) === slug && Boolean(L(item.name)))
  if (!entry || entry.demo === true || entry.verified !== true || entry.public !== true || settings?.sections?.showPartners === false) return <NotFound />

  const kind = relationshipKind(entry)
  const name = L(entry.name)
  const description = L(entry.description)
  const country = L(entry.country)
  const field = L(entry.field)
  const source = L(entry.verificationSource)
  const permission = L(entry.publicationPermission)
  const verifiedAt = validIsoDate(entry.verifiedAt)
  const website = safeWebsite(entry.website)
  const origin = typeof window === 'undefined' ? '' : window.location.origin
  const pageUrl = origin ? `${origin}/partners/${encodeURIComponent(entry.id)}` : ''
  const orgName = L(settings.company?.legal) || L(settings.company?.name)
  const schema = pageUrl ? { '@context': 'https://schema.org', '@type': 'WebPage', name, url: pageUrl, description: description || undefined, isPartOf: { '@id': `${origin}/partners#webpage` }, about: orgName ? { '@type': 'Organization', name: orgName, url: origin } : undefined } : null
  const contactSubject = encodeURIComponent(name)

  return <main id="main" className="tw-flex-1">
    {schema && <JsonLd value={schema} />}
    <CompanyHero image="/images/trade-documents.webp" imageSet="/images/trade-documents-sm.webp 640w, /images/trade-documents-md.webp 1024w, /images/trade-documents.webp 1600w" width={1600} height={1067} title={name} summary={description} crumbs={[{ label: t('nav_about'), to: '/about' }, { label: t('nav_partners'), to: '/partners' }, { label: name }]} compact contentPanel />
    <section className="tw-bg-kb-paper tw-py-8 sm:tw-py-10" aria-labelledby="partner-record-title"><SiteContainer className="tw-max-w-4xl">
      <h2 id="partner-record-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{labels[kind] ?? labels.partner}</h2>
      <dl className="tw-mt-5 tw-grid tw-gap-3 sm:tw-grid-cols-2">
        {country && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><dt className="tw-text-xs tw-font-bold tw-text-kb-muted">{labels.country}</dt><dd className="tw-mt-1 tw-text-sm tw-text-kb-navy">{country}</dd></div>}
        {field && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><dt className="tw-text-xs tw-font-bold tw-text-kb-muted">{labels.field}</dt><dd className="tw-mt-1 tw-text-sm tw-text-kb-navy">{field}</dd></div>}
        {entry.since && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><dt className="tw-text-xs tw-font-bold tw-text-kb-muted">{labels.since}</dt><dd className="tw-mt-1 tw-text-sm tw-text-kb-navy">{String(entry.since)}</dd></div>}
        {source && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><dt className="tw-text-xs tw-font-bold tw-text-kb-muted">{labels.source}</dt><dd className="tw-mt-1 tw-text-sm tw-text-kb-navy">{source}</dd></div>}
        {permission && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><dt className="tw-text-xs tw-font-bold tw-text-kb-muted">{labels.permission}</dt><dd className="tw-mt-1 tw-text-sm tw-text-kb-navy">{permission}</dd></div>}
        {verifiedAt && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><dt className="tw-text-xs tw-font-bold tw-text-kb-muted">{labels.verified}</dt><dd className="tw-mt-1 tw-text-sm tw-text-kb-navy"><time dateTime={verifiedAt}>{verifiedAt}</time></dd></div>}
      </dl>
      {website && <p className="tw-mt-4"><a className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" href={website} target="_blank" rel="noopener noreferrer">{fa ? 'بازدید از وب‌سایت' : 'Visit website'}<span className="tw-sr-only">{fa ? 'در برگهٔ تازه باز می‌شود' : 'Opens in a new tab'}</span><ArrowIcon kind="up" size={14} /></a></p>}
      <div className="tw-mt-7 tw-flex tw-flex-wrap tw-gap-3"><PrimaryLink to={`/contact?kind=cooperation&subject=${contactSubject}`} variant="blue">{labels.ask}<ArrowIcon /></PrimaryLink><Link to="/partners" className="tw-inline-flex tw-min-h-11 tw-items-center tw-gap-2 tw-rounded-kb tw-border tw-border-kb-blue tw-px-5 tw-text-sm tw-font-bold tw-text-kb-blue hover:tw-bg-kb-blue hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{t('nav_partners')}</Link></div>
    </SiteContainer></section>
  </main>
}

import { Link, useSearchParams } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicNews, publicSlug } from '../lib.jsx'
import NewsCard, { newsCat } from '../components/NewsCard.jsx'
import Hero from '../components/public/Hero.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'

export default function News() {
  const { data } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  const [searchParams, setSearchParams] = useSearchParams()
  const category = searchParams.get('c') || 'all'
  const updateCategory = (value) => {
    const next = new URLSearchParams(searchParams)
    if (value && value !== 'all') next.set('c', value)
    else next.delete('c')
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }
  if (!data) return <PublicLoading />

  const all = [...publicNews(data.news ?? [])].filter((item) => Boolean(L(item.title))).sort((a, b) => (b.date ?? '').localeCompare(a.date ?? ''))
  const categories = [...new Set(all.map((item) => item.category).filter((value) => Boolean(newsCat(value, lang))))]
  const filtered = category === 'all' ? all : all.filter((item) => item.category === category)
  const featured = filtered.find((item) => item.featured) ?? filtered[0]
  const showFeature = Boolean(featured && category === 'all')
  const rows = showFeature ? filtered.filter((item) => item.id !== featured.id) : filtered
  const numberFormat = new Intl.NumberFormat(lang === 'fa' ? 'fa-AF' : 'en', { useGrouping: false })
  const countText = fa ? `${numberFormat.format(filtered.length)} مطلب` : `${numberFormat.format(filtered.length)} items`

  return <main id="main" className="tw-flex-1">
    <Hero image="/images/news-exhibition.webp" crumbs={[[null, t('nav_news')]]} title={t('nav_news')} sub={t('news_d')} compact />

    <section className="tw-bg-kb-paper tw-py-3 sm:tw-py-4" aria-label={fa ? 'دسته‌بندی خبرها' : 'Filter by category'}><SiteContainer>
      <div className="tw-flex tw-items-center tw-gap-3"><span className="tw-flex tw-shrink-0 tw-flex-col tw-text-[11px] tw-font-bold tw-text-kb-muted"><span>{fa ? 'دسته‌بندی:' : 'Category:'}</span><small className="tw-text-[9px] tw-font-normal tw-text-kb-muted sm:tw-hidden">{fa ? 'افقی بکشید' : 'Swipe'}</small></span><div className="tw-min-w-0 tw-flex-1 tw-overflow-x-auto tw-pb-1" tabIndex={0} role="group" aria-label={fa ? 'فیلتر مطالب؛ برای دیدن همهٔ گزینه‌ها افقی پیمایش کنید' : 'Filter stories; scroll horizontally to see all options'}><div className="tw-flex tw-w-max tw-gap-2 sm:tw-w-full sm:tw-flex-wrap"><button type="button" className={`tw-min-h-9 tw-shrink-0 tw-rounded-full tw-border tw-px-4 tw-text-[11px] tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${category === 'all' ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-control tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`} aria-pressed={category === 'all'} onClick={() => updateCategory('all')}>{t('all')}</button>{categories.map((item) => <button type="button" key={item} className={`tw-min-h-9 tw-shrink-0 tw-rounded-full tw-border tw-px-4 tw-text-[11px] tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${category === item ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-control tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`} aria-pressed={category === item} onClick={() => updateCategory(item)}>{newsCat(item, lang)}</button>)}</div></div></div>
      <p className="tw-mt-2 tw-text-[11px] tw-font-bold tw-text-kb-muted" role="status" aria-live="polite">{countText}</p>
    </SiteContainer></section>

    {showFeature && <section className="tw-bg-white tw-py-6 sm:tw-py-10" aria-labelledby="featured-story-title"><SiteContainer className="tw-grid tw-gap-5 md:tw-grid-cols-2"><Link to={`/news/${publicSlug(featured.id)}`} className="tw-group tw-relative tw-block tw-aspect-video tw-overflow-hidden tw-rounded-kb-lg tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><img className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.03] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" src={featured.image || '/images/news-exhibition.webp'} alt="" fetchpriority="high" /><span className="tw-absolute tw-bottom-3 tw-start-3 tw-rounded-full tw-bg-kb-gold tw-px-3 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-navy">{t('featured_news')}</span><span className="tw-sr-only">{L(featured.title)}</span></Link><article className="tw-flex tw-flex-col tw-items-start tw-justify-center tw-py-2"><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-xs tw-text-kb-muted">{featured.date && <time dateTime={featured.date}>{featured.date}</time>}{featured.category && newsCat(featured.category, lang) && <span>{newsCat(featured.category, lang)}</span>}</div><h2 id="featured-story-title" className="tw-mt-3 tw-break-words tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl"><Link className="hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={`/news/${publicSlug(featured.id)}`}>{L(featured.title)}</Link></h2>{L(featured.excerpt) && <p className="tw-mt-3 tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-7 tw-text-kb-body">{L(featured.excerpt)}</p>}<Link className="tw-mt-4 tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={`/news/${publicSlug(featured.id)}`}>{t('read_more')}<ArrowIcon /></Link></article></SiteContainer></section>}

    <section className="tw-bg-white tw-py-7 sm:tw-py-10" aria-label={fa ? 'آرشیف خبرها و راهنماها' : 'News and guide archive'}><SiteContainer>{rows.length > 0 && <div className="tw-grid tw-gap-4 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{rows.map((item) => <NewsCard key={item.id} n={item} />)}</div>}</SiteContainer></section>
  </main>
}

import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import CallToAction from '../components/public/CallToAction.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'

const PROCESS = {
  fa: [
    ['درخواست و شناخت نیاز', 'گفتگو با مشتری یا شرکت، تعیین مشخصات و مقدار'],
    ['بررسی و تأمین', 'انتخاب تأمین‌کننده بر اساس اصول مشخص، اعلام شفاف قیمت و شرایط'],
    ['هماهنگی و آماده‌سازی', 'کنترل کیفیت و بسته‌بندی، تکمیل اسناد'],
    ['انتقال و تحویل', 'پیگیری تا تحویل، اطلاع‌رسانی روشن'],
  ],
  en: [
    ['Request & scoping', 'Talk with the client, agree specifications and quantity'],
    ['Review & sourcing', 'Choose suppliers on clear principles, transparent pricing'],
    ['Coordination & prep', 'Quality control, packing and documents'],
    ['Shipping & delivery', 'Follow-up until delivery, clear updates'],
  ],
}

export default function Process() {
  const { settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  const steps = PROCESS[fa ? 'fa' : 'en']
  const intro = L(settings.pages?.process?.intro)

  return <main id="main" className="tw-flex-1">
    <Hero image="/images/trade-highway.webp" crumbs={[["/activities", t('nav_activities')], [null, t('nav_process')]]} title={t('nav_process')} sub={intro} compact />
    <section className="tw-bg-white tw-py-10 sm:tw-py-14" aria-label={fa ? 'مراحل همکاری' : 'Trade process steps'}><SiteContainer><ol className="tw-grid tw-gap-3 md:tw-grid-cols-2 md:tw-gap-4 xl:tw-grid-cols-4">{steps.map(([title, copy], index) => <li className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 sm:tw-p-5" key={title}><span className="tw-grid tw-h-9 tw-w-9 tw-place-items-center tw-rounded-full tw-border tw-border-kb-gold/50 tw-bg-white tw-text-xs tw-font-bold tw-text-kb-blue">{fa ? String(index + 1).padStart(2, '0').replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[digit]) : String(index + 1).padStart(2, '0')}</span><h3 className="tw-mt-3 tw-font-head tw-text-lg tw-font-bold tw-leading-7 tw-text-kb-navy sm:tw-text-xl">{title}</h3><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{copy}</p></li>)}</ol></SiteContainer></section>
    <CallToAction />
  </main>
}

import { Link } from 'react-router-dom'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import CallToAction from '../components/public/CallToAction.jsx'
import FaqList from '../components/public/FaqList.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import Eyebrow from '../components/public/Eyebrow.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'

const IMPORT_FAQ = ['activities-faq-2', 'activities-faq-6', 'activities-faq-7']
const EXPORT_FAQ = ['activities-faq-3', 'activities-faq-8']
const TRADE_CASE_IDS = {
  import: ['demo-project-3', 'demo-project-x0', 'demo-project-x1'],
  export: ['demo-project-2', 'demo-project-x2'],
}

export default function TradePage({ kind }) {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  if (!data) return <PublicLoading />
  const pg = (settings.pages ?? {})[kind] ?? {}
  const cats = data.categories ?? []
  const projects = [...publicRecords(data.projects ?? [])].sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || bySort(a, b))
  const relatedProjects = (TRADE_CASE_IDS[kind] ?? []).map((id) => projects.find((project) => project.id === id)).filter(Boolean)
  const faqIds = kind === 'import' ? IMPORT_FAQ : EXPORT_FAQ
  const faqs = publicRecords(data.faq ?? []).filter((item) => faqIds.includes(item.id))
  const countByCategory = (id) => (data.products ?? []).filter((product) => product.category === id).length
  const categoryGroupsTitle = fa ? 'گروه‌های کالایی مرتبط' : 'Related product groups'
  const relatedCasesTitle = fa ? 'پرونده‌های مرتبط' : 'Related trade cases'
  const scopeTitle = fa ? 'دامنهٔ فعالیت' : 'Scope of work'

  return <main id="main" className="tw-flex-1"><Hero image={pg.image} crumbs={[["/activities", t('nav_activities')], [null, L(pg.title)]]} title={L(pg.title)} sub={L(pg.intro)} compact />
    <section className="tw-bg-kb-paper tw-py-10 sm:tw-py-14"><SiteContainer>
      <div className="tw-grid tw-items-start tw-gap-8 lg:tw-grid-cols-[minmax(0,7fr)_minmax(0,5fr)] lg:tw-gap-12">
        <div><h2 className="tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{scopeTitle}</h2><p className="tw-mt-3 tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{L(pg.body)}</p>
          <ul className="tw-mt-5 tw-grid tw-gap-3">{(pg.points ?? []).map((point, index) => <li className="tw-flex tw-items-start tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 tw-text-sm tw-leading-6 tw-text-kb-body" key={index}><span className="tw-mt-0.5 tw-flex tw-h-6 tw-w-6 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-bg-kb-paper tw-text-kb-blue" aria-hidden="true"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg></span>{L(point)}</li>)}</ul>
          <div className="tw-mt-8"><h2 className="tw-text-lg tw-font-bold tw-text-kb-navy">{t('audience_t')}</h2><p className="tw-mt-2 tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{L(pg.audience)}</p></div>
          <div className="tw-mt-7"><h2 className="tw-text-lg tw-font-bold tw-text-kb-navy">{t('required_t')}</h2><p className="tw-mt-2 tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{L(pg.required)}</p></div>
        </div>
        <aside className="tw-grid tw-gap-4">
          <div className="tw-overflow-hidden tw-rounded-kb-lg tw-bg-kb-navy"><img src={pg.image} alt={L(pg.title)} loading="lazy" className="tw-max-h-72 tw-w-full tw-object-cover" /></div>
          <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5"><h3 className="tw-mb-3 tw-text-base tw-font-bold tw-text-kb-navy">{categoryGroupsTitle}</h3><div className="tw-flex tw-flex-wrap tw-gap-2">{cats.map((category) => <Link className="tw-inline-flex tw-min-h-8 tw-items-center tw-gap-1.5 tw-rounded-full tw-border tw-border-kb-line tw-bg-kb-paper tw-px-3 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={`/products/?c=${category.id}`} key={category.id}>{L(category.name)} <span className="tw-text-[10px] tw-text-kb-muted">({countByCategory(category.id)})</span></Link>)}</div></div>
          {relatedProjects.length > 0 && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5"><div className="tw-mb-3 tw-flex tw-flex-wrap tw-items-center tw-gap-2"><h3 className="tw-text-base tw-font-bold tw-text-kb-navy">{relatedCasesTitle}</h3></div><ul className="tw-grid tw-gap-2">{relatedProjects.map((project) => <li className="tw-rounded-kb tw-border tw-border-kb-line tw-bg-kb-paper tw-p-3" key={project.id}><b className="tw-block tw-text-sm tw-text-kb-navy">{L(project.title)}</b><span className="tw-text-[11px] tw-text-kb-muted">{L(project.sector)} · {project.year}</span></li>)}</ul><Link className="tw-mt-3 tw-inline-flex tw-min-h-8 tw-items-center tw-gap-2 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to="/projects">{t('view_all')}<ArrowIcon /></Link></div>}
        </aside>
      </div>
      {faqs.length > 0 && <section className="tw-mt-12" aria-labelledby="trade-faq-title"><div className="tw-mb-5"><Eyebrow>{fa ? 'پرسش‌های پرتکرار' : 'FAQ'}</Eyebrow><h2 id="trade-faq-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{t('faq_coop')}</h2></div><FaqList items={faqs} plus /></section>}
    </SiteContainer></section>
    <CallToAction />
  </main>
}

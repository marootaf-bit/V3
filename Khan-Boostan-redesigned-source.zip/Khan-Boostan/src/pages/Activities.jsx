import { Link } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords } from '../lib.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import Hero from '../components/public/Hero.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import ActivitiesPathways from '../components/public/ActivitiesPathways.jsx'
import ActivitiesMarkets from '../components/public/ActivitiesMarkets.jsx'
import ActivitiesProcess from '../components/public/ActivitiesProcess.jsx'
import ActivitiesMarketInfo from '../components/public/ActivitiesMarketInfo.jsx'
import ActivitiesCases from '../components/public/ActivitiesCases.jsx'
import FaqList from '../components/public/FaqList.jsx'
import CallToAction from '../components/public/CallToAction.jsx'

export default function Activities() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  if (!data) return <PublicLoading />

  const pages = settings.pages ?? {}
  const activities = settings.activities ?? {}
  const categories = [...(data.categories ?? [])].filter((category) => Boolean(L(category.name)))
  const industries = activities.industries ?? []
  const tradeCases = [...publicRecords(data.projects ?? [])].filter((item) => Boolean(L(item.title))).sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)))
  const featuredCases = tradeCases.filter((item) => item.featured).slice(0, 3)
  const faq = publicRecords(data.faq ?? []).filter((item) => item.topic === 'activities' && L(item.q) && L(item.a))
  const pathways = [
    { key: 'import', to: '/import', label: L(pages.import?.title, fa ? 'واردات کالا' : 'Import goods'), copy: L(pages.import?.intro, fa ? 'تأمین کالا از بازارهای خارجی برای تاجران، شرکت‌ها و پروژه‌ها در افغانستان.' : 'Sourcing goods from international markets for traders, companies and projects in Afghanistan.'), image: '/images/trade-warehouse.webp', tag: fa ? 'واردات' : 'IMPORT' },
    { key: 'export', to: '/export', label: L(pages.export?.title, fa ? 'صادرات محصولات' : 'Export products'), copy: L(pages.export?.intro, fa ? 'رساندن محصولات افغانستان به بازارهای منطقه و جهان.' : 'Bringing Afghan products to regional and international markets.'), image: '/images/trade-cargo.webp', tag: fa ? 'صادرات' : 'EXPORT' },
  ]
  const processSteps = fa
    ? [['درخواست و شناخت نیاز', 'گفتگو و تعیین مشخصات'], ['بررسی و تأمین', 'انتخاب تأمین‌کننده و اعلام شفاف شرایط'], ['هماهنگی و آماده‌سازی', 'کنترل کیفیت، بسته‌بندی و اسناد'], ['انتقال و تحویل', 'پیگیری تا تحویل و اطلاع‌رسانی']]
    : [['Request & scoping', 'Talk and agree specifications'], ['Review & sourcing', 'Supplier selection, transparent terms'], ['Coordination & prep', 'QC, packing and documents'], ['Delivery', 'Follow-up until delivery']]

  return <main id="main" className="tw-flex-1">
    <Hero image="/images/trade-port.webp" crumbs={[[null, t('nav_activities')]]} title={t('nav_activities')} sub={L(activities.sourcing, fa ? 'در صورت درخواست مشتری، کالای مشخصی را از بازارهای مختلف شناسایی، قیمت‌گیری و تأمین می‌کنیم.' : 'On request we identify, price and source specific goods from different markets.')} compact />
    <ActivitiesPathways pathways={pathways} fa={fa} t={t} />
    <ActivitiesMarkets categories={categories} industries={industries} L={L} fa={fa} lang={lang} />
    <ActivitiesProcess processSteps={processSteps} fa={fa} />
    <ActivitiesMarketInfo markets={activities.markets ?? []} supplierPrinciples={activities.supplierPrinciples ?? []} quality={activities.quality} L={L} fa={fa} lang={lang} />
    <ActivitiesCases projects={featuredCases} L={L} fa={fa} lang={lang} t={t} />
    {faq.length > 0 && <section id="faq" className="tw-bg-white tw-py-12 sm:tw-py-16" aria-labelledby="activities-faq-title"><div className="tw-mx-auto tw-grid tw-w-full tw-max-w-[1320px] tw-gap-8 tw-px-4 sm:tw-px-6 lg:tw-grid-cols-[.8fr_1.2fr] lg:tw-gap-12 lg:tw-px-8"><div><span className="tw-text-[11px] tw-font-bold tw-tracking-[.14em] tw-text-kb-navy">{fa ? 'پرسش‌های پرتکرار' : 'FAQ'}</span><h2 id="activities-faq-title" className="tw-mt-2 tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy">{fa ? 'پرسش‌های متداول همکاری' : 'Cooperation FAQ'}</h2><Link to="/contact" className="tw-mt-4 tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('nav_contact')}<ArrowIcon /></Link></div><FaqList items={faq} plus /></div></section>}
    <section className="tw-bg-kb-paper tw-py-8 sm:tw-py-10" aria-labelledby="activities-trade-guide-title"><div className="tw-mx-auto tw-flex tw-w-full tw-max-w-[1320px] tw-flex-col tw-gap-4 tw-px-4 sm:tw-px-6 md:tw-flex-row md:tw-items-center md:tw-justify-between lg:tw-px-8"><div className="tw-max-w-3xl"><span className="tw-text-[10px] tw-font-bold tw-tracking-[.12em] tw-text-kb-blue">{fa ? 'ابزار آمادگی' : 'TRADE TOOLKIT'}</span><h2 id="activities-trade-guide-title" className="tw-mt-2 tw-font-head tw-text-xl tw-font-bold tw-text-kb-navy sm:tw-text-2xl">{fa ? 'درخواست تجارتی خود را آماده‌تر بسازید' : 'Prepare a clearer trade enquiry'}</h2><p className="tw-mt-2 tw-text-sm tw-leading-7 tw-text-kb-body">{fa ? 'چک‌لیست‌ها و راهنمای عمومی برای آماده‌سازی درخواست، اسناد و گفتگوهای تجارتی را ببینید.' : 'Explore general checklists for preparing enquiries, documents and trade discussions.'}</p></div><Link to="/trade-guide" className="tw-inline-flex tw-min-h-11 tw-w-fit tw-shrink-0 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-blue tw-px-4 tw-text-sm tw-font-bold tw-text-white hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{fa ? 'بازکردن راهنمای تجارت' : 'Open trade guide'}<ArrowIcon /></Link></div></section>
    <div className="tw-relative tw-aspect-[16/5] tw-min-h-36 tw-overflow-hidden tw-bg-kb-navy" aria-hidden="true"><img className="tw-absolute tw-inset-0 tw-h-full tw-w-full tw-object-cover" src="/images/trade-highway.webp" alt="" loading="lazy" /><div className="tw-absolute tw-inset-0 tw-bg-kb-navy/30" /></div>
    <CallToAction />
  </main>
}

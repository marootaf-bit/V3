import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords, publicJobSummary, publicJobBody } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'
import CareerMetaIcon from '../components/public/CareerMetaIcon.jsx'
import CopyPageLink from '../components/public/CopyPageLink.jsx'
import JsonLd from '../components/public/JsonLd.jsx'

const COPY = {
  fa: {
    search: 'جست‌وجوی بست', searchHint: 'عنوان، نوع کار یا محل', type: 'نوع بست', location: 'محل', allTypes: 'همهٔ نوع‌ها', allLocations: 'همهٔ محل‌ها',
    clear: 'پاک‌کردن فیلترها', noMatch: 'با این فیلترها بست پیدا نشد.',
    description: 'جزئیات بست', responsibilities: 'مسئولیت‌ها', requirements: 'شرایط و نیازمندی‌ها', documents: 'اسناد موردنیاز', application: 'روش درخواست',
    open: 'فعال', closed: 'بسته', pastTitle: 'بست‌های پایان‌یافته',
    applyNote: 'این مسیر پیش‌نویس ایمیل را باز می‌کند؛ سایت پیام را ذخیره نمی‌کند و پیوست فایل ندارد. CV را در برنامهٔ ایمیل خودتان پیوست کنید.',
    privacy: 'معلومات حریم خصوصی',
  },
  en: {
    search: 'Search vacancies', searchHint: 'Title, work type or location', type: 'Employment type', location: 'Location', allTypes: 'All types', allLocations: 'All locations',
    clear: 'Clear filters', noMatch: 'No vacancies match these filters.',
    description: 'Role details', responsibilities: 'Responsibilities', requirements: 'Requirements', documents: 'Required documents', application: 'How to apply',
    open: 'Open', closed: 'Closed', pastTitle: 'Past vacancies',
    applyNote: 'This route opens an email draft; the site does not store the message and the form has no file attachment. Attach your CV in your email app.',
    privacy: 'Privacy information',
  },
}

function safeIsoDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return ''
  const date = new Date(`${value}T12:00:00Z`)
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? value : ''
}

function jobStatus(job) {
  if (job.demo === true || job.verified !== true) return ''
  const deadline = safeIsoDate(job.deadline)
  if (!deadline) return ''
  const [year, month, day] = deadline.split('-').map(Number)
  return new Date(year, month - 1, day, 23, 59, 59).getTime() >= Date.now() ? 'open' : 'closed'
}

function jobAnchor(id) {
  return `job-${String(id ?? 'vacancy').replace(/[^a-zA-Z0-9_-]/g, '-')}`
}

export default function Careers() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  const c = COPY[fa ? 'fa' : 'en']
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('all')
  const [locationFilter, setLocationFilter] = useState('all')
  const jobs = [...publicRecords(data?.jobs ?? [])].sort(bySort)
  const locale = fa ? 'fa' : 'en'
  const types = [...new Map(jobs.filter((job) => job.type).map((job) => [JSON.stringify(job.type), L(job.type)])).entries()]
    .map(([value, label]) => ({ value, label }))
    .sort((a, b) => a.label.localeCompare(b.label, locale))
  const locations = [...new Map(jobs.filter((job) => job.location).map((job) => [JSON.stringify(job.location), L(job.location)])).entries()]
    .map(([value, label]) => ({ value, label }))
    .sort((a, b) => a.label.localeCompare(b.label, locale))
  const filteredJobs = useMemo(() => {
    const query = search.trim().toLocaleLowerCase(locale)
    return jobs.filter((job) => {
      const title = L(job.title)
      const type = L(job.type)
      const location = L(job.location)
      if (typeFilter !== 'all' && JSON.stringify(job.type) !== typeFilter) return false
      if (locationFilter !== 'all' && JSON.stringify(job.location) !== locationFilter) return false
      return !query || [title, type, location, publicJobSummary(job, L, lang)].some((value) => String(value ?? '').toLocaleLowerCase(locale).includes(query))
    })
  }, [jobs, search, typeFilter, locationFilter, L, lang, locale])
  const currentJobs = filteredJobs.filter((job) => jobStatus(job) !== 'closed')
  const closedJobs = filteredJobs.filter((job) => jobStatus(job) === 'closed')
  const hasFilters = Boolean(search.trim() || typeFilter !== 'all' || locationFilter !== 'all')
  const origin = typeof window === 'undefined' ? '' : window.location.origin
  const pageUrl = origin ? `${origin}/careers` : ''
  const organizationName = L(settings.company?.legal) || L(settings.company?.name)
  const schema = pageUrl && organizationName ? {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'Organization', '@id': `${origin}/#organization`, name: organizationName, url: origin, logo: `${origin}/brand/khan-boostan-official.png` },
      { '@type': 'CollectionPage', '@id': `${pageUrl}#webpage`, url: pageUrl, name: t('careers_t'), description: t('careers_d'), about: { '@id': `${origin}/#organization` } },
      { '@type': 'BreadcrumbList', '@id': `${pageUrl}#breadcrumb`, itemListElement: [
        { '@type': 'ListItem', position: 1, name: t('home'), item: origin },
        { '@type': 'ListItem', position: 2, name: t('nav_about'), item: `${origin}/about` },
        { '@type': 'ListItem', position: 3, name: t('careers_t'), item: pageUrl },
      ] },
    ],
  } : null

  const renderJob = (job) => {
    const title = L(job.title)
    const body = publicJobBody(job, L, lang)
    const structuredSections = [
      ['responsibilities', c.responsibilities, L(job.responsibilities)],
      ['requirements', c.requirements, L(job.requirements)],
      ['documents', c.documents, L(job.requiredDocuments)],
      ['application', c.application, L(job.applicationInstructions)],
    ].filter(([, , text]) => text)
    const status = jobStatus(job)
    const id = jobAnchor(job.id)
    return <article id={id} className="tw-scroll-mt-24 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-p-7" key={job.id}>
      <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-3"><h2 className="tw-text-lg tw-font-bold tw-text-kb-navy">{title}</h2><CopyPageLink id={id} lang={lang} sectionLabel={title} />{status && <span className={`tw-inline-flex tw-min-h-6 tw-items-center tw-rounded-full tw-px-2.5 tw-text-[10px] tw-font-bold ${status === 'open' ? 'tw-bg-kb-paper tw-text-kb-blue' : 'tw-bg-kb-paper tw-text-kb-muted'}`}>{status === 'open' ? c.open : c.closed}</span>}</div>
      <dl className="tw-mt-4 tw-grid tw-gap-2 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{job.type && <div className="tw-rounded-kb tw-bg-kb-paper tw-px-3 tw-py-2"><dt className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{c.type}</dt><dd className="tw-mt-1 tw-text-xs tw-font-bold tw-text-kb-navy">{L(job.type)}</dd></div>}{job.location && <div className="tw-rounded-kb tw-bg-kb-paper tw-px-3 tw-py-2"><dt className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{c.location}</dt><dd className="tw-mt-1 tw-inline-flex tw-items-center tw-gap-1.5 tw-text-xs tw-font-bold tw-text-kb-navy"><CareerMetaIcon kind="pin" />{L(job.location)}</dd></div>}{job.deadline && <div className="tw-rounded-kb tw-bg-kb-paper tw-px-3 tw-py-2"><dt className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{t('deadline_l')}</dt><dd className="tw-mt-1 tw-inline-flex tw-items-center tw-gap-1.5 tw-text-xs tw-font-bold tw-text-kb-navy"><CareerMetaIcon kind="clock" /><time dateTime={safeIsoDate(job.deadline) || undefined}>{job.deadline}</time></dd></div>}</dl>
      <p className="tw-mt-4 tw-text-sm tw-leading-7 tw-text-kb-body">{publicJobSummary(job, L, lang)}</p>
      {structuredSections.length > 0 ? <div className="tw-mt-4 tw-grid tw-gap-3 sm:tw-grid-cols-2">{structuredSections.map(([key, heading, text]) => <section key={key} className="tw-rounded-kb tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4"><h3 className="tw-text-sm tw-font-bold tw-text-kb-navy">{heading}</h3><p className="tw-mt-2 tw-whitespace-pre-line tw-text-sm tw-leading-6 tw-text-kb-body">{text}</p></section>)}{body && <section className="tw-rounded-kb tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 sm:tw-col-span-2"><h3 className="tw-text-sm tw-font-bold tw-text-kb-navy">{c.description}</h3><p className="tw-mt-2 tw-whitespace-pre-line tw-text-sm tw-leading-6 tw-text-kb-body">{body}</p></section>}</div> : body && <section className="tw-mt-4"><h3 className="tw-text-sm tw-font-bold tw-text-kb-navy">{c.description}</h3><p className="tw-mt-2 tw-whitespace-pre-line tw-text-sm tw-leading-6 tw-text-kb-body">{body}</p></section>}
      <div className="tw-mt-5 tw-flex tw-flex-col tw-items-start tw-gap-3 sm:tw-flex-row sm:tw-items-center"><Link to={`/contact?kind=career&subject=${encodeURIComponent(title)}`} className="tw-inline-flex tw-min-h-10 tw-items-center tw-rounded-kb tw-border tw-border-kb-blue tw-px-4 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-bg-kb-blue hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{t('apply')}</Link><span className="tw-text-[11px] tw-leading-5 tw-text-kb-muted">{fa ? 'سوابق و معلومات تماس را در پیام بنویسید؛ CV را پس از بازشدن برنامهٔ ایمیل، خودتان به ایمیل پیوست کنید.' : 'Include your background and contact details in the message; attach your CV in your email app after it opens.'}</span></div>
      <p className="tw-mt-3 tw-border-t tw-border-kb-line tw-pt-3 tw-text-[11px] tw-leading-5 tw-text-kb-muted">{c.applyNote} <Link to="/privacy" className="tw-font-bold tw-text-kb-blue hover:tw-underline focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{c.privacy}</Link></p>
    </article>
  }

  if (!data) return <PublicLoading />

  return <main id="main" className="tw-flex-1">
    {schema && <JsonLd value={schema} />}
    <Hero image="/images/gallery-office.webp" crumbs={[[null, t('nav_about')], [null, t('careers_t')]]} title={t('careers_t')} sub={t('careers_d')} compact />
    {jobs.length > 0 && <section className="tw-bg-white tw-py-5" aria-label={fa ? 'جست‌وجو و فیلتر بست‌ها' : 'Search and filter vacancies'}><SiteContainer className="tw-max-w-5xl">
      <div className="tw-grid tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 sm:tw-grid-cols-2 lg:tw-grid-cols-[minmax(0,1.2fr)_minmax(180px,.8fr)_minmax(180px,.8fr)_auto] lg:tw-items-end">
        <div><label htmlFor="career-search" className="tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body">{c.search}</label><input id="career-search" type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder={c.searchHint} className="tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink placeholder:tw-text-kb-muted focus:tw-border-kb-blue focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-blue/20" /></div>
        <div><label htmlFor="career-type-filter" className="tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body">{c.type}</label><select id="career-type-filter" value={typeFilter} onChange={(event) => setTypeFilter(event.target.value)} className="tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink focus:tw-border-kb-blue focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-blue/20"><option value="all">{c.allTypes}</option>{types.map((type) => <option value={type.value} key={type.value}>{type.label}</option>)}</select></div>
        <div><label htmlFor="career-location-filter" className="tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body">{c.location}</label><select id="career-location-filter" value={locationFilter} onChange={(event) => setLocationFilter(event.target.value)} className="tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-sm tw-text-kb-ink focus:tw-border-kb-blue focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-kb-blue/20"><option value="all">{c.allLocations}</option>{locations.map((location) => <option value={location.value} key={location.value}>{location.label}</option>)}</select></div>
        <button type="button" onClick={() => { setSearch(''); setTypeFilter('all'); setLocationFilter('all') }} className="tw-inline-flex tw-min-h-11 tw-items-center tw-justify-center tw-rounded-kb tw-border tw-border-kb-blue tw-px-4 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-bg-kb-blue hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{c.clear}</button>
      </div>
    </SiteContainer></section>}
    {jobs.length > 0 && <section className="tw-bg-kb-paper tw-py-8 sm:tw-py-11"><SiteContainer className="tw-grid tw-max-w-5xl tw-gap-4">
      {hasFilters && filteredJobs.length === 0 && <div className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5" role="status"><p className="tw-text-sm tw-text-kb-body">{c.noMatch}</p><button type="button" onClick={() => { setSearch(''); setTypeFilter('all'); setLocationFilter('all') }} className="tw-mt-3 tw-inline-flex tw-min-h-10 tw-items-center tw-rounded-kb tw-bg-kb-blue tw-px-4 tw-text-xs tw-font-bold tw-text-white hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{c.clear}</button></div>}
      {currentJobs.map(renderJob)}
      {closedJobs.length > 0 && <section className="tw-mt-3 tw-grid tw-gap-4" aria-labelledby="career-archive-title"><h2 id="career-archive-title" className="tw-font-head tw-text-xl tw-font-bold tw-text-kb-navy">{c.pastTitle}</h2>{closedJobs.map(renderJob)}</section>}
    </SiteContainer></section>}
  </main>
}

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { useContent, useLang } from '../../src/lib/store.jsx'
import { A, COLLECTIONS, COLLECTION_ORDER, FIELD_LABELS, SETTINGS_LABELS } from '../../src/admin/dict.js'
import './preview-admin.css'

const GROUPS = [
  { key: 'content', items: COLLECTION_ORDER.filter((key) => COLLECTIONS[key].group === 'content') },
  { key: 'trade', items: COLLECTION_ORDER.filter((key) => COLLECTIONS[key].group === 'trade') },
]
const faDigits = '۰۱۲۳۴۵۶۷۸۹'
const number = (n, lang) => lang === 'fa' ? String(n).replace(/\d/g, (d) => faDigits[d]) : String(n)
const label = (key, lang, a) => a[key] ?? FIELD_LABELS[key]?.[lang] ?? SETTINGS_LABELS[key]?.[lang] ?? key
const assetPath = (value) => /^\/(?:images|uploads|docs|videos)\/[a-z0-9/_.,%\-]+$/i.test(value)

function Value({ value, lang, a, depth = 0 }) {
  if (value === null || value === undefined || value === '') return <span className="pa-muted">—</span>
  if (typeof value === 'boolean') return <span>{value ? a.yes : a.no}</span>
  if (typeof value === 'number') return <span>{number(value, lang)}</span>
  if (typeof value === 'string') {
    return assetPath(value)
      ? <a href={value} target="_blank" rel="noopener noreferrer" className="pa-value-link">{value}</a>
      : <span>{value}</span>
  }
  if (typeof value !== 'object') return <span>{String(value)}</span>
  const keys = Object.keys(value)
  if (!Array.isArray(value) && keys.length > 0 && keys.every((key) => key === 'fa' || key === 'en')) {
    return <span>{value[lang] || value.fa || value.en || '—'}</span>
  }
  if (depth > 4) return <span className="pa-muted">…</span>
  if (Array.isArray(value)) return value.length ? (
    <ol className="pa-sublist">{value.map((item, i) => <li key={i}><Value value={item} lang={lang} a={a} depth={depth + 1} /></li>)}</ol>
  ) : <span className="pa-muted">—</span>
  return <dl className="pa-pairs">{keys.map((key) => (
    <div key={key}>
      <dt>{label(key, lang, a)}</dt>
      <dd><Value value={value[key]} lang={lang} a={a} depth={depth + 1} /></dd>
    </div>
  ))}</dl>
}

function CollectionPage({ name, data, lang, a }) {
  const [query, setQuery] = useState('')
  const schema = COLLECTIONS[name]
  const rows = Array.isArray(data[name]) ? data[name] : []
  const readTitle = (row) => {
    const raw = row[schema.titleKey] ?? row.title ?? row.name ?? row.id
    return typeof raw === 'object' ? (raw?.[lang] || raw?.fa || raw?.en || row.id) : String(raw ?? row.id ?? '—')
  }
  const filtered = rows.filter((row) => `${readTitle(row)} ${row.id ?? ''}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()))
  return <section className="pa-card" aria-labelledby="collection-heading">
    <div className="pa-card-head">
      <div>
        <p className="pa-overline">{a[schema.group]}</p>
        <h2 id="collection-heading">{schema.label[lang]}</h2>
        <p className="pa-muted">{number(rows.length, lang)} {a.items} · {lang === 'fa' ? 'نمایش اطلاعات بدون امکان ویرایش' : 'Browse data without editing'}</p>
      </div>
      <label className="pa-search">
        <span className="pa-sr-only">{a.search}</span>
        <input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={a.search} />
      </label>
    </div>
    <div className="pa-list">
      {filtered.map((row, index) => {
        const image = row[schema.imageKey] ?? row.image ?? row.photo ?? row.logo
        return <details className="pa-record" key={row.id ?? index}>
          <summary>
            <span className="pa-thumb" aria-hidden="true">{typeof image === 'string' && assetPath(image)
              ? <img src={image} alt="" loading="lazy" /> : <span>{number(index + 1, lang)}</span>}</span>
            <span className="pa-record-text"><b>{readTitle(row)}</b><small dir="ltr">{row.id ?? '—'}</small></span>
            <span className="pa-record-tags">{row.demo === true && <span className="pa-tag">{a.demoItem}</span>}{row.featured === true && <span className="pa-tag pa-tag-light">{a.featured}</span>}</span>
            <span className="pa-chevron" aria-hidden="true">⌄</span>
          </summary>
          <div className="pa-record-body"><dl className="pa-pairs">{Object.entries(row).map(([key, value]) => <div key={key}>
            <dt>{label(key, lang, a)}</dt><dd><Value value={value} lang={lang} a={a} /></dd>
          </div>)}</dl></div>
        </details>
      })}
      {filtered.length === 0 && <p className="pa-empty">{a.empty}</p>}
    </div>
  </section>
}

function Dashboard({ data, lang, a }) {
  const total = COLLECTION_ORDER.reduce((sum, key) => sum + (Array.isArray(data[key]) ? data[key].length : 0), 0)
  const featured = ['products', 'news', 'partners', 'documents']
  return <div className="pa-stack">
    <div className="pa-summary">
      {[{ key: 'total', title: a.totalItems, amount: total }, ...featured.map((key) => ({ key, title: COLLECTIONS[key].label[lang], amount: data[key]?.length ?? 0 }))].map(({ key, title, amount }) => (
        <Link className="pa-stat" key={key} to={key === 'total' ? '/admin/c/products' : `/admin/c/${key}`}>
          <span className="pa-stat-number">{number(amount, lang)}</span><span>{title}</span><span className="pa-stat-arrow" aria-hidden="true">↗</span>
        </Link>
      ))}
    </div>
    <section className="pa-card" aria-labelledby="overview-heading">
      <div className="pa-card-head"><div><p className="pa-overline">{a.statsOverview}</p><h2 id="overview-heading">{lang === 'fa' ? 'مجموعه‌های محتوا' : 'Content collections'}</h2>
        <p className="pa-muted">{lang === 'fa' ? 'آمار فقط از رکوردهای فایل محلی محاسبه شده است.' : 'Counts are calculated only from the bundled local records.'}</p></div></div>
      <div className="pa-overview-grid">{COLLECTION_ORDER.map((key) => <Link key={key} to={`/admin/c/${key}`} className="pa-overview-item">
        <span>{COLLECTIONS[key].label[lang]}</span><b>{number(data[key]?.length ?? 0, lang)}</b>
      </Link>)}</div>
    </section>
  </div>
}

function SettingsPage({ settings, lang, a }) {
  return <section className="pa-card" aria-labelledby="settings-heading">
    <div className="pa-card-head"><div><p className="pa-overline">{a.system}</p><h2 id="settings-heading">{a.settings}</h2>
      <p className="pa-muted">{lang === 'fa' ? 'مقادیر محلی؛ ذخیره و بارگذاری وجود ندارد.' : 'Bundled values; saving and uploading are unavailable.'}</p></div></div>
    <div className="pa-list">{Object.entries(settings).map(([section, fields], i) => (
      <details className="pa-settings-group" key={section} open={i === 0}>
        <summary><span>{SETTINGS_LABELS[section]?.[lang] ?? section}</span><span className="pa-chevron" aria-hidden="true">⌄</span></summary>
        <div className="pa-record-body"><Value value={fields} lang={lang} a={a} /></div>
      </details>
    ))}</div>
  </section>
}

function Unavailable({ kind, lang, a }) {
  const requests = kind === 'requests'
  return <section className="pa-card pa-unavailable">
    <span className="pa-unavailable-icon" aria-hidden="true">{requests ? '▤' : '◎'}</span>
    <h2>{requests ? a.requests : a.account}</h2>
    <p>{requests
      ? (lang === 'fa' ? 'درخواست‌های واقعی در دادهٔ عمومیِ این پیش‌نمایش موجود نیستند. فرم‌ها ارسال نمی‌شوند و هیچ درخواستی این‌جا ثبت یا دریافت نمی‌شود.' : 'Real requests are not part of this public-content snapshot. Forms do not send, record or retrieve requests here.')
      : (lang === 'fa' ? 'ورود و حساب کاربری در پیش‌نمایش فقط‌خواندنی فعال نیستند. هیچ رمز عبور یا اطلاعات کاربری در فرانت‌اند نگهداری نمی‌شود.' : 'Sign-in and account management are inactive in this read-only preview. No passwords or user-account data are stored in the frontend.')}</p>
  </section>
}

export default function PreviewAdmin() {
  const { data, settings } = useContent()
  const { lang, setLang, L } = useLang()
  const a = A[lang]
  const location = useLocation()
  const [menuOpen, setMenuOpen] = useState(false)
  const menuButton = useRef(null)
  const sidebar = useRef(null)
  const route = location.pathname.replace(/^\/admin\/?/, '').replace(/\/+$/, '')
  const [section, name] = route ? route.split('/') : ['dashboard']
  const validCollection = section === 'c' && Object.hasOwn(COLLECTIONS, name)
  const title = validCollection ? COLLECTIONS[name].label[lang] : a[section] ?? a.dashboard
  const company = L(settings.company?.name) || 'خان بوستان'

  useEffect(() => { setMenuOpen(false) }, [location.pathname])
  useLayoutEffect(() => {
    if (!menuOpen || !window.matchMedia('(max-width: 900px)').matches) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const links = [...(sidebar.current?.querySelectorAll('button, a') ?? [])]
    // A hidden sidebar becomes focusable only after its first painted frame.
    let focusFrame
    const focusFirst = () => {
      if (links[0] && getComputedStyle(links[0]).visibility === 'visible') links[0].focus()
      else focusFrame = requestAnimationFrame(focusFirst)
    }
    focusFrame = requestAnimationFrame(focusFirst)
    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        setMenuOpen(false)
        menuButton.current?.focus()
      } else if (event.key === 'Tab' && links.length) {
        if (!sidebar.current?.contains(document.activeElement)) {
          event.preventDefault()
          if (getComputedStyle(links[0]).visibility === 'visible') links[0].focus()
          else { cancelAnimationFrame(focusFrame); focusFrame = requestAnimationFrame(focusFirst) }
        }
        else if (event.shiftKey && document.activeElement === links[0]) { event.preventDefault(); links[links.length - 1].focus() }
        else if (!event.shiftKey && document.activeElement === links[links.length - 1]) { event.preventDefault(); links[0].focus() }
      }
    }
    document.addEventListener('keydown', onKeyDown)
    return () => { cancelAnimationFrame(focusFrame); document.removeEventListener('keydown', onKeyDown); document.body.style.overflow = previousOverflow }
  }, [menuOpen])
  useEffect(() => { document.title = `${lang === 'fa' ? 'پنل فقط‌خواندنی' : 'Read-only panel'} | ${company}` }, [lang, company])

  const navLink = (to, text, count) => <NavLink to={to} onClick={() => { if (menuOpen) menuButton.current?.focus(); setMenuOpen(false) }} className={({ isActive }) => `pa-nav-link${isActive ? ' is-active' : ''}`}>
    <span className="pa-nav-dot" aria-hidden="true" />{text}{count !== undefined && <span className="pa-nav-count">{number(count, lang)}</span>}
  </NavLink>

  return <div className="preview-admin">
    {menuOpen && <button type="button" className="pa-overlay" onClick={() => { setMenuOpen(false); menuButton.current?.focus() }} aria-label={a.close} />}
    <aside ref={sidebar} id="panel-nav" className={`pa-sidebar${menuOpen ? ' is-open' : ''}`} aria-label={lang === 'fa' ? 'فهرست پنل' : 'Panel navigation'}>
      <button type="button" className="pa-sidebar-close" onClick={() => { setMenuOpen(false); menuButton.current?.focus() }} aria-label={a.close}>×</button>
      <Link className="pa-brand" to="/admin/" onClick={() => { if (menuOpen) menuButton.current?.focus(); setMenuOpen(false) }}>
        <img src="/images/logo.png" alt="" width="42" height="42" />
        <span><b>{company}</b><small>{a.appName}</small></span>
      </Link>
      <div className="pa-sidebar-rule" />
      <nav aria-label={lang === 'fa' ? 'بخش‌های پنل' : 'Panel sections'}>
        <div className="pa-nav-group">{navLink('/admin/dashboard', a.dashboard)}{navLink('/admin/requests', a.requests)}</div>
        {GROUPS.map((group) => <div className="pa-nav-group" key={group.key}>
          <h2>{a[group.key]}</h2>
          {group.items.map((key) => <div key={key}>{navLink(`/admin/c/${key}`, COLLECTIONS[key].label[lang], data[key]?.length ?? 0)}</div>)}
        </div>)}
        <div className="pa-nav-group"><h2>{a.system}</h2>{navLink('/admin/settings', a.settings)}{navLink('/admin/account', a.account)}</div>
      </nav>
      <Link to="/" className="pa-site-link">{a.viewSite} <span aria-hidden="true">↗</span></Link>
    </aside>
    <div className="pa-main">
      <header className="pa-toolbar">
        <button ref={menuButton} type="button" className="pa-menu" onClick={() => setMenuOpen((open) => !open)} aria-label={lang === 'fa' ? 'بازکردن فهرست' : 'Open menu'} aria-expanded={menuOpen} aria-controls="panel-nav">☰</button>
        <div><p className="pa-toolbar-kicker">{a.appName}</p><h1>{title}</h1></div>
        <button type="button" className="pa-lang" onClick={() => setLang(lang === 'fa' ? 'en' : 'fa')} aria-label={lang === 'fa' ? 'EN — switch to English' : 'دری — تغییر زبان به دری'}>{lang === 'fa' ? 'EN' : 'دری'}</button>
      </header>
      <main id="main" className="pa-content">
        <div className="pa-notice" role="status"><span className="pa-notice-mark" aria-hidden="true">●</span><div>
          <b>{lang === 'fa' ? 'حالت فقط‌خواندنی' : 'Read-only mode'}</b>
          <span>{lang === 'fa' ? 'اطلاعات از فایل محلی فرانت‌اند خوانده می‌شوند؛ ورود، ذخیره، بارگذاری و دریافت درخواست تا پایان طراحی غیرفعال است.' : 'Content comes from a local frontend file. Sign-in, saving, uploads and incoming requests are disabled during design.'}</span>
        </div></div>
        {validCollection ? <CollectionPage key={name} name={name} data={data} lang={lang} a={a} />
          : section === 'dashboard' && !name ? <Dashboard data={data} lang={lang} a={a} />
          : section === 'settings' && !name ? <SettingsPage settings={settings} lang={lang} a={a} />
          : (section === 'requests' || section === 'account') && !name ? <Unavailable kind={section} lang={lang} a={a} />
          : <section className="pa-card pa-unavailable"><h2>{lang === 'fa' ? 'صفحه پیدا نشد' : 'Page not found'}</h2><Link to="/admin/">{a.dashboard}</Link></section>}
      </main>
    </div>
  </div>
}

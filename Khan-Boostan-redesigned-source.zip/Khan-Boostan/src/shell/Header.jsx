import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { useContent, useLang } from '../../src/lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'

const navItems = (lang) => [
  { to: '/', label: lang === 'fa' ? 'خانه' : 'Home' },
  { to: '/about', label: lang === 'fa' ? 'دربارهٔ ما' : 'About' },
  { to: '/activities', label: lang === 'fa' ? 'فعالیت‌های تجارتی' : 'Trade Activities' },
  { to: '/products', label: lang === 'fa' ? 'محصولات' : 'Products' },
  { to: '/news', label: lang === 'fa' ? 'اخبار و رسانه‌ها' : 'News & Media' },
  { to: '/contact', label: lang === 'fa' ? 'تماس' : 'Contact' },
]

const navClass = ({ isActive }) => `tw-relative tw-inline-flex tw-min-h-11 tw-items-center tw-whitespace-nowrap tw-border-b-2 tw-px-1 tw-text-[13px] tw-font-bold tw-transition-colors motion-reduce:tw-transition-none focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${isActive ? 'tw-border-kb-gold tw-text-kb-blue' : 'tw-border-transparent tw-text-kb-body hover:tw-border-kb-gold/50 hover:tw-text-kb-blue'}`

export default function Header() {
  const { settings } = useContent()
  const { L, lang } = usePublicDict()
  const { setLang } = useLang()
  const { pathname, hash } = useLocation()
  const [open, setOpen] = useState(false)
  const company = settings.company ?? {}
  const items = navItems(lang)
  const activityLinks = [
    { to: '/import', label: L(settings.pages?.import?.title, lang === 'fa' ? 'واردات' : 'Import') },
    { to: '/export', label: L(settings.pages?.export?.title, lang === 'fa' ? 'صادرات' : 'Export') },
    { to: '/process', label: lang === 'fa' ? 'مراحل همکاری' : 'Cooperation process' },
    { to: '/trade-guide', label: lang === 'fa' ? 'راهنمای آمادگی تجارت' : 'Trade readiness guide' },
    { to: '/projects', label: lang === 'fa' ? 'پرونده‌های تجارتی' : 'Trade cases' },
  ]
  const subnavs = {
    '/about': [
      { to: '/partners', label: lang === 'fa' ? 'شرکا و روابط تجارتی' : 'Trade relationships' },
      { to: '/careers', label: lang === 'fa' ? 'فرصت‌های شغلی' : 'Careers' },
    ],
    '/activities': activityLinks,
    '/news': [
      { to: '/gallery', label: lang === 'fa' ? 'گالری رسانه‌ها' : 'Media gallery' },
      { to: '/downloads', label: lang === 'fa' ? 'مرکز دانلودها' : 'Download centre' },
    ],
  }
  const moreLinks = [...activityLinks, subnavs['/about'][0], { to: '/gallery', label: lang === 'fa' ? 'گالری رسانه‌ها' : 'Media gallery' }, { to: '/downloads', label: lang === 'fa' ? 'مرکز دانلودها' : 'Download centre' }, subnavs['/about'][1]]

  useEffect(() => setOpen(false), [pathname, hash])
  useEffect(() => {
    if (!open) return undefined
    const onKeyDown = (event) => { if (event.key === 'Escape') setOpen(false) }
    window.addEventListener('keydown', onKeyDown)
    const oldOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      document.body.style.overflow = oldOverflow
    }
  }, [open])

  return <header className="tw-relative tw-z-50 tw-w-full tw-bg-white tw-text-kb-ink">
    <div className="tw-border-b tw-border-kb-line tw-bg-white">
      <SiteContainer className="tw-grid tw-min-h-16 tw-grid-cols-[minmax(0,1fr)_auto] tw-items-center tw-gap-x-2 sm:tw-flex sm:tw-min-h-[76px] sm:tw-gap-4 lg:tw-min-h-[86px] lg:tw-gap-6">
        <Link className="tw-flex tw-min-w-0 tw-items-center tw-gap-2.5 tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue sm:tw-shrink-0" to="/">
          <span className="tw-flex tw-h-11 tw-w-11 tw-shrink-0 tw-items-center tw-justify-center tw-overflow-hidden tw-rounded-full tw-bg-white sm:tw-h-12 sm:tw-w-12"><img src="/brand/khan-boostan-official.png" width="52" height="52" alt="" className="tw-h-full tw-w-full tw-object-contain" /></span>
          <span className="tw-flex tw-min-w-0 tw-flex-col tw-leading-tight"><b className="tw-break-words tw-text-sm tw-font-bold tw-text-kb-navy sm:tw-text-base">{L(company.name)}</b><small className="tw-mt-1 tw-hidden tw-max-w-[220px] tw-whitespace-normal tw-break-words tw-text-[10px] tw-leading-4 tw-text-kb-muted sm:tw-block xl:tw-max-w-[280px]">{L(company.tagline)}</small></span>
        </Link>
        <p className="tw-col-span-2 tw-row-start-2 tw-pb-2 tw-ps-[54px] tw-text-[10px] tw-leading-5 tw-text-kb-muted sm:tw-hidden">{L(company.tagline)}</p>

        <nav className="tw-hidden tw-flex-1 tw-items-center tw-justify-center tw-gap-3 xl:tw-gap-5 xl:tw-flex" aria-label={lang === 'fa' ? 'منوی اصلی' : 'Main navigation'}>
          {items.map((item) => {
            const children = subnavs[item.to] ?? []
            return <div className="tw-group tw-relative tw-flex tw-items-stretch" key={item.to}>
              <NavLink to={item.to} end={item.to === '/'} className={navClass}>{item.label}{children.length > 0 && <svg className="tw-ms-1" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>}</NavLink>
              {children.length > 0 && <div className="tw-invisible tw-absolute tw-start-0 tw-top-full tw-z-50 tw-translate-y-1 tw-opacity-0 tw-transition-all tw-duration-150 group-hover:tw-visible group-hover:tw-translate-y-0 group-hover:tw-opacity-100 group-focus-within:tw-visible group-focus-within:tw-translate-y-0 group-focus-within:tw-opacity-100">
                <div className="tw-mt-1 tw-min-w-56 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-2 tw-shadow-kb-lift">
                  <p className="tw-px-3 tw-py-2 tw-text-[10px] tw-font-bold tw-tracking-[.1em] tw-text-kb-muted">{lang === 'fa' ? 'صفحه‌های مرتبط' : 'RELATED PAGES'}</p>
                  <ul className="tw-grid tw-gap-1">{children.map((child) => <li key={child.to}><NavLink to={child.to} className={({ isActive }) => `tw-flex tw-min-h-10 tw-items-center tw-rounded-kb tw-px-3 tw-text-sm tw-font-semibold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${isActive ? 'tw-bg-kb-paper tw-text-kb-blue' : 'tw-text-kb-body hover:tw-bg-kb-paper hover:tw-text-kb-blue'}`}>{child.label}</NavLink></li>)}</ul>
                </div>
              </div>}
            </div>
          })}
        </nav>

        <div className="tw-ms-auto tw-flex tw-shrink-0 tw-items-center tw-gap-2.5 sm:tw-gap-3">
          <div className="tw-flex tw-items-center tw-gap-1 tw-rounded-full tw-border tw-border-kb-line tw-bg-kb-paper tw-p-1" role="group" aria-label={lang === 'fa' ? 'زبان سایت' : 'Site language'}>
            <button type="button" className={`tw-min-h-8 tw-min-w-9 tw-rounded-full tw-px-2 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${lang === 'fa' ? 'tw-bg-kb-blue tw-text-white' : 'tw-text-kb-body hover:tw-text-kb-blue'}`} onClick={() => setLang('fa')} aria-pressed={lang === 'fa'}>دری</button>
            <button type="button" className={`tw-min-h-8 tw-min-w-9 tw-rounded-full tw-px-2 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${lang === 'en' ? 'tw-bg-kb-blue tw-text-white' : 'tw-text-kb-body hover:tw-text-kb-blue'}`} onClick={() => setLang('en')} aria-pressed={lang === 'en'}>EN</button>
          </div>
          <PrimaryLink to="/contact?kind=cooperation" className="tw-hidden tw-min-h-10 tw-gap-2 tw-px-4 tw-text-xs md:tw-inline-flex">{lang === 'fa' ? 'درخواست همکاری' : 'Start an enquiry'}<ArrowIcon size={15} /></PrimaryLink>
          <button className="tw-inline-flex tw-h-10 tw-w-10 tw-items-center tw-justify-center tw-rounded-kb tw-border tw-border-kb-line tw-bg-white tw-text-kb-navy hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue xl:tw-hidden" type="button" aria-label={open ? (lang === 'fa' ? 'بستن منو' : 'Close menu') : (lang === 'fa' ? 'بازکردن منو' : 'Open menu')} aria-expanded={open} aria-controls="public-mobile-menu" onClick={() => setOpen((value) => !value)}>
            {open ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" /></svg> : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" /></svg>}
          </button>
        </div>
      </SiteContainer>
    </div>

    {open && <button className="tw-fixed tw-inset-0 tw-z-40 tw-bg-kb-navy/45 tw-backdrop-blur-[2px] xl:tw-hidden" type="button" aria-label={lang === 'fa' ? 'بستن منو' : 'Close menu'} onClick={() => setOpen(false)} />}
    <nav id="public-mobile-menu" className="tw-absolute tw-inset-x-0 tw-top-full tw-z-50 tw-max-h-[calc(100vh_-_8rem)] tw-overflow-y-auto tw-border-t tw-border-kb-line tw-bg-white tw-shadow-kb-lift xl:tw-hidden" aria-label={lang === 'fa' ? 'منوی موبایل' : 'Mobile navigation'} hidden={!open}>
      <SiteContainer className="tw-py-5">
        <div className="tw-mb-3 tw-flex tw-items-center tw-justify-between tw-border-b tw-border-kb-line tw-pb-3"><span className="tw-text-xs tw-font-bold tw-tracking-[.12em] tw-text-kb-gold">{lang === 'fa' ? 'فهرست سایت' : 'SITE DIRECTORY'}</span><span className="tw-text-[11px] tw-text-kb-muted">{lang === 'fa' ? 'خان بوستان · تجارت عمومی' : 'KHAN BOOSTAN · GENERAL TRADE'}</span></div>
        <div className="tw-grid tw-grid-cols-1 tw-divide-y tw-divide-kb-line sm:tw-grid-cols-2 sm:tw-divide-y-0 sm:tw-gap-x-5">
          {items.map((item, index) => <NavLink to={item.to} end={item.to === '/'} key={item.to} onClick={() => setOpen(false)} className={({ isActive }) => `tw-flex tw-min-h-12 tw-items-center tw-gap-3 tw-py-2 tw-text-start focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${isActive ? 'tw-text-kb-blue' : 'tw-text-kb-ink hover:tw-text-kb-blue'}`}>
            <span className="tw-text-[10px] tw-font-bold tw-tracking-[.12em] tw-text-kb-navy">{lang === 'fa' ? String(index + 1).replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[digit]).padStart(2, '۰') : String(index + 1).padStart(2, '0')}</span><b className="tw-flex-1 tw-text-sm">{item.label}</b><ArrowIcon kind="up" size={14} className="tw-text-kb-muted" />
          </NavLink>)}
        </div>
        <div className="tw-mt-5 tw-border-t tw-border-kb-line tw-pt-4">
          <h3 className="tw-text-[10px] tw-font-bold tw-tracking-[.12em] tw-text-kb-gold">{lang === 'fa' ? 'صفحه‌های مرتبط' : 'RELATED PAGES'}</h3>
          <ul className="tw-mt-2 tw-grid tw-grid-cols-2 tw-gap-1 sm:tw-grid-cols-4">{moreLinks.map((item) => <li key={item.to}><NavLink to={item.to} onClick={() => setOpen(false)} className={({ isActive }) => `tw-flex tw-min-h-10 tw-items-center tw-gap-2 tw-rounded-kb tw-px-2 tw-text-xs tw-font-semibold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${isActive ? 'tw-bg-kb-paper tw-text-kb-blue' : 'tw-text-kb-body hover:tw-bg-kb-paper hover:tw-text-kb-blue'}`}><span>{item.label}</span><ArrowIcon size={12} className="tw-shrink-0 tw-text-kb-gold" /></NavLink></li>)}</ul>
        </div>
        <p className="tw-mt-4 tw-text-xs tw-leading-6 tw-text-kb-muted">{L(company.summary)}</p>
      </SiteContainer>
    </nav>
  </header>
}

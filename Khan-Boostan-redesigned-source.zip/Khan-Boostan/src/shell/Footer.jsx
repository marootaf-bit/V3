import { Link } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import Eyebrow from '../components/public/Eyebrow.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'

export default function Footer({ showCta = true }) {
  const { settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const company = settings.company ?? {}
  const mainLinks = [
    ['/', lang === 'fa' ? 'خانه' : 'Home'],
    ['/about', lang === 'fa' ? 'دربارهٔ ما' : 'About'],
    ['/activities', lang === 'fa' ? 'فعالیت‌های تجارتی' : 'Trade Activities'],
    ['/products', lang === 'fa' ? 'محصولات' : 'Products'],
    ['/news', lang === 'fa' ? 'اخبار و رسانه‌ها' : 'News & Media'],
    ['/contact', lang === 'fa' ? 'تماس' : 'Contact'],
  ]
  const relatedLinks = [
    ['/import', L(settings.pages?.import?.title, lang === 'fa' ? 'واردات' : 'Import')],
    ['/export', L(settings.pages?.export?.title, lang === 'fa' ? 'صادرات' : 'Export')],
    ['/process', lang === 'fa' ? 'مراحل همکاری' : 'Cooperation process'],
    ['/trade-guide', lang === 'fa' ? 'راهنمای آمادگی تجارت' : 'Trade readiness guide'],
    ['/partners', lang === 'fa' ? 'شرکا و روابط تجارتی' : 'Trade relationships'],
    ['/projects', lang === 'fa' ? 'پرونده‌های تجارتی' : 'Trade cases'],
    ['/gallery', lang === 'fa' ? 'گالری رسانه‌ها' : 'Media gallery'],
    ['/downloads', lang === 'fa' ? 'مرکز دانلودها' : 'Download centre'],
    ['/careers', lang === 'fa' ? 'فرصت‌های شغلی' : 'Careers'],
  ]

  return <>
    {showCta && <section className="tw-border-y tw-border-kb-line tw-bg-kb-paper tw-py-9 sm:tw-py-12" aria-labelledby="public-footer-cta-title">
      <SiteContainer className="tw-flex tw-flex-col tw-items-start tw-justify-between tw-gap-6 md:tw-flex-row md:tw-items-center">
        <div className="tw-max-w-2xl"><Eyebrow>{lang === 'fa' ? 'درخواست تجارتی' : 'TRADE ENQUIRY'}</Eyebrow><h2 id="public-footer-cta-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{lang === 'fa' ? 'نیاز بازار خود را با ما در میان بگذارید.' : 'Tell us what your market needs.'}</h2><p className="tw-mt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{lang === 'fa' ? 'کالا، مشخصات، مقدار و مقصد را بگویید تا گفتگو از همان‌جا آغاز شود.' : 'Share the goods, specifications, quantity and destination to start the conversation.'}</p></div>
        <PrimaryLink to="/contact?kind=product" variant="gold" className="tw-shrink-0">{lang === 'fa' ? 'تماس و استعلام' : 'Contact & enquire'}<ArrowIcon /></PrimaryLink>
      </SiteContainer>
    </section>}

    <footer className="tw-bg-kb-navy tw-text-white">
      <SiteContainer className="tw-grid tw-gap-10 tw-py-10 md:tw-grid-cols-2 lg:tw-grid-cols-4 lg:tw-gap-8 lg:tw-py-14">
        <div className="tw-max-w-sm">
          <Link className="tw-inline-flex tw-items-center tw-gap-3 tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to="/">
            <span className="tw-flex tw-h-12 tw-w-12 tw-shrink-0 tw-items-center tw-justify-center tw-overflow-hidden tw-rounded-full tw-bg-white"><img src="/brand/khan-boostan-official.png" width="52" height="52" alt="" className="tw-h-full tw-w-full tw-object-contain" /></span>
            <span className="tw-flex tw-min-w-0 tw-flex-col tw-leading-tight"><b className="tw-break-words tw-text-sm tw-font-bold">{L(company.name)}</b><small className="tw-mt-1 tw-whitespace-normal tw-break-words tw-text-[10px] tw-leading-5 tw-text-white/65">{L(company.tagline)}</small></span>
          </Link>
          <p className="tw-mt-5 tw-text-sm tw-leading-7 tw-text-white/75">{L(company.summary)}</p>
        </div>

        <div><h3 className="tw-mb-3 tw-text-xs tw-font-bold tw-tracking-[.12em] tw-text-kb-gold">{lang === 'fa' ? 'منوی اصلی' : 'MAIN SECTIONS'}</h3><ul className="tw-space-y-1.5">{mainLinks.map(([to, label]) => <li key={to}><Link className="tw-inline-flex tw-min-h-8 tw-items-center tw-gap-2 tw-text-sm tw-text-white/80 tw-transition-colors hover:tw-text-white focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to={to}>{label}<ArrowIcon size={13} className="tw-text-kb-gold" /></Link></li>)}</ul></div>

        <div><h3 className="tw-mb-3 tw-text-xs tw-font-bold tw-tracking-[.12em] tw-text-kb-gold">{lang === 'fa' ? 'صفحه‌های مرتبط' : 'RELATED PAGES'}</h3><ul className="tw-grid tw-grid-cols-2 tw-gap-x-3 tw-gap-y-1.5">{relatedLinks.map(([to, label]) => <li key={to}><Link className="tw-inline-flex tw-min-h-8 tw-items-center tw-gap-1.5 tw-text-xs tw-leading-5 tw-text-white/75 tw-transition-colors hover:tw-text-white focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to={to}>{label}<ArrowIcon size={12} className="tw-shrink-0 tw-text-kb-gold" /></Link></li>)}</ul></div>

        <div className="tw-border-t tw-border-white/15 tw-pt-6 md:tw-col-span-2 lg:tw-col-span-1 lg:tw-border-t-0 lg:tw-pt-0"><Eyebrow tone="gold">{lang === 'fa' ? 'با ما گفتگو کنید' : 'LET’S TALK'}</Eyebrow><h3 className="tw-mt-2 tw-text-lg tw-font-bold tw-leading-7 tw-text-white">{lang === 'fa' ? 'یک درخواست روشن، آغاز همکاری است.' : 'A clear enquiry is a good place to start.'}</h3><Link className="tw-mt-4 tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-rounded-kb tw-border tw-border-white/35 tw-px-3 tw-text-sm tw-font-bold tw-text-white hover:tw-border-kb-gold hover:tw-text-kb-gold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to="/contact">{lang === 'fa' ? 'رفتن به صفحهٔ تماس' : 'Open contact page'}<ArrowIcon /></Link></div>
      </SiteContainer>
      <div className="tw-border-t tw-border-white/15 tw-bg-[#06263D]"><SiteContainer className="tw-flex tw-flex-col tw-gap-3 tw-py-4 tw-text-[11px] tw-text-white/65 sm:tw-flex-row sm:tw-items-center sm:tw-justify-between"><span>© {new Date().getFullYear()} {L(company.name)}</span><span>{lang === 'fa' ? 'تجارت عمومی · واردات · صادرات' : 'General trade · Import · Export'}</span><div className="tw-flex tw-gap-4"><Link className="tw-underline-offset-4 hover:tw-text-white hover:tw-underline focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to="/privacy">{t('nav_privacy')}</Link><Link className="tw-underline-offset-4 hover:tw-text-white hover:tw-underline focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" to="/terms">{t('nav_terms')}</Link></div></SiteContainer></div>
    </footer>
  </>
}

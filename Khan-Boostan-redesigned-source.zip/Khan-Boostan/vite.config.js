import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'node:fs'
import path from 'node:path'

/**
 * Dev-only middleware: serve the read-only static assets that live in deploy/
 * (images, fonts, docs, uploads, videos, favicon.svg, og.jpg) so the dev
 * preview renders the same media as the static build. PHP and .htaccess are
 * never served. The production static build is produced by build-static.py,
 * which copies these assets from deploy/ read-only; deploy/ is never written.
 */
function deployStaticAssets() {
  const ASSET_DIRS = ['docs', 'fonts', 'images', 'uploads', 'videos']
  const ASSET_FILES = ['favicon.svg', 'og.jpg']
  const MIME = {
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
    '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
    '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
    '.pdf': 'application/pdf', '.mp4': 'video/mp4', '.webm': 'video/webm',
    '.json': 'application/json', '.txt': 'text/plain; charset=utf-8',
  }
  return {
    name: 'kb-deploy-static-assets',
    configureServer(server) {
      const deployDir = path.resolve(server.config.root, '../deploy')
      server.middlewares.use((req, res, next) => {
        const url = decodeURIComponent((req.url || '').split('?')[0])
        const rel = url.replace(/^\/+/, '')
        const allowed = ASSET_FILES.includes(rel) || ASSET_DIRS.some((d) => rel.startsWith(d + '/'))
        if (!allowed || rel.includes('..') || /\.(php|htaccess)$/i.test(rel)) return next()
        const file = path.join(deployDir, rel)
        if (!file.startsWith(deployDir + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return next()
        res.setHeader('Content-Type', MIME[path.extname(file).toLowerCase()] || 'application/octet-stream')
        res.setHeader('Cache-Control', 'no-cache')
        fs.createReadStream(file).pipe(res)
      })
    },
  }
}

export default defineConfig({
  root: 'src',
  plugins: [react(), deployStaticAssets()],
  build: { outDir: '../dist', emptyOutDir: true },
  server: { allowedHosts: true },
  preview: { allowedHosts: true },
})

/** @type {import('tailwindcss').Config}
 *  Design system v2 — derived from the approved references:
 *  "Colo pointer.jpg"  → graphite + coral/peach + light mist palette
 *  "Design implemention*.jpg" → dark hero panels, stat strips, process line,
 *                               dark testimonial/CTA bands, dark footer
 *  Token NAMES are kept from v1 (ink/brass/…) so page code stays stable;
 *  their VALUES now carry the new brand.
 */
export default {
  content: ['./src/**/*.{js,ts,jsx,tsx,html}'],
  theme: {
    extend: {
      colors: {
        // deep pine-ink family — the manuscript ink of the Silk Road world
        ink:   { DEFAULT: '#12332C', 2: '#1B473E', 3: '#245B50', 4: '#55857A' },
        // saffron — accents, eyebrows, tags, marks
        brass: { DEFAULT: '#CE9527', deep: '#AE7B1D', pale: '#F7EBD3', dark: '#8A6117' },
        // lapis lazuli — primary actions, links, focus, active states
        brand: { DEFAULT: '#2451A0', deep: '#1D4487', dark: '#17366E', pale: '#E5EAF7' },
        // neutrals — warm parchment
        paper:  '#FDFBF6',
        stone2: '#F4EEE2',
        mist:   { 50: '#F9F5ED', 100: '#F2ECDF', 200: '#E7DFCF', 300: '#CFC2A9' },
        rule:   { DEFAULT: '#E7DFCF', strong: '#BFAF92' },
        // semantic
        ok:  '#2E9E6B',
        err: '#D64545'
      },
      fontFamily: {
        sans: ['"Vazirmatn"', '"Noto Sans Arabic"', 'Tahoma', 'Arial', 'sans-serif'],
        head: ['"Noto Naskh Arabic"', '"Noto Sans Arabic"', 'Tahoma', 'serif']
      },
      boxShadow: {
        card: '0 1px 2px rgba(12,46,78,.04), 0 10px 30px -18px rgba(12,46,78,.18)',
        lift: '0 4px 10px rgba(12,46,78,.06), 0 30px 60px -28px rgba(12,46,78,.30)',
        panel: '0 24px 60px -30px rgba(20,23,26,.55)'
      },
      borderRadius: { card: '14px', xl2: '20px' }
    }
  },
  plugins: []
}

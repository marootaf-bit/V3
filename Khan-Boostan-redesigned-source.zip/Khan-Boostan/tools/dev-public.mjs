import { spawn } from 'node:child_process'
import { resolve } from 'node:path'

const root = process.cwd()
const tailwindCli = resolve(root, 'node_modules/tailwindcss/lib/cli.js')
const viteCli = resolve(root, 'node_modules/vite/bin/vite.js')
const tailwindArgs = ['--config', 'tailwind.public.config.js', '--input', 'src/public-tailwind.input.css', '--output', 'src/public-tailwind.generated.css']
const children = new Set()
let stopping = false

function stop(code = 0) {
  if (stopping) return
  stopping = true
  for (const child of children) child.kill('SIGTERM')
  process.exitCode = code
}

process.on('SIGINT', () => stop(130))
process.on('SIGTERM', () => stop(143))

function launch(args) {
  const child = spawn(process.execPath, args, { cwd: root, stdio: 'inherit' })
  children.add(child)
  child.on('error', (error) => {
    console.error(error)
    stop(1)
  })
  child.on('exit', (code, signal) => {
    children.delete(child)
    if (!stopping) stop(code ?? (signal === 'SIGINT' ? 130 : 1))
  })
  return child
}

const initialBuild = spawn(process.execPath, [tailwindCli, ...tailwindArgs], { cwd: root, stdio: 'inherit' })
initialBuild.on('error', (error) => {
  console.error(error)
  stop(1)
})
initialBuild.on('exit', (code) => {
  if (stopping) return
  if (code !== 0) return stop(code ?? 1)
  launch([tailwindCli, ...tailwindArgs, '--watch=always'])
  launch([viteCli, '--config', 'vite.config.js', '--host', '0.0.0.0', '--port', '5173'])
})
